import numpy as np
import pandas as pd
from sklearn.neighbors import LocalOutlierFactor

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM

from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, precision_recall_curve, auc, f1_score, roc_auc_score, accuracy_score
import time
import json
import os
# from core.feature_engineer import *
import matplotlib.pyplot as plt


filename = 'test2.csv'

seed = 12345
ntrees = 100

antV = ['#1890FF', '#2FC25B', '#FACC14', '#223273', '#8543E0', '#13C2C2', '#3436c7', '#F04864'] 


gwd = os.getcwd()
filename = 'singapore_hotel.csv'
input_dir = os.path.join(gwd,'data/', filename)



def add_label(data, threshold = 3):

    lower = float(data.mean() - data.std()*threshold)
    higher = float(data.std()*threshold + data.mean())

    y_true = ((data > higher)|(data < lower))
    y_true = y_true.astype(int)  
    return y_true


def concat_label(data, y_pred):
    df = data.copy()
    df['y_pred'] = y_pred 
    return df


def LOF(df,  plot = False):
    var1 = 0
    df = df.reset_index(drop=True)
    clf = LocalOutlierFactor(n_neighbors= 100, contamination=0.01)

    y_pred = clf.fit_predict(df)
    LOF_pred = pd.Series(y_pred).replace([-1,1],[1,0])
    LOF_anomalies = df[LOF_pred==1]
    LOF_Scores = clf.negative_outlier_factor_
  
    return LOF_pred
    

def grid_search(col, model_name, k = False, plot=False): 
    models = {'isolation_forest': isolation_forest, 'LOF': LOF}
    search_results = {}
    execution_time = {}
    model = models[model_name]
    test_df = pd.DataFrame(col)
    if k == False:
        for thresh in np.arange(3,6,1):
            start_time = time.time()
            y_true = add_label(test_df, thresh)
            y_pred = model(test_df, thresh)
            exe_time = time.time() - start_time
            acc = accuracy_score(y_true, y_pred)
            execution_time[thresh] = exe_time
            search_results[thresh] = acc
        best_k = max(search_results, key=search_results.get)
    else:
        best_k = k 
    y_pred = model(test_df, best_k)
    if plot: 
        y_pred = pd.Series(y_pred)
        y_anomalies = concat_label(test_df, y_pred)
        y_anomalies=y_anomalies.reset_index(drop=True)
        plt.figure(figsize=(12,4), dpi=100)
        plt.style.use('ggplot')
        plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
        plt.scatter(range(len(col)), col, color= 'mediumturquoise', s=3., label= 'Data points')
        y_anomalies = y_anomalies[y_pred==1]
        plt.scatter(y_anomalies.index, y_anomalies.iloc[:, 0],c='lightsalmon', alpha = 0.7)
        plt.title(str(model_name) + ' - '+str(y_anomalies.columns[0]) +' Anomalies')
        plt.xlabel('Date integer')
        gwd = os.getcwd()
        plot_dir = make_dir(os.path.join(gwd , 'anomaly_detection/'))
        try:
            plt.savefig(plot_dir+str(y_anomalies.columns[0])+'.png',transparent=False)
        except:
            plt.savefig(plot_dir+str(y_anomalies.columns[0].replace('\n', '').replace('\r', '').replace('/',''))+'.png',transparent=False)
        # plt.close()
        plt.show()
    # print('For model {a} the best standard deviation threshold is {b:.3f} and the best model accuracy is {c:.5f} execution time is {d:.3f} '.format(a= model_name, b=best_k, c=search_results[best_k],d=execution_time[best_k]))
    return [int(val) for val in y_pred]


def isolation_forest(data, thresh):
    data = data.reset_index(drop=True)

    isf = IsolationForest(max_samples='auto',random_state=seed, contamination=(thresh/1000),
                        n_estimators=ntrees).fit(data)

    iso_predictions = isf.predict(data)
    y_pred = list(map(lambda x: 1*(x == -1), iso_predictions))

    return y_pred



def anomaly_detection(df, k = False, col = False, plot=True, method ='isolation_forest'):
    data = df.copy()
    # print('The anomaly detection method is {}'.format(method))
    if isinstance(data, pd.Series):
        # print('The input data is a series')
        # name = data.name
        # data = np.nan_to_num(data)

        data = grid_search(data, method, k, plot)
        # print(data.value_counts())
        return data
    elif isinstance(data, pd.DataFrame):
        if col:
            data[col] = np.nan_to_num(data[col])
            if method == 'isolation_forest':
                data[col] = grid_search(np.nan_to_num(data[col]), method, k, plot)
            elif method == 'LOF':
                data[col] = grid_search(np.nan_to_num(data[col]), 'LOF', k, plot) 
            else:
                pass
        else:
            for col in df.columns: 
                # col = np.nan_to_num(col)
                try:
                    data[col] = grid_search(data[col], method, k, plot)
                    print('The total number of anomalies in the col {} are {}'.format(str(col), (data[col] == 1).sum()))
                except:
                    data[col] = grid_search(data[col], 'LOF', k, plot) 
                    print('The total number of anomalies in the col {} are {}'.format(str(col), (data[col] == 1).sum()))
                else:
                    pass
        return data
        # if replace: 
        #     df[col] = replace_outlier(df,col)
    

def make_dir(outdir):
   '''
   Chcek and create directory if directory does not exist
   Returns a directory path
   '''
   if not os.path.exists(outdir):
       print('The output directory does not exist. Trying to make one..')
       os.makedirs(outdir)
   return outdir


# if __name__ == "__main__":
#     df = load_data(input_dir)
#     after_ad = anomality_detect(df,replace=True, plot=True)
#     after_ad.head()