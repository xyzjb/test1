import numpy as np
import pandas as pd


def data_breakup(df, key):
    """
    Break the data into multiple dataframes based on a specified column(key)

    Args: 
        - df: Input data frame
        - key: column name
    
     Returns:
        - return: Merged frame of df1 and df2
    """


def a_d(data, k=False, col=False, plot=True, method = 'isolation_forest'):
    '''
     Detect the anomaly with specified method and replace them with the mean value of the 14 periods around the date
     Return a dataframe of marked anomalies

    Args: 
        - data: input dataframe
        - replace: 
    '''
    df = data.copy()
    if isinstance(data, pd.DataFrame):
        df = df.select_dtypes(['number'])
    # df = np.nan_to_num(data)
    df = df.astype('float')
    after_ad = anomaly_detection(df, col, k, plot,method)
    return after_ad

def replace_anomaly(data, k = False, col = False,  plot=True, method = 'isolation_forest'):
    ''' 
        Replace the labeled anomalies with the mean of the column 
        Return a dataframe after the replacement 

        Args: 
            - df: input dataframe
    '''
    # TODO Replace with MOVING AVERAGE FILL 
    # df = df.assign(RollingMean=df.target.fillna(df.target.rolling(freq,min_periods=1,).mean()))
    df = data.copy()
    ori_index = df.index
    df = df.fillna(method = 'bfill').reset_index(drop=True)
    after_ad = a_d(df, col, k, plot, method = method)
    if isinstance(data, pd.Series):
        indices = [i for i, x in enumerate(after_ad) if x == 1]
        df.loc[indices] = np.nan
        # rep_list = [np.nan if (val == 1) else df[i] for i, val in enumerate(after_ad)]
        rep_col = df.interpolate(method='linear')
        rep_col.index = ori_index
        return rep_col
    elif isinstance(data, pd.DataFrame):
        df = df.select_dtypes(['number'])
        # df = fill_na(df).reset_index(drop=True)       
        if col: 
            df[col] = [np.nan if (val == 1) else df[col].loc[i] for i, val in enumerate(after_ad[col])]
            # rep_col = pd.Series(rep_list)
            return df[col].interpolate(method='linear')
        else:
            for col in df.columns:          
                # df[col] = [np.mean(df[col][i-7:i+7]) if (val == 1) else df[col][i] for i, val in enumerate(after_ad[col])]
                indices = [i for i, x in enumerate(after_ad) if x == 1]
                df[col].loc[indices] = np.nan
                df[col] = df[col].interpolate(method='linear')
                
                # df[col] = [df[col].rolling(30,min_periods=1,).mean() if (val == 1) else df[col].loc[i] for i, val in enumerate(after_ad[col])]
            logger.warning('Replaced anomalies detected with {} method'.format(method))
            # after_df = a_d(df, col, plot, method = method)
            # return df[~df.index.duplicated(keep='last')]
            df.index = ori_index
            return df

