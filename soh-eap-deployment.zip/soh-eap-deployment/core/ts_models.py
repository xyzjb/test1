from core.feature_engineer import * 
# from feature_engineer import normalization, fill_na
import warnings
import itertools
from statsmodels.tsa.arima_model import ARIMA
from pmdarima.arima import auto_arima
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.model_selection import TimeSeriesSplit
from collections import defaultdict
from sklearn.metrics import mean_squared_error
warnings.filterwarnings("ignore")


def tsplot(y, title='', lags=None, figsize=(12, 10)):
    plt.style.use('fivethirtyeight')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    fig = plt.figure(figsize=figsize)
    layout = (2, 2)
    ts_ax = plt.subplot2grid(layout, (0, 0))
    hist_ax = plt.subplot2grid(layout, (0, 1))
    acf_ax = plt.subplot2grid(layout, (1, 0))
    pacf_ax = plt.subplot2grid(layout, (1, 1))


    y.plot(ax=ts_ax, color = antV[5], lw = 3, alpha =0.6)
    ts_ax.set_title( title, fontsize=15, fontweight='bold')
    y.plot(ax=hist_ax, kind='hist', bins=25, color = antV[7], lw = 3, alpha =0.6)
    hist_ax.set_title('Histogram')
    sm.tsa.graphics.plot_acf(y, lags=lags, ax=acf_ax)
    sm.tsa.graphics.plot_pacf(y, lags=lags, ax=pacf_ax)
    sns.despine()
    plt.tight_layout()
    plt.show()
    return ts_ax, acf_ax, pacf_ax

def plot_diff(df, col):
    plt.style.use('fivethirtyeight')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.rcParams.update({'figure.figsize':(18,20), 'figure.dpi':300})
    # Original Series
    fig, axes = plt.subplots(3, 2, sharex=True)
    axes[0, 0].plot(df[col],color = 'mediumturquoise', alpha = 0.6, linewidth=4) 
    axes[0, 0].set_title('Original Series')
    plot_acf(df[col], ax=axes[0, 1],color = 'salmon', alpha = 0.6, linewidth=4)

    # 1st Differencing
    axes[1, 0].plot(df[col].diff(),color = 'mediumturquoise', alpha = 0.6, linewidth=4) 
    axes[1, 0].set_title('1st Order Differencing')
    plot_acf(df[col].diff().dropna(), ax=axes[1, 1],color = 'salmon', alpha = 0.6, linewidth=4)

    # 2nd Differencing
    axes[2, 0].plot(df[col].diff().diff(),color = 'mediumturquoise', alpha = 0.6, linewidth=4) 
    axes[2, 0].set_title('2nd Order Differencing')
    plot_acf(df[col].diff().diff().dropna(), ax=axes[2, 1],color = 'salmon', alpha = 0.6, linewidth=4)
    
    # # 2nd Differencing
    # axes[3, 0].plot(df[col].diff().diff(),color = 'mediumturquoise', alpha = 0.6, linewidth=4) 
    # axes[3, 0].set_title('3rd Order Differencing')
    # plot_acf(df[col].diff().diff().dropna(), ax=axes[3, 1],color = 'salmon', alpha = 0.6, linewidth=4)

    plot_name = col
    plt.title(plot_name +' - Autocorrelation Check' )
    plot_dir = make_dir(os.path.join(gwd ,'plots','ts_eda/'))
    plt.savefig(plot_dir+ plot_name +'_autocorrelation'+'.png')
    plt.show()
    

def var(X_train, y_train, X_test, y_test, p, q ):
    model = sm.tsa.VARMAX(endog = y_train, exog = X_train, order=(p, q), trend='c')
    model_res = model.fit(maxiter= 1000, disp= False)
    model_res.summary()
    n_periods = len(y_test)
    y_pred =  model_result.forecast(steps=n_periods)
    rmse = metrics(y_test, y_pred)[0] 
    mape = metrics(y_test, y_pred)[1]
    return model, rmse


def arima(X_train, y_train, X_test, y_test):

    model = auto_arima(y_train, exogenous=X_train,
                        start_p=1, start_q=1,
                        test='adf',       # use adftest to find optimal 'd'
                        max_p=6, max_q=50, # mDaximum p and q
                        m=1,              # frequency of series
                        d=None,           # let model determine 'd'
                        seasonal=False,   # No Seasonality
                        start_P=0, 
                        D=0, 
                        trace=True,
                        error_action='ignore',  
                        suppress_warnings=True, 
                        stepwise=True)

    print(model.summary())
    # Forecast
    n_periods = len(y_test)
    y_pred, conf = model.predict(n_periods=n_periods, exogenous= X_test,return_conf_int=True)   
    rmse = metrics(y_test, y_pred)[0] 
    mape = metrics(y_test, y_pred)[1]
    return model, rmse



def plot_arima(ypred, ori_tar, conf, plot_name, pred_partial =True, norm=True):
    if norm: 
        y_pred_rev = rev_min_max_func(ypred,ori_tar)
        y_rev = rev_min_max_func(ori_tar, ori_tar)
        #     y_rev = pd.Series(y_rev, index=range(0, len(y_ori)))
        y_rev = y_rev.reset_index(drop=True)
        y_pred_rev = y_pred_rev.reset_index(drop=True)
    else:
        # y_rev = y_ori.reset_index(drop=True)
        y_rev = ori_tar
        y_pred_rev = ypred
    
    if pred_partial:
        # y_pred_rev = pd.Series(cap_array(y_pred_rev), index=range(len(ytrain),len(ori_tar)))
        y_pred_rev = pd.Series(y_pred_rev, index=range(len(ori_tar) - len(y_pred_rev),len(ori_tar)))
    else:
        y_pred_rev = pd.Series(cap_array(y_pred_rev), index = range(len(y_pred_rev)))
        # y_pred_rev = pd.Series(y_pred_rev, index = range(len(y_pred_rev)))
    y_rev = pd.Series(y_rev, index=range(len(ori_tar) - len(y_rev),len(ori_tar)))
    
    # Make as pandas series
    lower_bound = conf[:, 0]
    upper_bound = conf[:, 1]
    lower_y = y_rev * 0.95
    upper_y = y_rev * 1.05
    # Plot
    plt.plot(y_rev, color ='mediumturquoise',linewidth=3, label='ture_val', alpha =0.6)
    plt.plot(y_pred_rev, color = 'salmon', linewidth=3, label ='pred_val',marker='.', alpha = 0.7)
    plt.fill_between(range(len(ori_tar) - len(y_pred_rev),len(ori_tar)),lower_bound,upper_bound, color = 'lightsamlmon', lw = 1,linestyle = '-.', alpha = 0.15)
    plt.plot(lower_y, color = 'paleturquoise', lw = 1,linestyle = '-.', alpha = 0.4)
    plt.plot(upper_y, color = 'paleturquoise', lw = 1,linestyle = '-.', alpha = 0.4)

    plt.legend(loc='upper left', fontsize=8)
    plt.title(plot_name + ' - Forecast vs Actuals ')
    plot_dir = make_dir(os.path.join(gwd ,'plots','all_predictions/'))
    plt.savefig(plot_dir+ plot_name + '_xgboost'+'.png')
    plt.show()




# def construct_df(n_records,pred, train):
#     start_index = len(pred)
#     # predictions = [val for prediction in pred for val in prediction]
#     # train_history = [val for train_list in train for val in train_list]
#     print('length of the index: ', len(range((n_records-start_index),n_records)))
#     print('length of the y_true: ', len(train[-start_index:]))
#     print('length of the yhat: ', len(pred))
#     future_dataframe = pd.DataFrame({'index': range((n_records-start_index),n_records ),
#                                     'y_true':train[-start_index:],
#                                     'yhat': pred})
#     future_dataframe.set_index(['index'], inplace = True)
#     print(future_dataframe.head())
#     return future_dataframe



def metrics(y_true, y_pred):
    '''
    Takes in the real test data and the predcited results and calculate the predicted error 
    Returns printed metrics values (RMSE and MAPE)
    '''
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
        # scores.append(rmse) 
    return rmse, mape


# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return pd.Series(diff)
 
# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]
 
# scale train and test data to [-1, 1]
def scale(train, test):
	# fit scaler
	scaler = MinMaxScaler(feature_range=(-1, 1))
	scaler = scaler.fit(train)
	# transform train
	train = train.reshape(train.shape[0], train.shape[1])
	train_scaled = scaler.transform(train)
	# transform test
	test = test.reshape(test.shape[0], test.shape[1])
	test_scaled = scaler.transform(test)
	return scaler, train_scaled, test_scaled
 
# inverse scaling for a forecasted value
def invert_scale(scaler, X, value):
	new_row = [x for x in X] + [value]
	array = np.array(new_row)
	array = array.reshape(1, len(array))
	inverted = scaler.inverse_transform(array)
	return inverted[0, -1]

def model_run(data, model, name, plot = False):
    # X = create_nestedarr(df)
    n_records = len(X)
    rmse = list()
    mape = list()
    predictions = []
    pred_index = []
    index_start = n_train*day_cnt
    index_end = index_start + day_cnt -1
    train_set = list()
    tscv = TimeSeriesSplit()
    for train_index, test_index in tscv.split(X):       
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        print('train=%d, test=%d' % (len(X_train), len(X_test)))
        print('Starting index: {} and Ending index: {}'.format(index_start, index_end))
        prediction = model(train, test, index_start, index_end)
        
        rmse.append(metrics(test, prediction)[0])
        mape.append(metrics(test, prediction)[1])
        
        predictions.extend(prediction)
        index_start += day_cnt
        index_end += day_cnt
        pred_index.extend(range(index_start, index_end))
    print('RMSE: %.3f, MAPE: %.3f' % (np.mean(rmse),np.mean(mape)))
    if plot: 
        # print('The length of the training set {} and predictive set {} '.format(len(X), len(predictions)))
        print('The starting index of the test set: ', pred_index[0])
        # print('The type of the training set: ', type(X))
        X = pd.Series(X, index=range(len(X)))
        y_pred = pd.Series(predictions,index = pred_index)      
        plot_prediction(train_set, y_pred, name = name +'.png')
    
    return np.mean(rmse), np.mean(mape)



def evaluate_model(train, test, num_input, num_steps, num_length):
    '''
     Evaluate a model's performance by calculating the metric overal score and scores 
     within a particular window 
     Returns an overall score (a float) and a list of scores (an array contains scores withina specified data range)
    '''
    model = model_lstm(train, num_steps, num_length, num_input, loss= 'mape',epochs=20, batch_size=16, verbose=0)

    history = [data for data in train] 
    
    predictions = []
    for i in range(len(test)):
        yhat_seq = forecast(model, history, num_input)
        
        predictions.append(yhat_seq)
        
        history.append(test[i,:])
        
    predictions = np.array(predictions)
    score, scores = evaluate_forecasts(test[:,:,0], predictions)
    return score, scores

# def plot_prediction(train, y_pred, name):
#     # Plot
#     plt.style.use('fivethirtyeight')
#     # train = pd.Series(obs, index = range(len(obs)))
#     # # test = pd.Series(test, index = range(len(train), len(train)+len(test)))
#     # y_pred = pd.Series(y_pred,index = range(288*training_range[-1], 288*training_range[-1]+len(y_pred)))
#     plt.figure(figsize=(15,6), dpi=100)
#     plt.plot(train, label='observations', alpha = 0.9)
    
#     # plt.plot(test, label='actual')
#     plt.plot(y_pred, label='forecast', alpha  = 0.7)
    
#     plt.title('Forecast vs Actuals')
#     plt.legend(loc='upper left', fontsize=8)
#     # plt.xlim(0, len(obs) + len(y_pred))
#     plot_dir = make_dir(os.path.join(gwd ,'Data-1', 'evl_plots/'))
#     plot_name = name
#     plt.savefig(plot_dir+plot_name, transparent=True)
#     plt.show()

def eval_plot(predictions, name):

    X = pd.Series(X, index=range(len(X)))
    y_pred = pd.Series(predictions,index = range(n_train*day_cnt, len(X)+1))
    
    plot_prediction(X, y_pred, name = name +'.png')

def xy_split(data, y_col,reduce_dim=False, method = False, include_y = False):
    df = fill_na(data)
    # df = df.fillna(df.mean())
    df = df.select_dtypes(['number'])
    # df = df[df[y_col] != 0]
    df_len = len(df)
    
    train_x = df.copy()
    if include_y == False: 
        train_x = train_x.drop([y_col], axis = 1).reset_index(drop=True)
    train_y = df[y_col].reset_index(drop=True)
    if reduce_dim:
        if method == 'encoder':
            train_x = autoencoder(train_x, train_y, n_comp= 10)
        else:
            train_x = svd(train_x)
    # print('The first 3 columns in train_x are {}'.format(train_x.columns[:3]))
    return train_x, train_y



def get_every_n(data, label_col = 'obj_name', tar_col='y', drop_col =False, shu = True,output_df=False,impute=True,
        normalize = False, x_win = 100, y_win = 1000, reduce_dim = True, train=True, method = False, include_y=False):
    '''
    Creates the nexted data structure with all the data from 1 day to be included in a block
    Returns a new nested array
    '''
    dt = data.copy()
    
    if drop_col: 
        dt = dt.drop([drop_col], axis = 1) 
    cols = dt.select_dtypes(['number']).columns
    obj_list = dt[label_col].unique().tolist()
    if shu: 
        shuffle(obj_list)
    ys = []
    xs = []
    df_xs = []
    df_ys = []
    x_cols = []
    for obj in obj_list: 
        df = dt.loc[dt[label_col] == obj]
        df = df[cols]
        if normalize:
            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(df)
            df = scaled
        train_x, train_y = xy_split(df,tar_col, reduce_dim = reduce_dim, method = method, include_y=include_y)
        if len(train_y) >= y_win: 
            if train:
                for i in range(len(train_y)-y_win):
                    # print(i+y_win)
                    x = train_x.iloc[i:(i+x_win),:]
                    y = train_y.iloc[i+y_win-1]
                    # x = x.values.flatten()
                    # print('The shape of x is {} '.format(x.shape))
                    if reduce_dim == False: 
                        x_cols.extend([col + '_' + str(i) for col in train_x.columns])
                        df_xs.append(x)
                        df_ys.append(y)
                    else:
                        x = x.values.flatten()
                        # print('The shape of x is {}'.format(x.shape))
                        xs.append(x)
                        ys.append(y)
            else: 
                x = train_x.iloc[:x_win,:]
                y = train_y.iloc[y_win-1]
                # x = x.values.flatten()
                # print('The shape of x is {} '.format(x.shape))
                if reduce_dim == False: 
                    x_cols.extend([col for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.append(y)
                else:
                    x = x.values.flatten()
                    xs.append(x)
                    ys.append(y)
        else:
            if (len(train_x) > x_win):
                y_1 = train_y.iloc[:-100]
                y_2 = train_y.iloc[-100:]
                coeffs = np.polyfit(y_2.index, y_2, 1)
                x = range(len(train_y),y_win+1)
                y_ext = pd.Series(x * coeffs[0] + coeffs[1], index=x)
                # print('The length of y_2 after nan appending is {}'.format(len(y_ext)))
                y_2 = y_2.append(y_ext)
                y_ext = y_1.append(y_2)
                # y_ext[y_ext<0] = 0
                # print("Battery {} has {} cycles < required {} threshold".format(obj, len(train_y), y_win))
                x = train_x.iloc[:x_win,:]
                y = y_ext.iloc[y_win-1]

                if reduce_dim == False: 
                    x_cols.extend([col + '_' + str(0) for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.append(y)
                else:
                    x = x.values.flatten()
                    xs.append(x)
                    ys.append(y)   
    if reduce_dim == False: 
        df_x  = pd.concat(df_xs, axis = 1, ignore_index = True).reset_index(drop=True)
        df_x.columns = x_cols
        df_y = pd.DataFrame(df_ys, columns = ['y']).reset_index(drop=True)
        df = pd.concat([df_x, df_y], axis = 1, ignore_index = False)
        if output_df: 
            return df_x, df_y
        else:
            return df_x.values, df_y.values
    else:
        xs = np.array(xs)
        ys = np.array(ys)
        # print('\nThe shape of x is {} and the shape of y is {}\n'.format(xs.shape,ys.shape))
        return xs, ys

def get_equal_dist(data, label_col = 'obj_name', tar_col='y', drop_col =False,shu = True,output_df=False,impute=True,
        normalize = False, x_win = 100, y_win = 1000, reduce_dim = False, train=True, method = False, include_y = False):
    '''
    Creates the nexted data structure with all the data from 1 day to be included in a block
    Returns a new nested array
    '''
    dt = data.copy()
    
    if drop_col: 
        dt = dt.drop([drop_col], axis = 1) 
    cols = dt.select_dtypes(['number']).columns
    obj_list = dt[label_col].unique().tolist()
    if shu: 
        shuffle(obj_list)
    ys = []
    xs = []
    df_xs = []
    df_ys = []
    x_cols = []
    for obj in obj_list: 
        df = dt.loc[dt[label_col] == obj]
        df = df[cols]
        if normalize:
            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(df)
            df = scaled
        train_x, train_y = xy_split(df,tar_col, reduce_dim = reduce_dim, method = method,include_y= include_y)
        if len(train_y) >= y_win: 
            if train:
                for i in range(len(train_y)-y_win):
                    y_idx = np.linspace(x_win+i, y_win+i, x_win, dtype='int')
                    x = train_x.iloc[i:i+x_win,:]
                    y = train_y.iloc[y_idx-1]
                    # print('The shape of x is {} '.format(x.shape))
                    if reduce_dim == False: 
                        x_cols.extend([col + '_' + str(i) for col in train_x.columns])
                        df_xs.append(x)
                        df_ys.extend(y)
                    else:
                        # x = x.values.flatten()
                        xs.append(x.values)
                        ys.append(y)
            else:
                y_idx = np.linspace(x_win, y_win, x_win, dtype='int')
                x = train_x.iloc[:x_win,:]
                y = train_y.iloc[y_idx-1]
                if reduce_dim == False: 
                    x_cols.extend([col  for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.extend(y)
                else:
                    xs.append(x.values)
                    ys.append(y)
        else:
            if len(train_x) > x_win:
                y_idx = np.linspace(x_win+1, y_win, x_win, dtype='int')
                y_1 = train_y.iloc[:-100]
                y_2 = train_y.iloc[-100:]
                coeffs = np.polyfit(y_2.index, y_2, 1)
                x = range(len(train_y),y_win+1)
                y_ext = pd.Series(x * coeffs[0] + coeffs[1], index=x)
                # print('The length of y_2 after nan appending is {}'.format(len(y_ext)))
                y_2 = y_2.append(y_ext)
                y_ext = y_1.append(y_2)
                # y_ext[y_ext<0] = 0
                x = train_x.iloc[:x_win,:]
                y = y_ext.iloc[y_idx-1]

                if reduce_dim == False: 
                    x_cols.extend([col + '_' + str(0) for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.extend(y)
                else:
                    # x = x.values.flatten()
                    xs.append(x.values)
                    ys.append(y)   
    if reduce_dim == False: 
        if output_df: 
            df_x  = pd.concat(df_xs, axis = 1, ignore_index = True).reset_index(drop=True)
            df_x.columns = x_cols
            print('The shape of df_ys is {}'.format(np.array(df_ys).shape))
            df_y = pd.DataFrame(df_ys, columns = ['y'])
            df = pd.concat([df_x, df_y], axis = 1, ignore_index = True)
            
            return df_x, df_y
        else:
            xs = np.array([x.values for x in df_xs])
            ys = np.array(df_ys)
            # ys = np.expand_dims(ys, axis=2)
            xs = xs.reshape((-1, xs.shape[-1]))
            ys = ys.reshape((-1,))

            return xs, ys
    else:
        xs = np.array(xs)
        ys = np.array(ys)
        # # ys = np.expand_dims(ys, axis=2)
        xs = xs.reshape((-1, xs.shape[-1]))
        ys = ys.reshape((-1,))
        print('\nThe shape of x is {} and the shape of y is {}\n'.format(xs.shape,ys.shape))
        return xs, ys


def split_train_test(data, label_col='obj_name', test_prop=0.2,test_objs=False):
    obj_list = data[label_col].unique().tolist()
    if test_objs: 
        train_objs = [x for x in obj_list if x not in test_objs]
    else: 
        train_objs = obj_list[-int(len(obj_list)*(1-test_prop)):]
        test_objs = [x for x in obj_list if x not in train_objs]
    train_df = data.loc[data[label_col].isin(train_objs)]
    test_df = data.loc[data[label_col].isin(test_objs)]
    return train_df, test_df, test_objs

def add_weights(data,  tar_objs, label_col='obj_name',rep_times=5):
    print('Before extension the length of the dataframe is {}'.format(len(data)))
    rest_df = data[~data[label_col].isin(tar_objs)]
    tar_dfs = []
    for tar in tar_objs: 
        df = data[data[label_col] == tar]
        rep_df = df.select_dtypes(['number'])

        rep_df = pd.concat([rep_df]*rep_times, ignore_index=True)
        rep_df = rep_df + np.random.normal(0, 1, rep_df.shape)
        rep_df[label_col] = pd.concat([df[label_col]]*rep_times, ignore_index=True)
        tar_dfs.append(rep_df)
    tar_df =  pd.concat(tar_dfs, axis = 0, ignore_index = False)
    frame = pd.concat([rest_df, tar_df], axis = 0, ignore_index = False)
    print('After extension the length of the dataframe is {}'.format(len(frame)))
    return frame

def interpolate_w_noise(data, cols, method = 'linear'):
    '''Interpolate the missing values in the specified columns with added noise 
    Args: 
        data: the input pandas dataframe 
        cols: the specified columns to interpolate 
        method: the interpolation method 
    Returns: 
        dataframe: the interpolated dataframe
    '''
    if isinstance(cols, list):

        for col in cols: 
            data[col] = interp_single_col(data, col, method)
    return data

    
def interp_single_col(data,col, method='linear'):
    '''Interpolate a single column with added noise
    Args: 
        data: the input pandas dataframe
        col: the specified column 
        method: the interpolation method
    Returns: 
        dataframe column: interpolated column
    '''
    # Step 1: Interpolate the column with specified method 
    data[col] = data[col].interpolate(method=method, limit_direction='forward', axis=0)
    # Step 2: Add noise to the column
    data[col] = data[col] + np.random.normal(0, 1, len(data[col]))
    return data[col]



def resample_class(data, test_objs, tar_objs=[0], tar_col='chk_abn',label_col='obj_name'):
    print('Before resampling the length of the dataframe is {} and the unique labels are {}'.format(len(data), data[tar_col].unique()))
    df = data.copy()
    labs = data[tar_col].unique()
    labels = df.groupby(label_col)[tar_col].unique()
    # print(labs)
    # Sort the over-represented class to the head.
    labels = labels[labels.apply(len).sort_values(ascending=False).index]
    try:
        print('label lengths are {} and {}'.format(len(df[df[tar_col] == labs[0]]), len(df[df[tar_col] == labs[1]])))
        excess = abs(len(df.loc[df[tar_col] == labs[0],label_col].unique()) - (len(df.loc[df[tar_col] == labs[1],label_col].unique())))
    # print(excess)
    except: 

        print('label lengths are {} {} and {}'.format(len(df[df[tar_col] == labs[0]]), len(df[df[tar_col] == labs[1]]),len(df[df[tar_col] == labs[2]])))
        excess = abs(len(df.loc[df[tar_col] == labs[0],label_col].unique()) - (len(df.loc[df[tar_col] == labs[1],label_col].unique())+len(df.loc[df[tar_col] == labs[2],label_col].unique())))
    # print(excess)
    remove = np.random.choice(df.loc[df[tar_col] == tar_objs[0],label_col].unique(), excess, replace=False)
    remove = [obj for obj in remove if obj not in test_objs ]
    print('The removed rows are {}'.format(remove))

    df2 = df[~df[label_col].isin(remove)]
    print('After resampleing the sample length of all labels are {} and the unique labels are {}'.format(len(df2),df2[tar_col].unique()))

    return df2


    
def get_multi_output(data, label_col = 'obj_name', tar_col='y', drop_col =False,shu = True,output_df=False,reduce_dim=10,
        normalize = False, x_win = 100, y_win = 1000, train=True, method = False, include_y = False, impute=True):
    '''
    Creates the nexted data structure with all the data from 1 day to be included in a block
    Returns a new nested array
    '''
    dt = data.copy()
    
    if drop_col: 
        dt = dt.drop([drop_col], axis = 1) 
    cols = dt.select_dtypes(['number']).columns
    obj_list = dt[label_col].unique().tolist()
    # print('The length of the objs are {}'.format(len(obj_list)))
    if shu: 
        shuffle(obj_list)
    ys = []
    xs = []
    df_xs = []
    df_ys = []
    x_cols = []
    for obj in obj_list: 
        df = dt.loc[dt[label_col] == obj]
        df = df[cols]
        if normalize:
            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(df)
            df = scaled
        train_x, train_y = xy_split(df,tar_col, reduce_dim = reduce_dim, method = method,include_y= include_y)
        freq = (y_win - x_win)//100
        j = 0
        if len(train_y) >= y_win: 
            if train:
                for i in range(len(train_y)-y_win):
                    j += 1
                    y_idx = np.linspace(x_win+i, y_win+i, freq, dtype='int')
                    x = train_x.iloc[i:i+x_win,:]
                    y = train_y.iloc[y_idx-1]
                    # print('The shape of x is {} '.format(x.shape))
                    if reduce_dim == False: 
                        x_cols.extend([col + '_' + str(i) for col in train_x.columns])
                        df_xs.append(x)
                        df_ys.append(y)
                    else:
                        x = x.values.flatten()
                        # print('The shape of x is {}'.format(x.shape))
                        xs.append(x)
                        ys.append(y)
            else:
                j += 1
                y_idx = np.linspace(x_win+1, y_win, freq, dtype='int')
                x = train_x.iloc[:x_win,:]
                y = train_y.iloc[y_idx-1]
                if reduce_dim == False: 
                    x_cols.extend([col for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.append(y)
                else:
                    x = x.values.flatten()
                    xs.append(x)
                    ys.append(y)
        else:
            if len(train_x) > x_win:
                if train: 
                    for i in range(len(train_x)-x_win):
                        j += 1
                        y_idx = np.linspace(x_win+i, y_win, freq, dtype='int')
                        y_1 = train_y.iloc[:-100]
                        y_2 = train_y.iloc[-100:]
                        coeffs = np.polyfit(y_2.index, y_2, 1)
                        x = range(len(train_y), y_win+1)
                        y_ext = pd.Series(x * coeffs[0] + coeffs[1], index=x)
                       
                        # print('The length of y_2 after nan appending is {}'.format(len(y_ext)))
                        y_2 = y_2.append(y_ext)
                        y_ext = y_1.append(y_2)
                        # y_ext[y_ext<0] = 0
                        x = train_x.iloc[i:i+x_win,:]
                        y = y_ext.iloc[y_idx-1]
                        if reduce_dim == False: 
                            x_cols.extend([col + '_' + str(0) for col in train_x.columns])
                            df_xs.append(x)
                            df_ys.append(y)
                        else:
                            x = x.values.flatten()
                            xs.append(x)
                            ys.append(y)

                else:
                    j += 1
                    y_idx = np.linspace(x_win+1, y_win, freq, dtype='int')
                    y_1 = train_y.iloc[:-100]
                    y_2 = train_y.iloc[-100:]
                    coeffs = np.polyfit(y_2.index, y_2, 1)
                    x = range(len(train_y), y_win+1)
                    y_ext = pd.Series(x * coeffs[0] + coeffs[1], index=x)
                    # print('The length of y_2 after nan appending is {}'.format(len(y_ext)))
                    y_2 = y_2.append(y_ext)
                    y_ext = y_1.append(y_2)
                    # y_ext[y_ext<0] = 0
                    x = train_x.iloc[:x_win,:]
                    y = y_ext.iloc[y_idx-1]

                    if reduce_dim == False: 
                        x_cols.extend([col + '_' + str(0) for col in train_x.columns])
                        df_xs.append(x)
                        df_ys.append(y)
                    else:
                        x = x.values.flatten()
                        xs.append(x)
                        ys.append(y)   
                # plt.style.use('fivethirtyeight')
                # plt.style.use('ggplot')
                # plt.rcParams['font.sans-serif'] = ['SimHei']
                # plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
                # params = {'legend.fontsize': 11,
                #         'legend.handlelength': 2,
                #             'xtick.labelsize':25,
                #             'ytick.labelsize':25}
                # plt.rcParams.update(params)
                # # plt.rcParams['axes.facecolor'] = 'white'
                # plt.figure(figsize=(8,4), dpi=300)
                # plt.title(obj)
                # random_int = np.random.randint(len(antV1)-1)
                # train_y = pd.Series(train_y, index=range(len(train_y)))
                # y_ext = pd.Series(y_ext, index=range(len(train_y)-1, len(train_y)+len(y_ext)))
                # plt.plot(train_y, color = antV1[8], label = 'Original SOH',lw=2)
                # plt.plot(y_ext, color = antV1[9], label  = 'Interpolated SOH',lw=2.5)
                # plt.legend()  

    xs = np.array(xs)
    ys = np.array(ys)

    print('\nThe shape of x is {} and the shape of y is {}\n'.format(xs.shape,ys.shape))
    return xs, ys


def split_train_test(data, label_col='obj_name', test_prop=0.2,test_objs=False):
    obj_list = data[label_col].unique().tolist()
    if test_objs: 
        train_objs = [x for x in obj_list if x not in test_objs]
    else: 
        train_objs = obj_list[-int(len(obj_list)*(1-test_prop)):]
        test_objs = [x for x in obj_list if x not in train_objs]
    train_df = data.loc[data[label_col].isin(train_objs)]
    test_df = data.loc[data[label_col].isin(test_objs)]
    return train_df, test_df, test_objs

def add_weights(data,  tar_objs, label_col='obj_name',rep_times=5):
    print('Before extension the length of the dataframe is {}'.format(len(data)))
    rest_df = data[~data[label_col].isin(tar_objs)]
    tar_dfs = []
    for tar in tar_objs: 
        df = data[data[label_col] == tar]
        rep_df = df.select_dtypes(['number'])

        rep_df = pd.concat([rep_df]*rep_times, ignore_index=True)
        rep_df = rep_df + np.random.normal(0, 1, rep_df.shape)
        rep_df[label_col] = pd.concat([df[label_col]]*rep_times, ignore_index=True)
        tar_dfs.append(rep_df)
    tar_df =  pd.concat(tar_dfs, axis = 0, ignore_index = False)
    frame = pd.concat([rest_df, tar_df], axis = 0, ignore_index = False)
    print('After extension the length of the dataframe is {}'.format(len(frame)))

    return frame


def get_rc(data,label_col = 'obj_name', tar_col='CycleNo', x_win=100, reduce_dim = False, train=True, method = False, 
           normalize= False, drop_col=False,output_df=False):
    '''
        Get the number of the difference value between the value at the x_win step and 
        the last value of the target column of a given object 
    '''
    dt = data.copy()
    
    if drop_col: 
        dt = dt.drop([drop_col], axis = 1) 
    cols = dt.select_dtypes(['number']).columns
    obj_list = dt[label_col].unique().tolist()
    ys = []
    xs = []
    df_xs = []
    df_ys = []
    x_cols = []
    for obj in obj_list: 
        df = dt.loc[dt[label_col] == obj]
        df = df[cols]
        if normalize:
            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(df)
            df = scaled
        train_x, train_y = xy_split(df,tar_col, reduce_dim = reduce_dim)
    
        if train:
            for i in range(len(train_y)):
                # print(i+y_win)
                x = train_x.iloc[i:i+x_win,:]
                y = len(train_y) - train_y.iloc[i+x_win]
                # print('The shape of x is {} '.format(x.shape))
                if reduce_dim == False: 
                    x_cols.extend([col + '_' + str(i) for col in train_x.columns])
                    df_xs.append(x)
                    df_ys.append(y)
                else:
                    x = x.values.flatten()
                    xs.append(x)
                    ys.append(y)
        else: 
            x = train_x.iloc[:x_win,:]
            y = len(train_y) - train_y.iloc[x_win]
            # print('The shape of x is {} '.format(x.shape))
            if reduce_dim == False: 
                x_cols.extend([col + '_' + str(i) for col in train_x.columns])
                df_xs.append(x)
                df_ys.append(y)
            else:
                x = x.values.flatten()
                xs.append(x)
                ys.append(y)
    
    if reduce_dim == False: 
        df_x  = pd.concat(df_xs, axis = 1, ignore_index = True).reset_index(drop=True)
        df_x.columns = x_cols
        df_y = pd.DataFrame(df_ys, columns = ['y']).reset_index(drop=True)
        df = pd.concat([df_x, df_y], axis = 1, ignore_index = False)
        if output_df: 
            return df_x, df_y
        else:
            return df_xs, df_ys
    else:
        xs = np.array(xs)
        ys = np.array(ys)
        # print('\nThe shape of x is {} and the shape of y is {}\n'.format(xs.shape,ys.shape))
        return xs, ys

def construct_df(actual,pred, index):
    dataframe = pd.DataFrame([actual, pred]).T
    dataframe.columns = ['true_val', 'pred_val']
    write_csv(dataframe, 'predicted_soh_' + str(index))
    return dataframe

def dic_to_df(dict, index=False):
    if index: 
        dataframe = pd.DataFrame.from_dict(dict) 
        dataframe.index = index
    else:
        dataframe = pd.DataFrame.from_dict(dict) 
    return dataframe

def multival_dict_to_df(dic):
    dfs = []
    for key in dic.keys():
        df = pd.DataFrame(dic[key])
        df = df.transpose()
        vals = [float(df[col].dropna().values) for col in df]
        df[key+'_MAPE'] = vals
        # print(df)   
        # df = df.set_index(0)
        dfs.append(df[key+'_MAPE'])
    frame = pd.concat(dfs, axis = 1, ignore_index = False)
    # print(frame)
    return frame

def pred_run(train_df,  xwin=200, y_win=1000, reduce_dim = 10, tar_col='y', label_col = 'obj_name',cross_val=False, normalize =False, regress=False,classification=False,
            label='prediction', data_method = '1', train =True,  splits = 5,shu= True,model_name = 'best_model',method =False, multi_step=False, grid_search=False,save=True):
    start_time = time.time()

    regr = xgb = rfreg = polyreg = logitreg = logit = rfcls =knnreg = dtreereg= ''
    model_metrics = {}
    cyc_grid = {}
    model_grid = defaultdict(list)
    models_save = {}
    if grid_search: 
        xwin = np.linspace(100, 500, 5, dtype=int)

    if type(xwin) == int:
        xwin = [xwin]
    for x_win in xwin:
        print('\n----------------Testing training cycle number {}----------------\n'.format(x_win))
        
        if regress: 
            models_names = {'RandomForest_regressor':rfreg}
            models = {'RandomForest_regressor':randomforest_reg}
            # models_names = {'LinearRregression': regr,'XGBoost':xgb,'RandomForest_regressor':rfreg,'KNN_regressor':knnreg,'DecisionTree_regressor':dtreereg}
            # models = {'LinearRegression': linear_regression,'XGBoost':xgboost_reg,'RandomForest_regressor':randomforest_reg,'KNN_regressor':knn_reg,'DecisionTree_regressor':dtree_reg}
        if classification:
            # models_save = {'SVM_Classifier': svm,'Logistic_Regressor':logit,'RandomForest_Classifier':rfcls}
            models = {'SVM_Classifier': svm_cls,'Logistic_Regressor':logit_cls,'RandomForest_Classifier':randomforest_cls}
        
        if data_method == '1':
            X_train, y_train = get_every_n(train_df, tar_col=tar_col, x_win= x_win,y_win=y_win,reduce_dim=reduce_dim,train=True,normalize = normalize, method = method)
            # X_test, y_test = get_every_n(test_df, tar_col=tar_col,x_win= x_win,y_win=y_win,reduce_dim=reduce_dim, train=False,normalize = normalize, method = method)
        
        elif data_method == '2':
            X_train, y_train = get_multi_output(train_df, tar_col=tar_col, x_win= x_win,y_win=y_win,reduce_dim=reduce_dim,train=True,normalize = normalize, method = method)
            # X_test, y_test = get_every_n(test_df, tar_col=tar_col,x_win= x_win,y_win=y_win,reduce_dim=reduce_dim, train=False,normalize = normalize, method = method)

        elif data_method == '3':
            X_train, y_train = get_equal_dist(train_df, tar_col=tar_col,x_win= x_win,y_win=y_win,reduce_dim=reduce_dim, train=True,normalize = normalize, method = method)
            # X_test, y_test = get_equal_dist(test_df, tar_col=tar_col,x_win= x_win,y_win=y_win,reduce_dim=reduce_dim, train=False,normalize = normalize, method = method)
        
        if train:
            for md in models.keys():
                if cross_val:
                    r2_scores = []           
                    cv = KFold(n_splits=splits, random_state=42, shuffle=shu)
                    for train_index, test_index in cv.split(X_train):
                        X_train_cv, X_val, y_train_cv, y_val = X_train[train_index], X_train[test_index], y_train[train_index], y_train[test_index]
                        # print('The shape of X_train and y_train is {} and {}'.format(X_train_cv.shape, y_train_cv.shape))
                        models_save[md+'_'+str(x_win)], score = models[md](X_train_cv, y_train_cv, X_val, y_val)
                        r2_scores.append(score)
                    print('\nR^2 of {} model after cross validation is {}'.format(md,np.mean(r2_scores)))
                    predictions = models_save[md+'_'+str(x_win)].predict(X_val)
                    rmse = np.sqrt(np.mean((predictions - y_val) ** 2))
                    mape = np.mean(np.abs((y_val - predictions)/y_val))*100
                    model_metrics[md+'_'+str(x_win)] = float(mape)
                    print("Model {} MAPE: {:.2f}".format(md,mape))
                    if len(predictions.shape) >= 2: 
                        y_train_cv = y_train_cv.flatten() 
                        y_val = y_val.flatten()
                        predictions = predictions.flatten()
                        # predictions = limit_array(predictions)
                    # print('y_train shape is {} and predictions shape is {}'.format(predictions.shape,y_train_cv.shape))
                    
                else:
                    X_train1, X_val1 = np.nan_to_num(X_train[:int(0.8*len(X_train))]), np.nan_to_num(X_train[-int(0.2*len(X_train)):])
                    y_train1, y_val1 = np.nan_to_num(y_train[:int(0.8*len(y_train))]), np.nan_to_num(y_train[-int(0.2*len(y_train)):])
                    # print('The shape of X_train and y_train is {} and {}'.format(X_train.shape, y_train.shape))

                    models_save[md+'_'+str(x_win)], score = models[md](X_train1, y_train1, X_val1, y_val1)
                    print('\nR^2 of {} model is {}'.format(md,score))
                    predictions = models_save[md+'_'+str(x_win)].predict(X_val1)
                    if len(y_train.shape) >= 2: 
                        y_train1 = y_train1.flatten() 
                        y_val1 = y_val1.flatten()
                        predictions = predictions.flatten()
                        predictions = limit_array(predictions)
                    rmse = np.sqrt(np.mean((predictions - y_val1) ** 2))
                    mape = np.mean(np.abs((y_val1 - predictions)/y_val1))*100
                    model_metrics[md+'_'+str(x_win)] = float(mape)
                    print("Model {} MAPE: {:.2f}".format(md,mape))
                

                model_grid[md].append({x_win:float(mape)})
               
            print('The best model is {} with MAPE {} '.format(str(min(model_metrics, key=model_metrics.get)), float(min(model_metrics.values()))))
            cyc_grid[x_win] = [min(model_metrics, key=model_metrics.get), float(min(model_metrics.values()))]
    if save: 
        md_grid = multival_dict_to_df(model_grid)
        print(md_grid)
        print('\nThe number of training cycles and best MAPE dictionary is {}\n'.format(cyc_grid))
        best_model  = min(cyc_grid.items(), key=lambda x: x[1][1])[1][0]
        x_win = min(cyc_grid.items(), key=lambda x: x[1][1])[0]
        print('The best training cycle number is {} and the best prediction model is {} with  MAPE {} \n'.format(x_win, str(best_model), str(model_metrics[best_model])))
        print('Models saved dictionaryis {}'.format(models_save[str(best_model)]))
        save_model(models_save[best_model], model_name+label+'_'+str(best_model))
        print("\n---The programe took %s seconds to train ---\n" % (time.time() - start_time))
    
# if __name__ == "__main__":
#     abn_objs = ['N192642-11-47-01-15', 'N190269-23-5b-01-06', 'N192642-11-47-01-16',
#              'N192642-11-47-01-03', 'N192642-11-47-01-07','N192642-11-47-01-06', 'N192642-11-47-01-05',
#               'N190269-02-55-01-08']
# #              'N192642-11-47-01-08','N192642-11-47-01-20', 'N192642-11-47-01-19']
#     gwd = os.getcwd()
#     data_dir = os.path.join(gwd, 'phase2/','output/')
#     df = load_data('processed_pred_y.csv',data_dir, set_index=0)
#     df = df.drop(df.columns[0], axis =1)
#     df = df.dropna(axis=1, how='all')
#     # df = df.select_dtypes(['number'])
    
#     #downsampling
#     data_res = resample_class(df, abn_objs)
#     #upsampling 
#     # data_ext = add_weights(data, abn_objs, rep_times=5)
#     train, test, test_objs = split_train_test(data_res)
#     # X_train, y_train = get_multi_output(train, drop_col ='chk_abn',x_win= 300,y_win=1000,reduce_dim=10, train=True)
#     # X_test, y_test = get_multi_output(test, drop_col ='chk_abn',x_win= 300,y_win=1000,reduce_dim=10, train=False)
#     pred_df = pred_run(train, test,test_objs,  data_method = '2', 
#                     regress=True,grid_search=True,multi_step = True
#                    )
#     print(pred_df)
    
    
