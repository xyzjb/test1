# -*- coding: utf-8 -*-
"""
Created 2021-05-18
@author: haohan.wang
@desc: methods of features engineering
"""
import time
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
import logging
import numpy as np
from numpy.core.arrayprint import DatetimeFormat
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os
import time
from sklearn import ensemble
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import matplotlib
import pylab
import seaborn as sns
from core.abd import anomaly_detection 
from statsmodels.tsa.seasonal import seasonal_decompose
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import StandardScaler
from sklearn import preprocessing
import matplotlib.colors as colors
from matplotlib.ticker import StrMethodFormatter
import re
from sklearn.preprocessing import MinMaxScaler
import pickle
from scipy import stats
from sklearn.cluster import KMeans
# from sklearn.externals import joblib
from sklearn.linear_model import LinearRegression
from sklearn import  tree, linear_model
from sklearn.metrics import mean_squared_error
import statsmodels.api as sm
from statsmodels.tools.eval_measures import rmse
from sklearn.metrics import explained_variance_score
import xgboost
from sklearn.model_selection import train_test_split
from random import shuffle
from sklearn.model_selection import TimeSeriesSplit
from sklearn.feature_selection import RFE
from sklearn.linear_model import RidgeCV, LassoCV, Ridge, Lasso
from sklearn.model_selection import KFold # import KFold
from scipy.signal import butter, lfilter, freqz
from statsmodels.nonparametric.smoothers_lowess import lowess
from sklearn import gaussian_process
from sklearn.gaussian_process.kernels import Matern, WhiteKernel, ConstantKernel
from sklearn.tree import DecisionTreeClassifier
from sklearn.decomposition import TruncatedSVD
from sklearn.random_projection import GaussianRandomProjection
from numpy.linalg import *
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn import svm
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import auc
from sklearn.neighbors import KNeighborsRegressor
from scipy import interpolate
from sklearn.tree import DecisionTreeRegressor
from sklearn.multioutput import MultiOutputRegressor
import joblib
logger = logging.getLogger(__name__)
# matplotlib.font_manager._rebuild()
np.random.seed(23)
gwd = os.getcwd()
# from sarima import * 
pd.set_option('max_rows', 50)
pd.set_option('max_columns', 50)
params = {'legend.fontsize': 'x-large',
          'figure.figsize': (15, 12),
         'axes.labelsize': 'xx-large',
         'axes.titlesize':'xx-large',
         'xtick.labelsize':'xx-large',
         'ytick.labelsize':'xx-large'}
pylab.rcParams.update(params)
antV = ['#ff4d4f','#13c2c2','#f759ab','#fadb14','#531dab','#1890FF', '#2FC25B', '#FACC14', '#223273', '#8543E0', 
         '#3436c7', '#F04864','salmon','#a0d911','#722ed1','#eb2f96','#1d39c4','#bfbfbf'] 

antV1= ['#5B8FF9','#BDD2FD','#5AD8A6','#BDEFDB','#5D7092','#C2C8D5','#F6BD16','#FBE5A2',
        '#E8684A','#F6C3B7','#6DC8EC','#B6E3F5','#9270CA','#D3C6EA','#FF9D4D','#269A99',
        '#AAD8D8','#FF99C3','#FFD6E7']
sns.set(font_scale = 1)
def colormap():
    # 设置颜色主题
    cdict = ['#13c2c2','#f5222d']
    return colors.ListedColormap(cdict, 'indexed')
def singlecolor():
    cdict = ['#13c2c2']
    return colors.ListedColormap(cdict, 'indexed')
my_cmap = colormap()
single_cmap = singlecolor()
# Laod data [csv or excel]

holiday =['2018-09-22','2018-09-23','2018-09-24','2018-10-01','2018-10-02','2018-10-03',
          '2018-10-04','2018-10-05','2018-10-06','2018-10-07','2018-12-30','2018-12-31',
          '2019-01-01','2019-02-04','2019-02-05','2019-02-06','2019-02-07','2019-02-08',
          '2019-02-09','2019-02-10','2019-04-05','2019-04-06','2019-04-07','2019-05-01',
          '2019-06-07','2019-06-08','2019-06-09','2019-09-13','2019-09-14', '2019-09-15',
          '2019-10-01','2019-10-02','2019-10-03','2019-10-04','2019-10-05','2019-10-06','2019-10-07']   
         
work_day = ['2019-02-03','2019-02-02','2018-02-11','2018-02-24','2018-04-08','2018-04-28','2018-09-29',
            '2018-09-30','2019-09-29','2019-10-12']   

lasso_eps = 0.0001
lasso_nalpha=20
lasso_iter=100

degree_min = 2
degree_max = 3

def load_csv(filename, skiprows, set_index=False):
    '''
        Load csv file given a directory 
        Return a dataframe
        **Optional encode method: gbk**
    '''
    if set_index:
        try: 
            return  pd.read_csv(filename,infer_datetime_format=True, encoding= 'utf-8-sig',  skiprows=skiprows,error_bad_lines=False, index_col=set_index)

        except: 
            return  pd.read_csv(filename,infer_datetime_format=True, encoding= 'iso-8859-1', skiprows=skiprows,error_bad_lines=False, index_col=set_index)
    else: 
        try: 
            return  pd.read_csv(filename,infer_datetime_format=True, encoding= 'utf-8-sig',  skiprows=skiprows,error_bad_lines=False)

        except: 
            return  pd.read_csv(filename,infer_datetime_format=True, encoding= 'cp932', skiprows=skiprows,error_bad_lines=False)


def load_excel(filename, sheet_name):
    '''
    Loads the data into pandas dataframe from specified directory 
    Returns pandas dataframe
    '''
    df = pd.read_excel(filename,sheet_name = sheet_name)
    return df


def load_data(filename, input_dir=False, set_index = False, sheet_name = 'Sheet1', skiprows=0):
    '''
     Determine the type of the input file and choose the right function to read the input data
     Return a loaded dataframe 

    Args: 
        - filename: input file filename 
    
    '''
    gwd = os.getcwd()
    # try:
    if input_dir: 
        filename = os.path.join(gwd, input_dir, filename)
    else:
        try:
            filename = os.path.join(gwd, filename)
        except:
            pass
    # print('the last 4 digits of the filename {}'.format(filename[-4:]))
    if 'csv' in filename[-4:]:
        df = load_csv(filename, skiprows, set_index)
        return df
    elif 'xls' in filename[-4:]:
        df = load_excel(filename,sheet_name)
        return df
    # except Exception as e:
    #     print(e)
    #     pass

# Add sub-colname
def add_shift(data, cols, n_in=1, n_out=0, dropcol=True, concat=True):
    agg = pd.DataFrame(data[cols], columns = cols) 
    for i in range(n_in, n_out, -1):      
        for col in cols: 
            agg[col+'(t'+str(-i)+')'] = agg[col].shift(i)
    if dropcol:
        agg.drop(agg.columns[range(0,len(cols))], axis= 1, inplace = True)
    if concat: 
        df = pd.concat([data, agg], axis =1)
    return df

def add_subcolname(df,colnames = False):

    if colnames == False:
        df.columns = pd.MultiIndex.from_arrays([df.columns, range(1,len(df.columns)+1)], 
                                       names=('NAME','IDX'))
    else: 
        df.columns = pd.MultiIndex.from_arrays([df.columns, colnames], 
                                       names=('NAME','IDX'))
    return df

# Add label to dataframe
def create_dict(df, col1, col2):
    '''
        Create a values mapping dictionary from 2 columns in a dataframe
        Return a dictionary with the keys from one column and values fromt the other column 
    '''
    label_dic = pd.Series(df[col2].values,index=df[col1]).to_dict()
    return label_dic

def add_label(df1, df2, col1, col2, label_col='label'):
    '''
        Add the label column to the other dataframe based on the value mapping dictionary
        Return a dataframe with new added label column
    '''
    labels = create_dict(df2,col1, col2)
    df1[label_col] = df1[col1].map(labels)
    df1[label_col] = df1[label_col].astype('category')

    return df1


# Data Resamplig 
def set_index(df, index_col):
    '''
        Set a specific columns as index 
        Return a dataframe with the set index
    '''
    # print('The columns in the dataframe are {}'.format(df.columns))
    df = df.set_index(pd.DatetimeIndex(df[index_col]))
    try: 
        df = df.drop(index_col, axis = 1)
    except:
        pass
    # print(df.head())
    return df

def resampling(df, freq, scale_type):
    '''
        Resample the data with the given frequency 
        Return a resampled datafame 

        Args: 
            - df: input dataframe
            - freq: the specified frequency i.e. 'D' or 'H'
            - scale_type: either up or down [if it is 'up' then the data processing method will be sum,
                                            if it is 'down' then the data processing method will be mean]
    '''
    df.inex = df.to_datetime(df.index)
    if scale_type == 'down':      
        df = df.resample(freq).sum()
    else: 
    # TODO: upsampling filling rule
        df = df.resample(freq)
        # Solution 1: interpolate it with the best time series interpolation method
        df = ts_interpolation(df)
        # Solution 2: interpolate it with moving average
        #df = df.assign(RollingMean=df.target.fillna(df.target.rolling(freq,min_periods=1,).mean()))
    return df 

# Convert data into numeric
def convert_numeric(df, drop_cols=False):
    if drop_cols:
        df_sub = df[drop_cols]
        try:
            cols = df.drop([drop_cols], axis=1).columns
        except:
            cols = df.drop(drop_cols, axis=1).columns
    else:
        cols = df.columns
    for col in cols: 
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(9999).astype(float)
    df = df.replace(9999, np.nan)
    if drop_cols:
        df[drop_cols] = df_sub
#     print(df)
    return df

# Missing data Imputation 
def basic_fill(df, day_cnt, method = 'ffill'):
    '''
     Fill the missing data with the baisc missing data filling method 
     Returns a filled dataframe

     Args: 
        - df: input dataframe 
        - method: the data filling method
    '''
    df = df.dropna(axis=1, how='all') 
    if method == 'drop':
        data = df.copy()
        data.dropna()
        return data
    else:
        
        # if df.isnull().sum().all() != 0:
        df = fill_seasonal(df,day_cnt)
        # df = ts_interpolation(df)
        df = df.fillna(method = method)
           
        logger.info('Missing data is filled')
        return df

def fill_seasonal(df, day_cnt, lookback='day'):
    '''
        Fill the data based on the specified lookback window size
        Returns a filled dataframe

        Args: 
            - df: input dataframe
            - lookback: lookback window size ['day' or 'week' or 'mix']
    '''
    for col in df.columns: 
        values = df[col].values
        if lookback == 'week':          
            try:
                df[col] = df[col].fillna(df[col].shift(7*day_cnt)) 
            except: 
                df[col] = df[col].fillna(df[col].shift(-7*day_cnt))

        elif lookback == 'day':
            try:
                df[col] = df[col].fillna(df[col].shift(day_cnt)) 
            except: 
                df[col] = df[col].fillna(df[col].shift(-day_cnt))
    if df.isnull().sum().all() != 0:
        df = df.ffill()
    return df 


def ts_interpolation(data):
    '''
        Fill the data by comparing a set of time series interpolation methods
        Reutnr a interpolated dataframe 

        Args:
            - df: initial dataframe
    '''
    df = data.copy()
    
    for name in df.columns: 
        try:
            df[name+'_ref'] = df[name].fillna(df[name].mean())        

            ind = df.index
            df[name] = pd.Series(df[name])
            df.index = pd.to_datetime(df.index)
            df = df.assign(InterpolateLinear=df[name].interpolate(method='linear'))
            df = df.assign(InterpolateTime=df[name].interpolate(method='time'))
            df = df.assign(InterpolateQuadratic=df[name].interpolate(method='quadratic'))
            df = df.assign(InterpolateCubic=df[name].interpolate(method='cubic'))
            df = df.assign(InterpolateSLinear=df[name].interpolate(method='slinear'))
            df = df.assign(InterpolateAkima=df[name].interpolate(method='akima'))
            df = df.assign(InterpolatePoly5=df[name].interpolate(method='polynomial', order=5)) 
            df = df.assign(InterpolatePoly7=df[name].interpolate(method='polynomial', order=7))
            df = df.assign(InterpolateSpline3=df[name].interpolate(method='spline', order=3))
            df = df.assign(InterpolateSpline4=df[name].interpolate(method='spline', order=4))
            df = df.assign(InterpolateSpline5=df[name].interpolate(method='spline', order=5))
            missing_cnts = [df[method].isnull().sum() for method in list(df.columns)[2:]]
            # print('After interpolation the number of missing values are {}'.format(missing_cnts))
            results = [(method, r2_score(df[name+'_ref'], np.nan_to_num(df[method]))) for method in list(df.columns)[2:]]
            results_df = pd.DataFrame(results, columns=['Method', 'R_squared'])
            results_df.sort_values(by='R_squared', ascending=False)
            # print(results_df)
            best_method = results_df.loc[results_df['R_squared'].idxmax(), 'Method']
            # print('The best interpolation method {}'.format(str(best_method)))
            df.index = ind
            df[name] = df[str(best_method)]
        except:
            pass
    return df

def fill_na(df, drop_ratio = 0.8):
    '''
    fill missing values in dataframe
    and drop timestamp not continuous records
    return fixed dataframe
    '''
    # todo improve filling methods like using same period value or interpolation
    # for df in user_data_list:
    data = df.copy()
    
    # data = data.loc[:, data.isnull().mean() < drop_ratio]

    data = data.ffill()
    # print(data.isna().sum())
    data.fillna(0, inplace=True)
    return data
    
def drop_zero(data,how='all'):
    '''
        Drop the column with all zeros
    '''
    data = data.replace(0,np.nan).dropna(axis=1,how=how)
    return data

# Outlier Detection and Replace them with the mean of the column
def a_d(data, k=False, col=False, plot=True, method = 'isolation_forest'):
    '''
     Detect the anomaly with specified method and replace them with the mean value of the 14 periods around the date
     Return a dataframe of marked anomalies

    Args: 
        - data: input dataframe
        - replace: 
    '''
    df = data.copy()
    if isinstance(data, pd.DataFrame):
        df = df.select_dtypes(['number'])
    # df = np.nan_to_num(data)
    df = df.astype('float')
    after_ad = anomaly_detection(df, col, k, plot,method)
    return after_ad

def replace_anomaly(data, k = False, col = False,  plot=False, method = 'LOF'):
    ''' 
        Replace the labeled anomalies with the mean of the column 
        Return a dataframe after the replacement 

        Args: 
            - df: input dataframe
    '''
    # TODO Replace with MOVING AVERAGE FILL 
    # df = df.assign(RollingMean=df.target.fillna(df.target.rolling(freq,min_periods=1,).mean()))
    # print('The anomaly detection method is {}'.format(method))
    df = data.copy()
    ori_index = df.index
    df = df.fillna(method = 'bfill').reset_index(drop=True)
    after_ad = a_d(df, col, k, plot, method = method)
    if isinstance(data, pd.Series):
        indices = [i for i, x in enumerate(after_ad) if x == 1]
        df.loc[indices] = np.nan
        # rep_list = [np.nan if (val == 1) else df[i] for i, val in enumerate(after_ad)]
        rep_col = df.interpolate(method='linear')
        rep_col.index = ori_index
        return rep_col
    elif isinstance(data, pd.DataFrame):
        df = df.select_dtypes(['number'])
        # df = fill_na(df).reset_index(drop=True)       
        if col: 
            df[col] = [np.nan if (val == 1) else df[col].loc[i] for i, val in enumerate(after_ad[col])]
            # rep_col = pd.Series(rep_list)
            try:
                df['roll50'] = df[col].rolling(50,center=True,min_periods=1).mean()
                df['update'] = df['roll50']
                df['update'].update( df[col] )
                del df['roll50']
                del df['update']
                return df[col]
            except:
                return df[col].interpolate(method='linear')
        else:
            for col in df.columns:          
                # df[col] = [np.mean(df[col][i-7:i+7]) if (val == 1) else df[col][i] for i, val in enumerate(after_ad[col])]
                indices = [i for i, x in enumerate(after_ad) if x == 1]
                df.loc[indices,col] = np.nan
                try:
                    df['roll50'] = df[col].rolling(50,center=True,min_periods=1).mean()
                    df['update'] = df['roll50']
                    df['update'].update( df[col] )
                    del df['roll50']
                    del df['update']
                except:
                    df[col] = df[col].interpolate(method='linear')
                
                # df[col] = [df[col].rolling(30,min_periods=1,).mean() if (val == 1) else df[col].loc[i] for i, val in enumerate(after_ad[col])]
            logger.warning('Replaced anomalies detected with {} method'.format(method))
            # after_df = a_d(df, col, plot, method = method)
            # return df[~df.index.duplicated(keep='last')]
            df.index = ori_index
            return df


def drop_abnormal(user_data_list):
    '''
    drop records having abnormal values
    return fixed dataframe
    '''
    # todo
    # abnormal data include points out of distribution and continous values keep same
    logger.warning('%s not implement' % drop_abnormal.__name__)

# Discretize label columns and value column 
def discretize_columns(df, val_col, col_name):
    '''Convert a categorical columns into seperate columns with corresponding values
    Args: 
        df: the input pandas dataframe
        col_pair: the column pair with the category name and values 
    Returns: 
        The dataframe after converting and merging 
    '''
    df_pivot = df.pivot_table(values= val_col, index=df.index, columns=col_name, aggfunc='first')
    df = df.join(df_pivot)
    df = df.drop([val_col, col_name], axis =1 )
    return df

# Feature Generation 
def add_features(df):
    # print('The first time index: ',df.index[0].date())
    try: 
        df.index = pd.to_datetime(df.index)
    except: 
        raise 'The index column is not in the right datetime format'

    df['day_of_week'] = df.index.dayofweek
    df['month_of_year'] = df.index.month
    if holiday: 
        df['holiday'] = [1 if str(val.date()) in holiday else 0 for val in df.index]
    if work_day: 
        df['weekday_weekend'] = [1 if (val in [0,6]) and (str(df.index[i].date()) not in work_day)  else 0 for i, val in enumerate(df['day_of_week'])]
    try:
        df['hour_of_day'] = df.index.hour
    except: 
        pass
    # Seasonal Effect
    df['season_of_year'] = pd.cut(x=df['month_of_year'], bins=[2, 5, 9, 11, 12],labels=['1', '2', '3','4'])
    df['season_of_year'] =  df['season_of_year'].fillna('4')
    logger.info('New features are added')
    return df

#Feature Selection 
def feature_importance(df, y_col, thresh = 10, plot=True, keep_top = False, plot_name = ' - y'):
    '''
    Train the model with xgboost and plot the importance of each feature 
    Return the dataframe with only the top x features and predictor

    Args: 
        - df: input dataframe
        - thresh: the number of top features
        - plot: True or False [if True, return a feature importance plot]
    '''
    gwd = os.getcwd()
    data = df.dropna()
    if isinstance(data, pd.DataFrame):
        data = data.select_dtypes(['number'])
    else: 
        data = data.astype(float)
    y = data[y_col].values
    df = data.copy()
    df.drop([y_col], axis=1, inplace=True)
    X = df.values

    offset = int(X.shape[0] * 0.9)
    X_train, y_train = X[:offset], y[:offset]
    X_test, y_test = X[offset:], y[offset:]

    # fit model no training data
    params = {'n_estimators': 500, 'max_depth': 4, 'min_samples_split': 2,
          'learning_rate': 0.01, 'loss': 'ls'}
    clf = ensemble.GradientBoostingRegressor(**params)

    clf.fit(X_train, y_train)
    feature_importance = clf.feature_importances_
    feature_importance = 100.0 * (feature_importance / feature_importance.max())

    if len(df.columns)  < thresh: 
        thresh = len(df.columns) 
    sorted_idx = np.argsort(feature_importance)[:thresh]
    pos = np.arange(sorted_idx.shape[0]) + .5
    logger.info('feature selection')
    import_features =  [df.columns[idx] for idx in sorted_idx]
    # print('Important features are {}'.format(import_features))
    if plot: 
        plt.style.use('ggplot')
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

        plt.figure(figsize=(15,6), dpi=100)
        plt.barh(pos, feature_importance[sorted_idx], align='center')
        plt.yticks(pos, df.columns[sorted_idx],fontsize=12)
        plt.xticks(fontsize=12)
        plt.xlabel('Relative Importance',fontsize=10)
        plt.title('Features Importance'+plot_name,fontsize=15)
        plot_dir = make_dir(os.path.join(gwd , 'plots/','feature_importance/'))

        plt.savefig(plot_dir+ plot_name + '_feature_importance.png',transparent=False)
        plt.show()   
    if keep_top:
        selected_df = pd.concat([data[y_col], data[import_features]], axis = 1)
        return selected_df
    if keep_top == False: 
        print('The top features are {}'.format(import_features))
        logger.info('The top features are {}'.format(import_features))
        return data

def drop_corr_cols(df, thresh = 0.95):
    '''
        Calculate the correlation matrix and drop the features that are highly correlated
    '''
    # Create correlation matrix
    corr_matrix = df.corr().abs()

    # Select upper triangle of correlation matrix
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

    # Find features with correlation greater than 0.95
    to_drop = [column for column in upper.columns if any(upper[column] > thresh)]

    df.drop(to_drop, axis=1, inplace=True)
    return df

# Feature Engineer

def normalization(df):
    '''
        Normalize the data in a dataframe 
    '''
    result = df.copy()
    if isinstance(df, pd.DataFrame):
        result = result.select_dtypes(['number'])
    for feature_name in result.columns:
        max_value = float(df[feature_name].max())
        min_value = float(df[feature_name].min())
        result[feature_name] = (df[feature_name] - min_value) / (max_value - min_value)
    return result

def adf_test(data):
    df = data.select_dtypes(['number'])
    df_nor = normalization(df)
    col_adf = {}
    cols = df.columns
    for col in cols: 
        col_adf[col] = adfuller(df_nor[col])[1]
    stationary_cols = [k for k,v in col_adf.items() if float(v) < 0.001]
    print('The columns that are stationary are {}'.format(stationary_cols))
    return col_adf 

# All featurs Plot
def plot_multi_col(data,x_col, y_col,cyc_col='CycleNo', cycle_list=False, plot_name = ''):
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(12,8), dpi=300)
    plot_name = plot_name + ' '+ str(y_col) +' & '+ str(x_col) +' Plot'
    if cycle_list: 
        palette = dict(zip(cycle_list,sns.color_palette("PiYG_r", len(cycle_list))))
        for cyc in cycle_list:
            draw_df = data.loc[data[cyc_col] ==  cyc].reset_index(drop=True)    
            draw_df[cyc_col] = draw_df[cyc_col].astype(int)
            # sns.scatterplot(x=x_col, y=y_col, data=draw_df,palette=palette)
            sns.lineplot(x_col, y_col,
                             hue=cyc_col, 
                             palette=palette,
                             data=draw_df,lw=0.5,
                             legend='brief')
    else:
        try:
            palette= antV1
            sns.lineplot(x_col, y_col,
                                hue=cyc_col, 
                                palette=palette,
                             data=data,lw=0.5,
                             legend='brief')
        except: 
            sns.lineplot(x_col, y_col,
                                hue=cyc_col, 
                             data=data,lw=0.5,
                             legend='brief')
    plt.title(plot_name)
    plot_dir = make_dir(os.path.join(gwd ,'plots','scatter_plots/'))
    plt.savefig(plot_dir + plot_name+'.png')
    plt.show()



def plot_df(data, subplots = True, plot_name='', num_col=20, turning_col=False):
    '''
        Generate and save the line plots of all features in a dataframe
    '''
    df = data.copy()
    if isinstance(df, pd.DataFrame):
        data = data.select_dtypes(['number'])
    
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 11,
      'legend.handlelength': 2,
         'xtick.labelsize':25,
        'ytick.labelsize':25}
    plt.rcParams.update(params)
    plt.figure(figsize=(15,12), dpi=300)
    plotname = plot_name + ' Feature Line Plot'
    if num_col: 
        df = df.iloc[:,:num_col]
    if subplots: 
        df.plot(kind='line',color = antV1, figsize=(16,10),lw = 2, 
             title= plotname, subplots=True, alpha =0.8)
    else:
        try:
            df_nor = normalization(df)
        except:
            df_nor = df
        df_nor.plot(kind='line',color = antV1, figsize=(16,10),lw = 2, 
             title=plot_name, subplots=False, alpha =0.8)
    if turning_col: 
        turning_idx = turningpoints(df[turning_col])
        # for idx in turning_idx:
        plt.axvline(turning_idx, color='tomato',linestyle='--', alpha = 0.8)
    plt.xticks(fontsize=20, rotation=45)
    # plt.yticks(fontsize=20, rotation=45)
    plt.ylabel('MAPE ')
    plt.xlabel('Input Cycle No.')
    plot_dir = make_dir(os.path.join(gwd ,'plots','feature_plot/'))

    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()

def plot_col(col,plot_name='', v_lines=[]):
    data = col.copy()
    if not isinstance(data, pd.Series):
        data = pd.Series(col)
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 10})
    params = {'legend.fontsize': 10,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(10,3), dpi=300)
    plotname = plot_name + ' Feature Line Plot'
    random_int = np.random.randint(len(antV1))
    data.plot(kind='line',color = antV1[random_int], figsize=(10,3),lw = 2, 
            title= plotname, subplots=True, alpha =0.7)   
    if len(v_lines) > 0 : 
        for idx in v_lines: 
        # turning_idx = turningpoints(df[turning_col])
        # for idx in turning_idx:
            plt.axvline(idx, color='tomato',linestyle='--', alpha = 0.7)
    plt.xticks(fontsize=10, rotation=45)
    # plt.yticks(fontsize=20, rotation=45)
    plot_dir = make_dir(os.path.join(gwd ,'plots','feature_plot/'))
    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()

def plot_bar(data, x_col, label_col, hue_col=False, palette='Set2'):
    df = data.copy()
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    
    plt.figure(figsize=(18, 10), dpi = 300)
    sns.set(font_scale=1.2)
    if hue_col:
        try: 
            df_sub = df[[x_col, label_col, hue_col]]
            df_sub.set_index(hue_col)\
            .reindex(df_sub.set_index(hue_col).sum().sort_values().index, axis=1)\
            .T.plot(kind='bar', stacked=True,
                    colormap=palette, 
                    figsize=(12,6))
                    
        except: 
            sns.catplot(x=x_col, col=label_col,
                    hue=hue_col, palette=palette,
                    # palette=sns.color_palette(antV),
                    data=df, kind="count",
                    height=6, aspect=1, 
                    capsize=.2, alpha = 0.6)
    else:
        sns.catplot(x=x_col, col=label_col,
                  palette=palette,
                # palette=sns.color_palette(antV),
                data=df, kind="count",
                height=6, aspect=1, 
                capsize=.2, alpha = 0.6)

    # plt.title(hue_col + ' Distribution Checkup across - ' + label_col)
    plot_dir = make_dir(os.path.join(gwd ,'plots','bar_plots/'))
    plot_name = label_col
    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()


def plot_dis(data, plot_name='',num_col= 20, subplot=True, col = False, log=False):
    '''
        Generate and save the distribution plots of all features in a dataframe
    '''
    df = data.copy()
    df = fill_na(df).dropna()
    if isinstance(df, pd.DataFrame):
        df = df.select_dtypes(['number'])
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    if num_col: 
        # print('Subset the dataset')
        df = df.iloc[:,-num_col:]
    # print('The number of columns in dataframe is {}'.format(len(df.columns)))
    plt.rcParams.update(params)
    sns.set(font_scale=1)
    df = df.astype(float)
    try:
        if col: 
            plt.subplots(figsize=(12, 4), dpi = 300)
            if log: 
                sns.distplot(np.log(df[col]), kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(6%len(antV))], label =col)
            else: 
                sns.distplot(df[col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(6%len(antV))], label =col)
            plot_name = col
        else:       
            if subplot: 
                plt.subplots(figsize=(12, int(len(df.columns)*1.5)), dpi = 300)
                for i, col in enumerate(df.columns):
                    plt.subplot(len(df.columns),1,i+1)
                    plt.subplots_adjust(hspace = 1.5)
                    if log: 
                        sns.distplot(np.log(df[col]), kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(i%len(antV))],label=col)
                    else: 
                        sns.distplot(df[col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(i%len(antV))],label=col)
            else: 
                plt.subplots(figsize=(12, 4), dpi = 300)
                for i, col in enumerate(df.columns):
                    df_nor = normalization(df)
                    if log:
                        sns.distplot(np.log(df.iloc[:,i]), kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(i%len(antV))],label=col)
                    else: 
                        sns.distplot(df_nor.iloc[:,i], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(i%len(antV))], label=col)
            plot_name = 'All Features ' + plot_name
    except:
        pass
    plt.legend(bbox_to_anchor=(1.2, 1.05), loc='upper right', ncol=1, prop={'size': 10})
    plot_dir = make_dir(os.path.join(gwd ,'plots','feature_dis/'))
    plt.title(' Feature Distribution Plot - ' + plot_name)
    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()

def plot_decomp(data, col, freq, plot_name='feature_seasonal_decomp'):
    '''
        Generate and save the time series decomposition plots for a specific feature in a dataframe
    '''
    df = data.copy()
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    # plt.rcParams.update(params)
    # plt.figure(figsize=(18,12), dpi=300)
   
        
    df.index = pd.to_datetime(df.index)
    result = seasonal_decompose(df[col].astype(float), model='multiplicative', freq=freq)
    # result.plot()
    
    
    fig, (ax1,ax2,ax3) = plt.subplots(3,1, figsize=(15,8),dpi=300)
    
    result.trend.plot(ax=ax1,label = 'trend', color = antV[int(2%len(antV))], lw = 3, alpha = 0.7)
    # plt.legend()
    plt.title('Seasonal Decomposition - ' + col)
    result.resid.plot(ax=ax2,label = 'residual', color = antV[int(4%len(antV))], lw = 3, alpha = 0.7)
    # plt.legend()
    result.seasonal.plot(ax=ax3,label = 'seasonal', color = antV[int(6%len(antV))], lw = 3, alpha = 0.7)
    
    plt.legend()
    # plt.axis('off')
    plot_dir = make_dir(os.path.join(gwd ,'plots','ts_decomp/'))
    plt.savefig(plot_dir+ 'seasonal_decomp ' + col +'.png')
    plt.show()

def plot_pair(data, plot_name='feature_pair',num_col=7):
    '''
        Generate and save the pair grid plot of all features in a dataframe
    '''
    gwd = os.getcwd()
    df = data.copy()
    if isinstance(df, pd.DataFrame):
        df = df.select_dtypes(['number'])
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    if num_col: 
        df = df.iloc[:,:num_col]
    # plt.rcParams.update(params)
    plt.figure(figsize=(15,12), dpi=300)
    sns.pairplot(df,palette="husl",  diag_kind="kde")
    plt.title('Features Pair plot')
    plot_dir = make_dir(os.path.join(gwd ,'plots','feature_pair/'))

    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()

def plot_cm(y_true, y_pred, figsize=(10,10)):
    cm = confusion_matrix(y_true, y_pred, labels=np.unique(y_true))
    cm_sum = np.sum(cm, axis=1, keepdims=True)
    cm_perc = cm / cm_sum.astype(float) * 100
    annot = np.empty_like(cm).astype(str)
    nrows, ncols = cm.shape
    for i in range(nrows):
        for j in range(ncols):
            c = cm[i, j]
            p = cm_perc[i, j]
            if i == j:
                s = cm_sum[i]
                annot[i, j] = '%.1f%%\n%d/%d' % (p, c, s)
            elif c == 0:
                annot[i, j] = ''
            else:
                annot[i, j] = '%.1f%%\n%d' % (p, c)
    cm = pd.DataFrame(cm, index=np.unique(y_true), columns=np.unique(y_true))
    cm.index.name = 'Actual'
    cm.columns.name = 'Predicted'
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(cm, cmap= "PiYG_r", annot=annot, fmt='', ax=ax)

def plot_corr(data, num_col = False, top_corr = 0.8, plot_name=''):
    '''
    Plot the heatmap given a dataframe 
    '''
    df = data.select_dtypes(['number'])
    if num_col: 
        df = df.iloc[:,:num_col]
    corr = df.corr()
    if top_corr: 
        corr = corr[corr>=top_corr]
    # mask = np.zeros_like(corr)
    # mask[np.triu_indices_from(mask)] = True
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(15,12), dpi=300)
    xticks = df.columns
    sns.heatmap(corr, cmap="PiYG_r",  xticklabels=xticks, yticklabels=xticks,linewidths=.5)
    plt.yticks(rotation=30) 
    plt.xticks(rotation=30)

    plt.title(plot_name + 'Features Correlation')
    plot_dir = make_dir(os.path.join(gwd ,'plots','feature_corr/'))
    title = plot_name + 'missing_heatmap'
    plt.savefig(plot_dir+ title+'.png')
    plt.show()

def plot_missingmap(data,  num_col = 30, num_row = 100, plot_name='missing_heatmap',):
    '''
    Plot the heatmap given a dataframe 
    '''
    df = data.select_dtypes(['number'])
    if num_col: 
        df = df.iloc[:num_row,:num_col]
    else:
        df = df.iloc[:num_row, :]
    missing_df = df.isnull()
    
    gwd = os.getcwd()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(15,12), dpi=300)
    xticks = df.columns
    if df.isnull().values.any():
        sns.heatmap(missing_df, cmap=my_cmap,  xticklabels=xticks, linewidths=.5)
    else:
        sns.heatmap(missing_df, cmap=single_cmap,  xticklabels=xticks, linewidths=.5)
    plt.yticks(rotation=30) 
    plt.xticks(rotation=30)
    title = plot_name + 'missing_heatmap'
    plt.title(plot_name + ' Missing Data Heatmap')
    plot_dir = make_dir(os.path.join(gwd ,'plots','missing_val/'))

    plt.savefig(plot_dir+ title+'.png')
    plt.show()

def count_sparse_matrix(data):
    matrix_x = data.iloc[:,:-2]
    # matrix_x.head()
    # matrix['溶剂2'].value_counts()
    count_df = pd.DataFrame(matrix_x.sum()).T
    long_df = pd.melt(count_df)
    long_df.columns = ['Variable','Count']
    long_df = long_df.sort_values(['Count']).reset_index(drop=True)

    long_df.head()
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
        'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(15,55), dpi=300)
    plt.title('Count by Formula')
    ax = sns.barplot(y = long_df.Variable, x = long_df.Count)
    for i, v in enumerate(long_df["Count"].iteritems()):        
        ax.text(v[1] ,i, "{:,}".format(v[1]), color='salmon', va ='bottom', rotation=45)
    plt.tight_layout()

def turningpoints(col):

    if isinstance(col, pd.Series) == False:
        col = pd.Series(col)
    index = col.index
    dy = np.diff(col)/np.diff(index)
    dpy=[float(dy[i+1]-dy[i]) for i in range(len(dy)-1)]
    min_idx = [index.values.tolist()[np.argmin(dpy)]]
    top_min = [index.values.tolist()[i] for i in np.argsort(dpy)[-1:]]

    best_idx = top_min
    return best_idx

def elbow_pts(col, thresh=50):
    if isinstance(col, pd.Series) == False:
        col = pd.Series(col)
    index = col.index
    dy = [0]
    dx = abs(np.diff(col)*100)
    dy.extend([val for val in dx])
    dx = pd.Series(dy, index=index)
    top_min = [index.values.tolist()[i] for i in np.argsort(dx)[:5]] 
    print(top_min)
    best_idx  = []
    for idx in top_min:
        if np.mean(dx.iloc[idx:idx+thresh]) <= 0.1:
            best_idx.append(idx)
    return best_idx


def flat_idx(col_f, up_before = True, thresh=100, keep_one =True):
    if isinstance(col_f, pd.Series) == False:
        col_f = pd.Series(col_f)
    col = col_f.ffill().round(2)
    index = col.index  
    # lab_col = group_slope(col,up_before, thresh)
    if up_before: 
        lab_col=(col.groupby((col.diff() != col.diff().shift()).cumsum()).transform('size') >= thresh).astype(int)
    else:
        lab_col=(col.groupby((col == col.shift()).cumsum()).transform('size') >= thresh).astype(int)
    if 1 in lab_col.values:     
        idx_col = lab_col[lab_col.diff() != 0]
        idx = idx_col[idx_col == 1].index.values
        if keep_one: 
            if up_before:
                idx = [idx[-1]]
            else:
                idx = [idx[0]]
    else: 
        idx = []
    return idx

def cal_auc( y_col, dx = 1):
    # if x_col == False:
    #     x_col = np.array(y_col.index.values)
    # print(x_col)
    return np.trapz(y_col, dx = dx)


# Dimensionality Reduction 
def autoencoder(x_train, y_train, n_comp= 10):
    m = Sequential()
    m.add(Dense(256,  activation='elu', input_shape=(x_train.shape[0],x_train.shape[1])))
    m.add(Dense(128,  activation='elu'))
    m.add(Dense(2,    activation='linear', name="bottleneck"))
    # m.add(Dense(128,  activation='elu'))
    m.add(Dense(256,  activation='elu'))
    m.add(Dense(n_comp,  activation='sigmoid'))
    m.compile(loss='mean_squared_error', optimizer = Adam())
    history = m.fit(x_train, y_train, batch_size=8, epochs=5, verbose=1)

    encoder = Model(m.input, m.get_layer('bottleneck').output)
    zenc = encoder.predict(x_train)  # bottleneck representation
    renc = m.predict(x_train)    
    print('The shape of input x is {} and the encoded x is {}'.format(x_train.shape, np.array(renc).shape))    # reconstruction
    return renc


def svd(df, y_col=False, three_d = True, max_feat = 20000, n_comp= 10, plot_name ='svd_dim_re'):
    data = df.select_dtypes(['number'])
    gwd = os.getcwd()
    df = data.dropna()
    if df.shape[1] > max_feat:
        df = df.set_index(y_col).reset_index()
        df = df.iloc[:,:max_feat]
    # For reproducability of the results
    np.random.seed(42)
    rndperm = np.random.permutation(df.shape[0])
    svd = TruncatedSVD(n_components=10,algorithm='randomized', random_state=2019, n_iter=5)
    if y_col:
        df = df.loc[:,df.columns != y_col]
    if df.values.shape[0] >= 1: 
        svd.fit(df.values)

        svd_result = svd.fit_transform(df.values)
        svd_result = svd.inverse_transform(svd_result)
        svd_result = svd_result[:,:n_comp]
        new_df = pd.DataFrame(svd_result)
        new_df.columns = ['svd_' + str(i+1) for i in range(len(new_df.columns))]

        # df['svd_comp1'] = svd_result[:,0]
        # df['svd_comp2'] = svd_result[:,1]
        # df['svd_comp3'] = svd_result[:,2]
    else:
        new_df = df
    return new_df

def pca(df, y_col=False, three_d = True, max_feat = 20000,plot_name ='pca_dim_re'):
    '''
        Use PCA method to reduce the dimension of the dataset
        Return a 2D and/or 3D PCA plot
    '''
    data = df.select_dtypes(['number'])
    gwd = os.getcwd()
    df = data.dropna()
    if y_col:
        if df.shape[1] > max_feat:
            df = df.set_index(y_col).reset_index()
            df = df.iloc[:,:max_feat]
    # For reproducability of the results
    np.random.seed(42)
    rndperm = np.random.permutation(df.shape[0])
    pca = PCA(n_components=3)
    if y_col:
        pca_result = pca.fit_transform(df.loc[:,df.columns != y_col].values)
    else:
        pca_result = pca.fit_transform(df.values)
    # pca_result = pca.inverse_transform(pca_result)
    df['pca_comp1'] = pca_result[:,0]
    df['pca_comp2'] = pca_result[:,1]
    df['pca_comp3'] = pca_result[:,2]
    
    print('Explained variation per principal component: {}'.format(pca.explained_variance_ratio_))
    plt.style.use('fivethirtyeight')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    # plt.rcParams['axes.facecolor'] = 'white'
    plt.figure(figsize=(12,6), dpi=300)
    try:
        sns.scatterplot(
                    x="pca_comp1", y="pca_comp2",
                    hue=y_col,
                    palette="Set2",
                    data=df,
                    legend="full",
                    alpha=0.7
                )
    except:
        df[y_col] = df[y_col].astype('category').cat.codes
        sns.scatterplot(
                    x="pca_comp1", y="pca_comp2",
                    hue=y_col,
                    palette="Set2",
                    data=df,
                    legend="full",
                    alpha=0.7
                )
    plt.title('PCA Feature Dimensionality Reduction 2D Plot')
    plt.legend('')
    plot_dir = make_dir(os.path.join(gwd ,'plots','dim_red/'))

    plt.savefig(plot_dir+ plot_name+'_2d.png')
    plt.show()
    

    if three_d: 
        plt.rcParams['axes.facecolor'] = 'white'
        ax = plt.figure(figsize=(12,8),dpi=300).gca(projection='3d')
        ax.scatter(
            xs=df.loc[rndperm,:]["pca_comp1"], 
            ys=df.loc[rndperm,:]["pca_comp2"], 
            zs=df.loc[rndperm,:]["pca_comp3"], 
            c=df.loc[rndperm,:][y_col].astype('category').cat.codes, 
            # label=df.loc[rndperm,:][y_col],
            cmap='Set2'
        )
        ax.set_xlabel('pca_comp1')
        ax.set_ylabel('pca_comp2')
        ax.set_zlabel('pca_comp3')
        # produce a legend with the unique colors from the scatter
        # legend = ax.legend(*scatter.legend_elements(),
        #                     loc="lower right", title="device_type")
        # ax.add_artist(legend)

        plt.title('PCA Feature Dimensionality Reduction 3D Plot')
        plot_dir = make_dir(os.path.join(gwd ,'plots','dim_red/'))

        plt.savefig(plot_dir+ plot_name+'_3d.png')
        plt.show()
    return df


def tsne(df, y_col=False, three_d=True, max_feat = 20000, plot_name ='tsne_dim_red'):
    '''
        Use t-SNE method to reduce the dimension of the dataset
        Return a 2D and /or 3D t-SNE plot
    '''
    data = df.select_dtypes(['number'])

    gwd = os.getcwd()
    df = data.dropna()
    time_start = time.time()
    if y_col:
        if df.shape[1] > max_feat:
            df = df.set_index(y_col).reset_index()
            df = df.iloc[:,:max_feat]
    np.random.seed(42)
    rndperm = np.random.permutation(df.shape[0])
    tsne = TSNE(n_components = 3, verbose = 1, perplexity=30, n_iter=500)
    if y_col:
        tsne_results = tsne.fit_transform(df.loc[:,df.columns != y_col].values)
    else:
        tsne_results = tsne.fit_transform(df.values)
    print('t-SNE done! Time elapsed: {} seconds'.format(time.time()-time_start))
    df['tsne-3d-1'] = tsne_results[:,0]
    df['tsne-3d-2'] = tsne_results[:,1]
    df['tsne-3d-3'] = tsne_results[:,2]
    plt.style.use('fivethirtyeight')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    # plt.rcParams['axes.facecolor'] = 'white'
    plt.figure(figsize=(12,6), dpi=300)
    try:
        sns.scatterplot(
            x="tsne-3d-1", y="tsne-3d-2",
            hue=y_col,
            palette="Set2",
            data=df,
            legend="full",
            alpha=0.7
        )
    except:
        df[y_col] = df[y_col].astype('category').cat.codes
        sns.scatterplot(
            x="tsne-3d-1", y="tsne-3d-2",
            hue=y_col,
            palette="Set2",
            data=df,
            legend="full",
            alpha=0.7
        )
    plt.title('t-SNE Feature Dimensionality Reduction 2D Plot')
    plt.legend('')
    plot_dir = make_dir(os.path.join(gwd ,'plots','dim_red/'))

    plt.savefig(plot_dir+ plot_name+'_2d.png')
    plt.show()

    if three_d: 
        plt.rcParams['axes.facecolor'] = 'white'
        ax = plt.figure(figsize=(12,8),dpi=300).gca(projection='3d')
        ax.scatter(
            xs=df.loc[rndperm,:]["tsne-3d-1"], 
            ys=df.loc[rndperm,:]["tsne-3d-2"], 
            zs=df.loc[rndperm,:]["tsne-3d-3"], 
            c=df.loc[rndperm,:][y_col].astype('category').cat.codes,
            cmap='Set2'
            # label=df.loc[rndperm,:][y_col],
        )
        ax.set_xlabel('tsne-3d-1')
        ax.set_ylabel('tsne-3d-2')
        ax.set_zlabel('tsne-3d-3')
        # legend = ax.legend(*scatter.legend_elements(),
        #                     loc="lower right", title="device_type")
        # ax.add_artist(legend)

        plt.title('t-SNE Feature Dimensionality Reduction 3D Plot')
        plot_dir = make_dir(os.path.join(gwd ,'plots','dim_red/'))

        plt.savefig(plot_dir+ plot_name+'_3d.png')
        plt.show()

def plot_data(data, xaxis, title):
    '''
    Plot the columns in a dataframe in one graph 
    '''
    if xaxis:
        df = data.set_index(xaxis)
        df.plot(kind='line',color = antV, figsize=(20,14),linewidth = 3,
                 subplots=True, alpha =0.8)
        plt.xlabel(xaxis)
        plt.title(title)

    else:

        # df = data.astype('float')
        df = data.select_dtypes(['number']) # select only the numeric columns
        df.plot(kind='line',color = antV, figsize=(20,14),linewidth = 3,
                 subplots=True, alpha =0.8)
        plt.title(title)
        plt.legend()


# Filter abnormal by derivative
def cal_slope(y):
    # dx = np.nan_to_num(np.diff(x))
    # dy = np.nan_to_num(np.diff(y))
    # print('dx and dy and dy/dx are {} {} {}'.format(dx, dy, dy*100/dx))
    # avg_slope = abs(np.mean(dy*100/dx))
    y = y.dropna()
    y = y.values
    dy = abs(y[-1] - y[0])
    avg_slope = dy/len(y)
    return float(avg_slope)

def filter_pctdrop(df, y_col, cyc_col,  label_col, pct = 70, cyc_num = 1000, plot=False, keep_all=False):
    data = df.copy()
    data = data.ffill()
    data['chk_abn'] = 0
    labels = data[label_col].unique()
    abn_samples = []
    for i,lab in enumerate(labels): 
        df = data.loc[data[label_col] == lab]
        if max(df[cyc_col].values) > cyc_num: 
            y_1000 = float(df.loc[df[cyc_col] == cyc_num,y_col].values[0])
        else:
            y_1000 = 0
        if y_1000 < pct:
            abn_samples.append(lab)
    if plot: 
        plot_df(data[y_col], subplots = False, plot_name='Abnormal battery '+ str(i), num_col = False)
    data.loc[data['obj_name'].isin(abn_samples), 'chk_abn'] = 1                  
    print('The abnormal samples are {}'.format(abn_samples))
    if keep_all == False:
        data = data[~data[label_col].isin(abn_samples)]
    return data
        

def filter_slope(dt, tar_col, label_col, thresh = 0.045, label_name = 1, keep_all= False,plot=False):
    '''
     Filter out the samples with abnormal patterm in target column by the percentage 
     change 
     Returns a list of target samples
    '''
    data = dt.copy()
    # data = fill_na(data)
    data['chk_abn'] = 0
    labels = data[label_col].unique()
    abn_samples = []
    slopes = {}
    for i,lab in enumerate(labels): 
        df = data.loc[data[label_col] == lab]
        avg_slope = cal_slope(df[tar_col].iloc[-100:])
        slopes[lab] = avg_slope

    dict_vals = list(slopes.values())
    dict_vals = [x for x in dict_vals if (str(x) != 'nan') & (x != np.inf)]
    dict_vals = np.asarray(dict_vals)
    perc = thresh
    # print('The {} percentile of all cells are {}'.format(thresh, perc))
    abn_samples  = [k for k,v in slopes.items() if v >= perc]
    # if max_dd < thresh:
    if plot: 
        plot_df(df[tar_col], subplots = False, plot_name='Abnormal battery '+ str(i), num_col = False)
            # abn_samples.append(lab)
    data.loc[data['obj_name'].isin(abn_samples), 'chk_abn'] = label_name            
    print('The abnormal samples are {}'.format(abn_samples))
    if keep_all == False:
        data = data[~data[label_col].isin(abn_samples)]
    return data

def filter_abn(dt, tar_col, label_col, thresh = 75, keep_all= False,plot=False):
    '''
     Filter out the samples with abnormal patterm in target column by the percentage 
     change 
     Returns a list of target samples
    '''
    data = dt.copy()
    data['chk_abn'] = 0
    labels = data[label_col].unique()
    abn_samples = []
    min_dd= {}
    for i,lab in enumerate(labels): 
        # max_dd = 0 
        df = data.loc[data[label_col] == lab]
        min_dd[lab] = min(max_drawdown(df, tar_col))
        # print('Sample {} has the maximum drawdown of {}'.format(lab, max_dd))
        # if max_dd < thresh:
        #     if plot: 
        #         plot_df(df[tar_col], subplots = False, plot_name='Abnormal battery '+ str(i), num_col = False)
        #     abn_samples.append(lab)
    dict_vals = list(min_dd.values())
    dict_vals = [abs(x) for x in dict_vals if (str(x) != 'nan') & (x != np.inf)]
    dict_vals = np.asarray(dict_vals)
    # print('slope array {}'.format(dict_vals))
    perc = float(np.percentile(dict_vals, thresh))
    print('The {} percentile of all cells are {}'.format(thresh, perc))
    abn_samples  = [k for k,v in min_dd.items() if abs(v) >= perc]
    data.loc[data['obj_name'].isin(abn_samples), 'chk_abn'] = 2               
    print('The abnormal samples are {}'.format(abn_samples))
    if keep_all == False:
        data = data[~data[label_col].isin(abn_samples)]
    return data

def max_drawdown(data, tar_col):
    # data['pct_chg'] = np.nan_to_num(data[tar_col].pct_change())
    data['pct_chg'] = np.nan_to_num(data[tar_col].diff())
    data['cumulative_y'] = data['pct_chg'].cumsum()
    data['highvalue'] = data['cumulative_y'].cummax()
    return data['cumulative_y'] - data['highvalue']

def drop_type1(data, tar_col1='CycleNo', tar_col2='y', thresh1=80, thresh2=70, label_col='obj_name', keep_all=True):
    df = data.copy()
    labels = df[label_col].unique()
    unqualified_samples = []
    p1 = [600,1000]
    p2 = [85,75]
    a, b = np.polyfit(p1, p2, 1)
    y = np.polyfit(p1, p2, 1)
    for cell in labels: 
        df_cell = df[df[label_col] == cell]
        max_cyc = int(df_cell.loc[df_cell[tar_col2] == min(df_cell[tar_col2]), tar_col1].values[0])
        thresh = a*max_cyc + b
        if min(df_cell[tar_col2]) < thresh:
            unqualified_samples.append(cell)
        # if (max(df_cell[tar_col1]) >= 1000) & (len(df_cell.loc[df_cell[tar_col1] == 1000, tar_col2].unique()) >=1):
        #     if (float(df_cell.loc[df_cell[tar_col1] == 1000, tar_col2].unique()[0]) <= thresh2):
        #         print('The battery {} has more than 1000 cycles and its SOH is {}'.format(cell, min(df_cell[tar_col2])))
            
        #         unqualified_samples.append(cell)
        # elif (max(df_cell[tar_col1]) >= 600) & (len(df_cell.loc[df_cell[tar_col1] == 600, tar_col2].unique()) >=1):
        #     if (float(df_cell.loc[df_cell[tar_col1] == 600, tar_col2].unique()[0]) <= thresh1):
        #         print('The battery {} has more than 600 cycles and its SOH is {}'.format(cell, min(df_cell[tar_col2])))
        #         unqualified_samples.append(cell)
        # elif max(df_cell[tar_col1]) < 600:
        #     unqualified_samples.append(cell)
        else:
            pass
            # unqualified_samples = []
    print("The unqualified samples are {}".format(unqualified_samples))
    if keep_all:
        df.loc[(df[label_col].isin(unqualified_samples)), 'chk_abn'] = 1
        df['chk_abn'] = df['chk_abn'].fillna(0)
    else:
        df = df[~df[label_col].isin(unqualified_samples)]
    return df 

def drop_earlystopper(data, tar_col, thresh, label_col, keep_all=False, m_or_l = 'more'):
    '''
        Drop the samples with the number of time steps less or more than a threashold 
        Return a dataframe after the drop
    '''
    df = data.copy()
    labels = df[label_col].unique()
    if m_or_l == 'more':
        qualified_samples = df[df[tar_col] > thresh][label_col].unique().tolist()
    if m_or_l == 'less':
        qualified_samples = df[df[tar_col] < thresh][label_col].unique().tolist()
    print("The qualified samples are {}".format(qualified_samples))
    unqualitfied_samples = [obj for obj in labels if obj not in qualified_samples]
    slopes = {}
    
    for i,lab in enumerate(unqualitfied_samples): 
        obj_df = df.loc[df[label_col] == lab]
        # print('The first column is {}'.format( df.columns[0]))
        avg_slope = cal_slope(obj_df[tar_col])
        slopes[lab] = avg_slope
    dict_vals = list(slopes.values())
    dict_vals = [x for x in dict_vals if (str(x) != 'nan') & (x != np.inf)]
    dict_vals = np.asarray(dict_vals)
    perc = float(np.percentile(dict_vals, 85))
    abn_samples  = [k for k,v in slopes.items() if v >= perc]
    nor_samples = [obj for obj in labels if obj not in abn_samples]
    if keep_all:
        df.loc[(df[label_col].isin(abn_samples)), 'chk_abn'] = 1
        df['chk_abn'] = df['chk_abn'].fillna(0)
    else:
        df = df[~df[label_col].isin(qualified_samples)]
    return df 



def plot_turningpts(df, y_col, label_col=False, obj_name=''):
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 10})
    params = {'legend.fontsize': 10,
              'legend.handlelength': 2}
    plt.rcParams.update(params)
#     plt.figure(figsize=(18,14), dpi=300)
    data = df.copy()
    data = fill_na(data)
    data = data.reset_index(drop=True)
    data = data.select_dtypes(['number'])
    data = data.astype(float).fillna(0)
    
    if label_col: 
        unique_labels = data[label_col].unique()
        for col in data.columns: 
            plt.figure(figsize=(8,2), dpi=300)
            for i,lab in enumerate(unique_labels):
                
                sns.distplot(data.loc[data[label_col] == lab,col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[np.random.randint(len(antV))], label = lab)
                # sns. (sub_df_post[col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int((i+1)%len(antV))], label ='After - '+col)
                # plt.text(y=-0.2, x=1, s=obj_name, color=antV[np.random.randint(9)], fontsize=12,rotation=0)
                plt.legend() 
                plt.title(obj_name )
        
    else: 
        turning_idx = turningpoints(data[y_col])
        sub_df_pre = data.iloc[:int(turning_idx[0]), :]
        sub_df_post = data.iloc[-int(turning_idx[0]):, :]
        for i,col in enumerate(data.columns):
            plt.figure(figsize=(8,2), dpi=300)
            sns.distplot(sub_df_pre[col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int(i%len(antV))], label = 'Before - '+col)
            sns.distplot(sub_df_post[col], kde_kws=dict(linewidth=3),ax=plt.gca(), color = antV[int((i+1)%len(antV))], label ='After - '+col)
            # plt.text(y=-0.2, x=1, s=obj_name, color=antV[np.random.randint(9)], fontsize=12,rotation=0)
            plt.legend() 
            plt.title(obj_name )
    plt.show()



def plot_obj_features(df, y_col, label, drop_cols=False, groupby=True,obj_name='', num_col=30,
                       xaxis = False, title = 'y ', turning=False):
    '''
        Plot the y of the object and its related explanatory variables x in stacked 2 graphs 
        and generate inividual plot set for each object 
        Return a set of plots for all object

       Args:
            - data: a dataframe 
            - x_col: a string of the variable on x axis with the default value False 
            - y_col: a string of the target variable name
            - x_cols: a list of strings of the explanatory variables 
            - label: a string of the variable which contains the label of the object 
    '''
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 11,
              'legend.handlelength': 2}
    plt.rcParams.update(params)
#     plt.figure(figsize=(18,14), dpi=300)
    data = df.copy()

    labels = data[label].unique()
    col_batches = get_batches(data, y_col, drop_cols)
    # (df.ColumnB.ne(df.ColumnB.shift())).astype(int)
    cats = data[(data[label].ne(data[label].shift())).astype(int)!=0].index.values
    
    for num, batch in enumerate(col_batches):
        # print('the num is {}'.format(num))
        if groupby:
            for i, name in enumerate(labels): 
                df = data.loc[data[label] == name][batch] 
                try:
                    if num_col: 
                        df = df.iloc[:,-num_col:]
                    # plot_data(df, xaxis, name + label +' ' + title + ' vs. other features') 
                    df.plot(kind='line', figsize=(12,6),lw = 2, color=antV1, 
                        title='', subplots=True, alpha =0.8)
                    if turning: 
                        turning_idx = turningpoints(df[y_col])
                        print('At the first turning point the discharge_avg_temp is {} and charge_avg_temp is {}'.format(df['discharge_avg_temp'].values[turning_idx[0]],df['charge_avg_temp'].values[turning_idx[0]]))

                        for idx in turning_idx: 
                            plt.axvline(turning_idx, color='tomato',linestyle='--', alpha = 0.8)
                    plt.title(name + ' Features Plot')
                    plot_dir = make_dir(os.path.join(gwd ,'plots/','objs/',name+'/'))
                    plt.legend(bbox_to_anchor=(1.15, 1.05), loc='upper right', ncol=1,prop={'size': 11})
                    plt.savefig(plot_dir + str(num) +'.png')
                    plt.show()  
                except:
                    pass
        else:
            sub_df = data[batch]

            try:
                if num_col: 
                    df = df.iloc[:,-num_col:]
                ax = sub_df.plot(kind='line', figsize=(12,8),lw = 1.5, color = antV1,
                         subplots=True, alpha =0.8) 
            
                for sub in ax:    # Plot the red vertical lines
                    # for item in cats[0::]:
                    #     sub.axvline(item, ymin=1.2, ymax=100,color='salmon',linestyle='--')
                    #     sub.axvline(item, ymin=-1.2, ymax=100,color='salmon',linestyle='--')
                    if turning: 
                        turning_idx = turningpoints(df[y_col])
                        print('At the first turning point the discharge_avg_temp is {} and charge_avg_temp is {}'.format(df['discharge_avg_temp'].values[turning_idx[0]],df['charge_avg_temp'].values[turning_idx[0]]))
                        for idx in turning_idx:
                            # sub_df_pre = sub_df.iloc[:idx, :]
                            # sub_df_post = sub_df.iloc[-idx:, :]
                            sub.axvline(idx,  ymin=1.2, ymax=100,color='tomato',linestyle='--', alpha = 0.8)
                            sub.axvline(idx,  ymin=-1.2, ymax=100,color='tomato',linestyle='--', alpha = 0.8)
 
            except Exception:
                pass
                # plt.text(y=0.8*sub_df[y_col].max(), x=(cats[-1]+len(sub_df)-1)/2,
            
            # plt.legend(bbox_to_anchor=(1.15, 1.05), loc='upper right', ncol=1,prop={'size': 11})
            plt.title(name + ' Features Plot')
            plot_dir = make_dir(os.path.join(gwd ,'plots/','all_objs/'))
            plot_path = str(plot_dir) + str(num) +'.png'
                    
            plt.savefig(plot_path)
        
            plt.show()  

            



# Subset dataset and extract feature 
def delta(col):
    delta = 0
    try: 
        delta = float(col[-1]) - float(col[0])   
    except: 
        pass
    return delta
   

def feature_extraction(df,  stats = ['mean','max','min','median','std', 'delta', 'sum']):
    '''
        Extract the basic statistics from a given dataframe across columns
        Return a array of stats
        Args: 
            - df: the input dataframe
    '''
    ops = {'mean': np.mean, 'max': np.max, 'min': np.min, 'median': np.median, 'std': np.std, 'sum':np.sum, 'delta': delta}
    features = {}
    
    for col in df.columns: 
        for stat in stats:
            # print('we are at the column {} and stat {}'.format(col, stat))
            try:
                new_col = str(col)+ '_' +str(stat)
                features[new_col] = ops[stat](df[col].values)
            except: 
                pass
            
    df = pd.DataFrame([features])
    return df
    
def subset_dataset(data, y_col, omit_col =False, delta_y=False):
    '''
        Subset the dataframe into multiple sub-dataframe based on the occurrence of y and
        extract the featurs from those sub-dataframe and generate a new feature dataframe with
        all stats of each sub-dataframe
        Return a stats dataframe
        Args: 
            - numpy.isnan(number)
            
    '''
    df = data.copy()

    # y_idx = df[df[y_col].notnull()].index 
    y_idx = []
    for lab in df[y_col].unique():
        y_idx.append(df[df[y_col] == lab].index.values[-1])
    y_idx = sorted(y_idx)
    print('The indices when y is not empty are {}'.format(y_idx))
    
    feature_list = []
    col_y = df.iloc[y_idx][y_col]
    
    if omit_col: 
        col_omit = df.iloc[y_idx][omit_col]
        df_y =pd.concat([col_y, col_omit], axis=1).reset_index(drop=True)
        df = df.drop([y_col,omit_col], axis =1)
    else:
        df_y = pd.DataFrame([col_y]).reset_index(drop=True)
        df = df.drop(y_col, axis =1)
    if delta_y: 
        delta_y = 'dy'
        df_y[delta_y] = df_y[y_col].diff(1)
    
    
    for idx in range(len(y_idx)):
        if idx == 0: 
            sub_df = df.iloc[0: y_idx[idx+1],:]
        elif idx == len(y_idx) - 1: 
            sub_df = df.iloc[y_idx[idx]: len(df),:]
        else: 
            sub_df = df.iloc[y_idx[idx]: y_idx[idx+1],:]
        stats = feature_extraction(sub_df)
        feature_list.append(stats)
    feature_df = pd.concat(feature_list, axis = 0).reset_index(drop=True)
    if delta_y: 
        delta_y = 'dy'
        df_y = df_y[df_y[delta_y] != 0]
        print('The length of the feature df is {} and the length of df_y is {}'.format(len(feature_df), len(df_y)))
    frame = pd.concat([feature_df, df_y], axis = 1)
    return frame
    
# Concatenate all dataframes from the same folder
def concat_dfs(input_dir, skiprows=0, concat = True, name = False):
    '''
        Load all dataframes from the folder and concatenate them together 
        Return a concatenated dataframe 
        Args: 
            - input_dir: the input folder where all the files are saved
    '''

    
    if isinstance(input_dir,str): 
        files = os.listdir(input_dir)
        files_csv = [input_dir + i for i in files if i.endswith('.csv')]
    else:
        files_csv = input_dir
    dfs = []
    ids = []
    for filename in files_csv:
        print(filename)
        if os.path.exists(filename):
            try:
                df = load_data(filename,  skiprows = skiprows)
                if name:
                    ids.append(name)
                    df['obj_name'] = name
                else:
                    print(re.search(r'.*\/(.*)', filename).group(1)[:-4])
                    # ids.append(filename[:-4])
                    ids.append(re.search(r'.*\/(.*)', filename).group(1)[:-4])
                    df['obj_name'] = re.search(r'.*\/(.*)', filename).group(1)[:-4]
                    
                dfs.append(df)
            except: 
                pass 
           
        else:
            pass
                 
    if concat: 
        frame = pd.concat(dfs, axis = 0, ignore_index = False)
        print('Number of rows in concatenated dataset: ', len(frame))
         #     write_csv(frame, 'concated_df_all')
        return frame  
    else: 
        return dfs, ids


#------------------------- Supporting Functions ---------------------------#

def merge_holiday(df):
    '''
    merge is_holiday into weekday column
    return new dataframe
    '''
    holiday_data = df.is_holiday.values
    args = np.argwhere(holiday_data == 1)
    dayweek_data = df.weekday.values
    dayweek_data[args] = 7
    df['weekday'] = dayweek_data
    return df

def find_folder(input_dir, pattern_str = 'N190269',pattern_loc = 'start'):
    '''
     Identify all folders with the particular pattern in the name in given input directory 
     Return a list of folder names
    '''
    folders = os.listdir(input_dir)
    if pattern_loc == 'start':
        folders = [os.path.join(input_dir,folder) for folder in folders if folder.startswith(pattern_str)]
    elif pattern_loc == 'end':
        folders = [os.path.join(input_dir,folder) for folder in folders if folder.endswith(pattern_str)]
    elif pattern_loc == 'contain':
        folders = [os.path.join(input_dir,folder) for folder in folders if folder.find(pattern_str) != -1]
    if len(folders) >=1:
        return folders
    else:
        pass

def get_user_list(df, id_col):
    if id_col is not None:
        return sorted(df[id_col].unique())
    else:
        return []


def group_by_id(df, user_list, id_col, timestamp_col):
    '''
    make dataframe for each user 
    return list of dataframe order by id
    '''
    raw_data_list = []
    if len(user_list) > 0:
        for uid in user_list:
            raw_data_list.append(
                df[df[id_col] == uid].sort_values(timestamp_col))
    else:
        raw_data_list.append(df.sort_values(timestamp_col))
    logger.info('split raw data by user id')
    return raw_data_list


def count_dummy_vals(df, dummy_features):
    '''
    return dummy feature unique values num
    '''
    d = {}
    for c in dummy_features:
        d[c] = len(df[c].unique())
    logger.info('count dummy feature unique values')
    return d

# Kmeans
def elbow_plot(data, drop_cols, max_cluster=20):
    sse = {}
    df = data.copy()
    if drop_cols: 
        df = df.drop(drop_cols, axis = 1)

    for k in range(1, max_cluster):
        kmeans = KMeans(n_clusters=k, max_iter=1000).fit(df)
        df["clusters"] = kmeans.labels_
         
        sse[k] = kmeans.inertia_ # Inertia: Sum of distances of samples to their closest cluster center
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    fig = plt.figure(figsize=(12,8), dpi=300)
    plt.title('Elbow Analysis')
    plt.plot(list(sse.keys()), list(sse.values()),'r*-.',c='lightcoral',lw =1)
    plt.xlabel("Number of cluster")
    plt.ylabel("SSE")
    plt.savefig('elbowanalysis.png', transparent=True)
    plt.show()

def kmeans(data, num_cluster, drop_cols,cluster_col='kmeans_label'):
    '''
     Create the kmeans model to cluster
    '''
#     num_cluster = len(sample_df[label_col].unique())
    df = data.copy().dropna()
    if drop_cols: 
        df = df.drop(drop_cols, axis = 1)
    df_std = np.nan_to_num(stats.zscore(df))

    #Cluster the data
    kmeans = KMeans(n_clusters=num_cluster, random_state=0).fit(df_std)
    labels = kmeans.labels_

#    print(df.groupby(['clusters']).mean())
    # df['clusters'].unique()
    cluster_map = pd.DataFrame()
    cluster_map['data_index'] = df.index.values
    cluster_map[cluster_col] = labels
    return cluster_map

def add_cluster(df, cluster_df, device_col, cluster_col):
    '''
        Add the cluster number back to the original dataframe
        Return a dataframe with added cluster number column 
        Args: 
            - df: dataframe with the device id 
            - cluster_df: dataframe generated kmeans algorithm 
            - device_col: the device id column name in df
            - index_col: the index id column name in cluster df
    '''
#     df[cluster_col] = [int(cluster_df[cluster_df[index_col] == idx][cluster_col].values) ]
    df[cluster_col] = [int(cluster_df[cluster_df[device_col] == device][cluster_col].values) if device in cluster_df[device_col].values else np.nan for device in df[device_col]]
    return df

def add_idcol(df, cluster_df, device_col, index_col):
    '''
       Add the device ids back to the cluster dataframe
        Return a dataframe with added device_id column 
        Args: 
            - df: dataframe with the device id 
            - cluster_df: dataframe generated kmeans algorithm 
            - device_col: the device id column name in df
            - index_col: the index id column name in cluster df
    '''
    cluster_df[device_col] = [df[device_col][idx] for idx in cluster_df[index_col].values]
    return cluster_df

def device_class(df, class_col, device_col):
    '''
        Place the device into the corresponding class
        Return a dictionary with the key as the class and values as device ids
        Args: 
            - df: dataframe
            - class_col: the column with the class number
            - device_col: the column with the deive ids
    '''
    device_class = {}
    for cate in df[class_col].unique():
        device_class[cate] = df[df[class_col] == cate][device_col].values.tolist()
    return device_class


def plot_class(data, label, labels=False):
    '''
        Subset the dataframe into multiple dataframes based on the label 
        then plot the data in the same class into the same subplot 
        Return a set of sub-dataframes per class
        Args: 
            - df: dataframe
            - label: the label to subset the dataframe
            - labels: a dictionary of labels to drop other than the second argument label
    '''
    df = data.copy().dropna()
    dfs = {}
    grouped = df.groupby(label)
    for level in df[label].unique():
        if labels: 
            dfs[level] = grouped.get_group(level).drop(labels, axis =1).T.head(200)
        else: 
            dfs[level] = grouped.get_group(level).drop(label, axis=1).T.head(200)
    return dfs



def plot_dfs(dfs, plot_name= 'subclass_plot'):
    '''
        Plot all the dataframe in separate subplot
    '''
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 15,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    fig = plt.figure(figsize=(18,40), dpi=300)
    idx = 1
    for key,df in dfs.items(): 
        
        ax = fig.add_subplot(len(dfs),1,idx)
        ax.plot(df)
        idx += 1
        ax.set_title(key)

    plot_dir = make_dir(os.path.join(gwd ,'plots','class_plots/'))

    plt.savefig(plot_dir+ plot_name+'.png')
    plt.show()

def kmeans_run(df, num_cluster, cluster_name, id_col, drop_cols, plot_name='cluster_'):
    '''
    
    '''
    cluster_map = kmeans(df, num_cluster, drop_cols,cluster_name)
    cluster_map = add_idcol(df, cluster_map, id_col, 'data_index')
    
    df_cluster = add_cluster(df, cluster_map,  id_col, cluster_name)
    
    drop_cols.append(cluster_name)
    plot_name = plot_name + str(num_cluster) + '_plot'
    dfs = plot_class(df_cluster, cluster_name, drop_cols)
    plot_dfs(dfs,plot_name)
    return df_cluster

# Supporting fns
def make_dir(outdir):
   '''
   Chcek and create directory if directory does not exist
   Returns a directory path
   '''
   if not os.path.exists(outdir):
       print('The output directory does not exist. Trying to make one..')
       os.makedirs(outdir)
   return outdir


def write_csv(df, filename, y_col = False, out_dir = 'output/', header=True):
   '''
   Writes the dataframe as a csv and saved it to the specified directory
   '''
   gwd = os.getcwd()
   if y_col: 
       df = pd.concat([df[y_col], df.loc[:, df.columns != y_col]], axis = 1)
   outdir = make_dir(os.path.join(gwd, out_dir))  
   df.to_csv(outdir + filename + '.csv', index=True, encoding='utf-8-sig', header=header)

def create_subclass(df, col1, col2, class_name):
    '''
         Create sub-class based on the value in the previous class levels 
         Return a dataframe with new subclass column 
         Args: 
             - df: dataframe
             - col1: level 1 column 
             - col2: level 2 column 
             - class_name: new subclass column name
    '''
    subclass_list = []
    for level in df[col1].unique():
#         print(df.loc[df[col1] == level][col2].astype('category').cat.codes.values)
        subclass_list.extend(df.loc[df[col1] == level][col2].astype('category').cat.codes.values)
    print('The length of the list is {} and the length of dataframe is {}'.format(len(subclass_list), len(df)))
    df[class_name] = subclass_list
    return df


def get_batches(data, y_col, drop_cols=False, batch_size = 4):
    '''
       Create separate batches of columns with y_col as the first element in the 
       Returns a list of lists with all batches 
       Args:
           - col_names: a list of column names
           - y_col: a string with the y column name 
           - batch_size: a int of the size of each list
    '''
    df = data.copy()
    df = df.drop(y_col, axis=1)
    df = df.select_dtypes(['number'])
    df = df.astype(float).ffill()
    col_names = df.columns.tolist()
#     col_names.remove(y_col)
    if drop_cols:
        col_names = [e for e in col_names if e not in drop_cols]
        
    # print('The original column names are {}'.format(col_names))
    new_list = []
    for i in range(0, len(col_names), batch_size):
        new_list.append(col_names[i:i + batch_size])
    for sub_list in new_list:
        if len(sub_list) > 0:
            sub_list.insert(0, y_col)
    return new_list


def load_model(modelname, fileformat='.plk'):
    '''
        Load the saved model 
        Returns a loaded model object

        Args: 
            - model_path: the directory of the saved model 
    '''
    model_dir = make_dir(os.path.join(gwd ,'models/','trained_model/'))
    model_path = model_dir + modelname + fileformat
    
    # model = pickle.load(open(model_path,'rb'))
    
    print('The model from the path {} is loaded'.format(model_path))
    return joblib.load(model_path)


def save_model(model, filename, fileformat='.plk'):
    '''
        Save a trained sklearn model into a model to disk
        Returns a saved model 
        
        Args: 
            - model: a trained sklearn model
            - filename: the model name when saved to disk 
    '''
    model_dir = make_dir(os.path.join(gwd ,'models/','trained_model/'))
    # return joblib.dump(model, model_dir + filename + '.sav')
    return pickle.dump(model, open(model_dir + filename + fileformat, 'wb'))


# AESC
#-----------DATA SMOOTHING-----------------#
def insert_mean(col, idx):
    '''
        Get the mean value of the values before and after with the specified index in a series
        Return the mean value      
    '''
    try:
        mean =  min(np.mean([col[int(idx) - 1], col[int(idx) + 1]]), col[int(idx) - 1], col[int(idx) + 1])
    except: 
        mean = np.mean(col[(int(idx)-5):(int(idx)+5)])
    #     print('the mean value is {}'.format(mean))
    return mean
 


def get_idx(col, pos=True):
    '''
        Get the indexes of the positive difference between 2 consecutive values in a series 
    '''
    if pos:
        try:
            return col[col.diff(1) > 0].index.tolist()
        except:
            col = pd.Series(col)
            return col[col.diff(1) > 0].index.tolist()

    else: 
        try:
            return col[col.diff(1) < 0].index.tolist()
        except:
            col = pd.Series(col)
            return col[col.diff(1) < 0].index.tolist()

    
def check_trend(col, trend='up', thresh=5):
    if isinstance(col, pd.Series) == False:
        col = pd.Series(col)
    if trend == 'up':
        chk_up = (col.diff(1) > 0).astype(int)
        up_bool = chk_up.groupby((chk_up != chk_up.shift()).cumsum()).transform('sum') > thresh
        idx = up_bool.index[up_bool].tolist()
    if trend == 'down':
        chk_down = (col.diff(1) < 0).astype(int)
        down_bool = chk_down.groupby((chk_down != chk_down.shift()).cumsum()).transform('sum') > thresh
        idx = down_bool.index[down_bool].tolist()
    return idx

def ma_smooth(col, thresh=  50):
    if isinstance(col, pd.Series) != True:
        col = pd.Series(col)
    new_col = col.ewm(span=thresh).mean()
    new_col.iloc[-10:] = np.nan
    new_col = new_col.interpolate(method='linear')
    return new_col
    

def linear_smooth(col):
    '''
     Group by the label in the dataframe and smooth out the value in a specified column 
     by identifying the value that has different trend 
     Returns a dataframe with the smoothed column values
     Args: 
         - df: a dataframe 
         - target_col: a string with the target column name 
         - groupby_col: a string with the groupby column name (optional)
    '''
    col = np.array(col)
    if len(col.shape) >= 2:
        col = col.flatten()
    if isinstance(col, pd.Series) != True:
        col = pd.Series(col)
    
    n = 0
    idx = get_idx(col)
    first_val = col.iloc[0]
    while (len(idx) > 0) and n < 10:
        col.iloc[0] = first_val
        up_idx = check_trend(col)
        try:
            col.loc[idx] = np.nan
            idx = np.array(idx)
            col.loc[idx-1] = np.nan
            col.loc[idx-2] = np.nan
            # col.loc[idx+1] = np.nan
            col.loc[up_idx] = np.nan
        except:
            col = pd.Series(col)
            col.loc[idx] = np.nan
            idx = np.array(idx)
            col.loc[idx-1] = np.nan
            # col.loc[idx+1] = np.nan
            col.loc[up_idx] = np.nan
            
        col = col.interpolate(method='linear')
        idx = get_idx(col)
        n += 1

    try:
        col = replace_anomaly(col, plot=False)
        
    except:
        pass
    col.iloc[0] = first_val
    return col


#------- Scaling Data ---------#
def move_data(col, thresh=100):
    index = col.index
    max_val = max(col.dropna())
    # print('the maximum value is {}'.format(max_val))
    if max_val > thresh:
        col = float(thresh - max_val) + col
        # col = float(thresh/max_val)*col
    else:
        col = col
    col.index = index
    return col

def scale_data(col, thresh=100):
    index = col.index
    new_col = col.copy()
    new_col = new_col.reset_index(drop=True)
    max_val = max(new_col.dropna())
    max_idx = int(new_col.index[new_col==max_val].tolist()[0])
    # print('the maximum value index is {}'.format(max_idx))
    if max_val > thresh:
        new_col = (thresh/max_val) * new_col 
        # col = float(thresh/max_val)*col
    else:
        new_col = new_col
    new_col.iloc[:max_idx] = thresh
    new_col.index = index
    return new_col

def groupby_apply(data, tar_col, label_col, fn, x_col=False,rep_cols=False, b_plot=False, plotname = '',plot=False):
    '''
        Group by dataframe by a the vlaue in the label column and modify the value of 
        the target column after group by with the specified function
        Return modeified dataframe
        Args:
            - df: dataframe
            - tar_col: a string with the target column name 
            - label_col: a string with the label column name 
            - fn: a function 
    '''
    df = data.copy()

    if b_plot:
        
        plot_ys(df, y_col=tar_col, label=label_col, x_col = x_col, plot_name = 'Before '+ plotname)
#     y_col = df.groupby(label_col)[tar_col].apply(fn)
    if rep_cols:
        df = df.groupby(label_col).apply(fn)
    else:
        df[tar_col] = df.groupby(label_col)[tar_col].apply(fn)
    if plot:
        plot_ys(df,  y_col=tar_col,label=label_col,x_col = x_col, plot_name = 'After '+plotname)
    return df
   
def remove_anomaly(data,  label_col, k, method = 'isolation_forest', tar_col = False, plot=False, plot_name = 'After Anomaly Removal SOHs'):
    '''
        Group by dataframe by a the vlaue in the label column and modify the value of 
        the target column after group by with the specified function
        Return modeified dataframe
        Args:
            - df: dataframe
            - tar_col: a string with the target column name 
            - label_col: a string with the label column name 
            - fn: a function 
    '''
    df = data.copy()
    # if tar_col: 
    #     plot_ys(df, label=label_col, y_col=tar_col, plot_name = 'Before Anomaly Removal SOHs - cycle')
    # else: 
    #     plot_ys(df, label=label_col, plot_name = 'Before Anomaly Removal SOHs - cycle')
    labels = df[label_col].unique().tolist()
#     print('unique lables are {}'.format(labels))
    dfs = []
    for i, name in enumerate(labels): 
        sub_df = df.loc[df[label_col] == name].copy()
        # sub_df.reset_index(inplace=True)
        first_idx = sub_df.index[0]
        if tar_col:
            if tar_col == 'y':
#                 sub_df[tar_col][first_idx] = 100
                sub_df.loc[first_idx,tar_col] = 100
            sub_df[tar_col] = replace_anomaly(sub_df[tar_col], k, method = method, plot=plot)
            if plot:
                plot_ys(sub_df, label=label_col, y_col=tar_col, plot_name = 'After Anomaly Removal - ' + tar_col)
        else:
            # print('The anomaly detection method is {}'.format(method))
            sub_df = replace_anomaly(sub_df, k, method = method, plot=plot )   
#         print(sub_df[tar_col])
        dfs.append(sub_df)
    frame = pd.concat(dfs, axis = 0, ignore_index = True)    
    if plot:
        plot_ys(frame, label=label_col, plot_name = 'After Anomaly Removal SOHs - cycle')
    return frame

def plot_ys(data, label, y_col = 'y', x_col = False, plot_name = 'SOHs', legend = True):
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 22})
    params = {'legend.fontsize': 11,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    plt.figure(figsize=(20,8), dpi=300)
    df = data.dropna(subset=[y_col])
    if x_col: 
        try:
            sns.lineplot(x=x_col, y=y_col, hue=label, linewidth = 3,
                        markers=True, data = df, palette = antV, alpha = 0.7)
            plt.xlabel(x_col)
        except:
            sns.lineplot(x=x_col, y=y_col, hue=label, linewidth = 3,
                        markers=True, data = df,  alpha = 0.7)
            plt.xlabel(x_col)
    else:
        x_col = df.columns[0]
        # print('x_col is {}'.format(x_col))
        try:
            sns.lineplot(x=df[x_col], y=y_col, hue=label, linewidth = 3,
                         markers=True, data = df, palette = antV, alpha = 0.7)
        except:
            try:
                sns.lineplot(x=df[x_col], y=y_col, hue=label, linewidth = 3,
                         markers=True, data = df,  alpha = 0.7)
            except:
                df[label] = df.index
                sns.lineplot(x=df.iloc[:,0], y=y_col, hue=label, linewidth = 2.5,
                         markers=True, data = df,  alpha = 0.7)
        plt.xlabel(x_col)
    plt.title(plot_name)   
    plt.ylabel(plot_name)
    if legend == False:
        plt.legend('',frameon=False)
            # plt.legend(bbox_to_anchor=(1.2, 1.05), loc='upper right', ncol=1,prop={'size': 10})
    else:
        plt.legend(bbox_to_anchor=(1.15, 1.05), loc='upper right', ncol=1,prop={'size': 12})
    plot_dir = make_dir(os.path.join(gwd ,'plots/','all_sohs/'))
    
    plt.savefig(plot_dir + plot_name + '.png')

    plt.show()   


def create_dataset(X, y, time_steps=1):
    Xs, ys = [], []
    for i in range(len(X) - time_steps):
        v = X[i:(i + time_steps)]
        Xs.append(v)
        ys.append(y[i + time_steps])
    return np.array(Xs), np.array(ys)

def min_max_func(col):
    f_col = fill_na(col)
    f_col = f_col.astype(float)
    nor_col = (f_col - f_col.min())/(f_col.max()-f_col.min())
    return nor_col

def rev_min_max_func(ori_col, nor_col):
    max_val = max(ori_col)
    min_val = min(ori_col)
    re_col = (nor_col*(max_val - min_val)) + min_val
    return re_col

def plot_prediction(y_true, y_pred, plot_name=''):
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 20,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    fig = plt.figure(figsize=(14,5), dpi=300)
    
    if isinstance(y_true, pd.Series) != True:
        y_true = pd.Series(y_true, index = range(len(y_true)))
    if isinstance(y_pred, pd.Series) != True:
        y_pred = pd.Series(y_pred, index = range(len(y_pred)))

    lower_bound = y_true * 0.95
    upper_bound = y_true * 1.05
    plt.plot(y_true, color = 'mediumturquoise', alpha = 0.6, linewidth=3, label ='true_val')
    plt.plot(y_pred, color ='salmon',linewidth=3, label='pred_val', marker='.',alpha = 0.7)
    plt.fill_between(range(len(y_true)),lower_bound,upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.2)
    # plt.plot(upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.5)
    plt.legend()
    plt.title(plot_name +' - Forecast vs Actuals' )
    plot_dir = make_dir(os.path.join(gwd ,'plots','all_predictions/'))
    plt.savefig(plot_dir+ plot_name +'.png')
    plt.show()

def plot_forecast_line(ytrain, y_ori, ypred, ori_tar, plot_name, pred_partial =True, norm=True, pred_idx=False):
    plt.style.use('ggplot')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    plt.rcParams.update({'font.size': 18})
    params = {'legend.fontsize': 20,
          'legend.handlelength': 2}
    plt.rcParams.update(params)
    fig = plt.figure(figsize=(12,5), dpi=300)
    # if isinstance(ypred, pd.Series) == False:
    # ypred = pd.Series(ypred)
    if norm: 
        y_pred_rev = rev_min_max_func(ypred,ori_tar.values)
        y_rev = rev_min_max_func(y_ori, ori_tar.values)
    else:
        y_rev = y_ori
        y_pred_rev = ypred
    lower_bound = y_rev * 0.95
    upper_bound = y_rev * 1.05
    # if pred_idx: 
    #     y_pred_rev = pd.Series(y_pred_rev, index=pred_idx)
    #     y_rev = pd.Series(y_rev, index=pred_idx)
    #     plt.fill_between(pred_idx,lower_bound,upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.2)

    if pred_partial:
        # y_pred_rev = pd.Series(cap_array(y_pred_rev), index=range(len(ytrain),len(ori_tar)))
        y_pred_rev = pd.Series(y_pred_rev, index=range(len(ori_tar) - len(y_pred_rev),len(ori_tar)))
        y_rev = pd.Series(y_rev, index=range(len(ori_tar) - len(y_pred_rev),len(ori_tar)))
        plt.fill_between(range(len(ori_tar) - len(y_pred_rev),len(ori_tar)),lower_bound,upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.2)

    else:
        y_pred_rev = pd.Series(y_pred_rev, index = range(len(y_pred_rev)))
        y_rev = pd.Series(y_rev, index = range(len(y_rev)))
        plt.fill_between(range(len(y_rev)),lower_bound,upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.2)
    
    plt.plot(y_rev, color ='mediumturquoise',linewidth=3, label='ture_val', alpha =0.6)
    plt.plot(y_pred_rev, color = 'salmon', linewidth=3, label ='pred_val',marker='.', alpha = 0.7)
    # plt.plot(upper_bound, color = 'mediumturquoise', lw = 1,linestyle = '-.', alpha = 0.5)
    plt.legend()
    plt.title(plot_name + ' - Forecast vs Actuals ')
    plot_dir = make_dir(os.path.join(gwd ,'plots','all_predictions/'))
    plt.savefig(plot_dir+ plot_name +'.png')
    plt.show()

def save_img(img_obj, img_name):
    plt.rc('figure', figsize=(15, 7))
    #plt.text(0.01, 0.05, str(model.summary()), {'fontsize': 12}) old approach
    plt.text(0.01, 0.05, str(img_obj), {'fontsize': 10}, fontproperties = 'monospace') # approach improved by OP -> monospace!
    plt.axis('off')
    plt.tight_layout()
    plot_dir = make_dir(os.path.join(gwd ,'plots','all_predictions/'))
    plt.savefig(plot_dir+ img_name + '_modelsummary'+'.png')

def cap_array(arr, cap=100):
    arr[arr > cap] = cap
    return arr

def limit_array(arr, cap=0):
    arr[arr < cap] = cap
    return arr

def feature_bucketizer(col, num_bucket, labels = ''):
    if labels !='':
        new_col = pd.qcut(col, num_bucket, labels=labels)
    else:
        new_col = pd.qcut(col, num_bucket)
  
    return new_col


## Feature Selection 
# Method 1: Backward Elimination 
def xy_split(data, tar_col, arr = False):
    '''
        Split the dataframe into training and test sets
    '''
    df = fill_na(data)
    df_num = df.select_dtypes(['number'])
    n_features = len(df_num.columns)
    
    train_data = df_num.copy()
    train_data = train_data.drop([tar_col], axis = 1)
    # print('The columns in train_data are {}'.format(train_data.columns))
    cols = list(train_data.columns)
    if arr: 
        X = np.nan_to_num(train_data.values)
        y = np.nan_to_num(df_num[tar_col].values)
    else: 
        X = train_data
        y = df_num[tar_col]
    return X, y, cols


def be_fs(data, tar_col, prt=True):
    '''
        Implementing Backward Elimination method to identify 
        the best number of features and the top features 
        Return a set of best features
    '''
    total_feats = len(data.columns)
    X, y,cols = xy_split(data,tar_col)
    pmax = 1
    while (len(cols) > 0):
        p = []
        X_1 = X[cols]
        X_1 = sm.add_constant(X_1)
        model = sm.OLS(y, X_1).fit()
        # print(' pvalues are {} and cols are {}'.format(model.pvalues.values[1:], cols))
        p = pd.Series(model.pvalues.values[1:], index = cols)
        pmax = max(p)
        feature_with_p_max = p.idxmax()
        if (pmax > 0.05):
            cols.remove(feature_with_p_max)
        else:
            break 
    selected_features = cols 
    X_1 = X[selected_features]
    X_1 = sm.add_constant(X_1)
    model = sm.OLS(y, X_1).fit()
    if prt: 
        print('There are total {} features are selected and {} features are eliminated by Backward Elinmination Method '.format( len(selected_features), total_feats-len(selected_features)))
        print('Score with {} features is {}'.format(selected_features, model.rsquared))
    score = model.rsquared
    return selected_features, score


def rfe_fs(data, tar_col,prt = True):
    '''
        Implementing RFE (Recursive Feature Elimination) method to identify 
        the best number of features and the top features 
        Return a set of best features

        Args:
            - cols: a list of features
            
    '''
    X, y, cols = xy_split(data,tar_col, True)
    nof = 0 
    score_dict = {}
    for n in range(1, len(cols)):
        X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.2, random_state = 0)
        model = LinearRegression()
        rfe = RFE(model,n)
        X_train_rfe = rfe.fit_transform(X_train, y_train)
        X_test_rfe = rfe.transform(X_test)
        model.fit(X_train_rfe, y_train)
        score = model.score(X_test_rfe, y_test)
        score_dict[n] = score
    opt_features = max(score_dict, key=score_dict.get)
    
    score = score_dict[opt_features]
   

        #initialize RFE model 
    rfe = RFE(model, opt_features)
    X_rfe = rfe.fit_transform(X, y)
    model.fit(X_rfe, y)
    temp = pd.Series(rfe.support_,index = cols)
    selected_features_rfe = temp[temp==True].index
    if prt: 
        print("Optimum number of features: %d" %opt_features)
        print('Score with {} features is {}'.format(opt_features, score_dict[opt_features]))
        print('The best features are {}'.format(selected_features_rfe))
    return selected_features_rfe.tolist(), score

# Embedded Method 
def embed_fs(data, tar_col, prt=True):
    '''

    '''
    X, y, cols = xy_split(data, tar_col)
    reg = LassoCV()
    reg.fit(X,y)
    score = reg.score(X,y)
    coef = pd.Series(reg.coef_, index = X.columns)
    if prt: 
        print('Lasso picked {} features and eliminated the other {} features'.format(str(sum(coef != 0)), str(sum(coef == 0))))
        print('Best score using built-in LassoCV is {}'.format(score))
    selected_features = coef[coef != 0]
    #plot 
    imp_coef = coef.sort_values()
    if prt:
        plt.style.use('ggplot')
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
        plt.rcParams.update({'font.size': 18})
        params = {'legend.fontsize': 20,
            'legend.handlelength': 2}
        plt.rcParams.update(params)
        fig = plt.figure(figsize=(14,8), dpi=300) 
        imp_coef.plot(kind = "barh", color = antV, alpha =0.6, zorder=2, width=0.85,)

        plt.title('Feature Selection ' + ' - Embedded Feature Selection ')
        plot_dir = make_dir(os.path.join(gwd ,'plots','feature_selection/'))
        plt.savefig(plot_dir+ 'embedded_method' + '_xgboost'+'.png')
        plt.show()
    return selected_features.index.tolist(), score
    
def feature_selection(data, tar_col):
    df_f = fill_na(data)
    df_f = df_f.select_dtypes(['number'])
    cols = df_f.columns

    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df_f[cols])
    scaled_data = pd.DataFrame(scaled, columns = cols)
    best_fs_method = {'RFE': rfe_fs,'embeded_feature':embed_fs,'backward elimination': be_fs }
    fs_score = {}

    for method in best_fs_method.keys():
        _, fs_score[method] = best_fs_method[method](scaled_data, tar_col, prt = False)
        
    best_method = max(fs_score, key=fs_score.get)
    print('The best feature selectionn method is {}'.format(best_method))

    best_features, _ = best_fs_method[best_method](scaled_data, tar_col, prt = True)
    return best_features

def cross_validation(data, splits, shuffle=True):
    df = data.copy()
    df.index = df.index * 10
    kf = KFold(n_splits = splits, shuffle = shuffle, random_state = 2)
    result = next(kf.split(df), None)
    train = df.iloc[result[0]]
    test =  df.iloc[result[1]]
    return train, test
    
def knn_reg(X_train, y_train, X_test, y_test,weights=False):
    if len(y_test.shape) >= 2: 
        knn = MultiOutputRegressor(KNeighborsRegressor(n_neighbors=10))
    else:
        knn = KNeighborsRegressor(n_neighbors=10)
    knn.fit(X_train, y_train)
    predictions = knn.predict(X_test)
    if len(predictions.shape) >= 2: 
        y_test = y_test.flatten()
        predictions = predictions.flatten()
    score = explained_variance_score(predictions,y_test)
    return knn, score

def dtree_reg(X_train, y_train, X_test, y_test, weights=False):
    if len(y_test.shape) >= 2: 
        dt_reg = MultiOutputRegressor(DecisionTreeRegressor())
    else:
        dt_reg = DecisionTreeRegressor()
    dt_reg.fit(X_train, y_train)   
    predictions = dt_reg.predict(X_test)
    print("the shape of predictions and y_test are {} and {}".format(predictions.shape, y_test.shape))
    if len(y_test.shape) >= 2: 
        y_test = y_test.flatten()
        predictions = predictions.flatten()
    # predictions = dt_reg.predict(X_test)
    score = explained_variance_score(predictions,y_test)
    return dt_reg, score

def xgboost_reg(X_train, y_train, X_test, y_test, weights=False):
    #XGBoost
    # print('The shape of X_train is {} and y_train is {} '.format(X_train.shape, y_train.shape))
    if len(y_test.shape) >= 2: 
        xgb = MultiOutputRegressor(xgboost.XGBRegressor(n_estimators=50, learning_rate=0.08, gamma=0, 
                                subsample=0.75, colsample_bytree=1, max_depth=7))
    else: 
        xgb = xgboost.XGBRegressor(n_estimators=50, learning_rate=0.08, gamma=0, 
                                subsample=0.75, colsample_bytree=1, max_depth=7)
    xgb.fit(X_train, y_train)   
    predictions = xgb.predict(X_test)
    print("the shape of predictions and y_test are {} and {}".format(predictions.shape, y_test.shape))
    if len(y_test.shape) >= 2: 
        y_test = y_test.flatten()
        predictions = predictions.flatten()
    score = explained_variance_score(predictions,y_test)
    return xgb, score

def randomforest_reg(X_train, y_train, X_test, y_test,weights=False):
    if len(y_test.shape) >= 2: 
        model_rf = MultiOutputRegressor(RandomForestRegressor(n_estimators=10, oob_score=True, random_state=100))
    else:
        model_rf = RandomForestRegressor(n_estimators=10, oob_score=True, random_state=100)
    model_rf.fit(X_train, y_train) 
    pred_train_rf= model_rf.predict(X_test)
    if len(pred_train_rf.shape) >= 2: 
        y_test = y_test.flatten()
        pred_train_rf = pred_train_rf.flatten()
    rmse = np.sqrt(mean_squared_error(y_test,pred_train_rf))
    score = round(r2_score(y_test, pred_train_rf),4)
    return model_rf, score

def poly_reg(X_train, y_train, X_test, y_test,weights=False):
    # for degree in range(1,3):
        # model = make_pipeline(PolynomialFeatures(degree, interaction_only=False), LassoCV(eps=lasso_eps,n_alphas=lasso_nalpha,max_iter=lasso_iter,cv=5, normalize=False))
    model = PolynomialFeatures(degree=2, interaction_only=False)
    x_train_ploy = model.fit_transform(X_train)
    x_test_ploy = model.fit_transform(X_test)

    model, test_score=lr_ols(x_train_ploy, y_train, x_test_ploy, y_test)

    return model, test_score

def linear_regression(X_train, y_train, X_test, y_test,weights=False):
    #Linear Regression
    regr = linear_model.LinearRegression()
    regr.fit(X_train, y_train)
    score = round(regr.score(X_test,y_test),4)
    return regr,score


def lr_ols(X_train, y_train, X_test, y_test,weights=False):
    regr_ols = sm.OLS(y_train, X_train).fit()
    predictions = regr_ols.predict(X_test)
    score = round(regr_ols.rsquared,4)
    # print(pd.DataFrame({"Feature":X2.columns.tolist(),"Coefficients":clf.coef_[0]})
    return regr_ols, score


# -------- CLASSIFICATION --------- #
def svm_cls(X_train, y_train, X_test, y_test):
    SVM = svm.SVC(decision_function_shape='ovo')
    SVM.fit(X_train, y_train)
    score = round(SVM.score(X_test, y_test),4)
    return SVM, score

def randomforest_cls(X_train, y_train, X_test, y_test):
    RF = RandomForestClassifier(n_estimator=100, max_depth=10, random_state=0)
    RF.fit(X_train, y_train)
    score = round(RF.score(X_test, y_test),4)
    return RF, score


def mlp_cls(X_train, y_train, X_test, y_test):
    mlp = MLPClassifier(solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(150, 10), random_state=1)
    mlp.fit(X_train,y_train)
    score = round(mlp.score(X_test, y_test),4)
    return mlp, score

def logit_cls(X_train, y_train, X_test, y_test):
    lg = LogisticRegression(random_state=0, solver='lbfgs', multi_class= 'multinomial')
    lg.fit(X_train, y_train)
    score = round(lg.score(X_test, y_test), 4)
    return lg, score

def xgboost_classifier(X_train, X_test, y_train, y_test):
    '''
    Train the model with xgboost and plot the importance of each feature 
    Return a trained model and a feature importance plot
    '''
    model = XGBClassifier(max_delta_step=1)
  
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    predictions = [value for value in y_pred]
    accuracy = accuracy_score(y_test, predictions)
    print('The prediction accuracy of XGBoost classifier is {}'.format(accuracy))
    return accuracy


def logit_reg(X_train, y_train, X_test, y_test):
    logreg = LogisticRegression()
    logreg.fit(X_train, y_train)
    y_pred = logreg.predict(X_test)
    score = logreg.score(X_test, y_test)
    # confusion_matrix = confusion_matrix(y_test, y_pred)
    plot_cm(y_test,y_pred)
    return logreg, score


## Run Model 
def models_run(data, label_col='obj_name', tar_col = 'y', normalize = False, test_prop = 0.2,  train =True, load = True, test_objs = False, regress=True,
                pred_window = False, train_window = False, model_name = 'best_model', cross_val=True, shu= True, splits = 10,classification=False,
                 best_model='', label=''):
    # Randomly select batteries for prediction
    # shuffle(obj_list)
    
    obj_list = data[label_col].unique().tolist()
    if test_objs: 
        train_objs = [x for x in obj_list if x not in test_objs]
    else: 
        train_objs = obj_list[-int(len(obj_list)*(1-test_prop/3)):]
        test_objs = [x for x in obj_list if x not in train_objs]
    train_df = data.loc[data['obj_name'].isin(train_objs)]
    # test_df = data.loc[data['obj_name'].isin(test_objs)]
    regr = xgb = rfreg = polyreg = logitreg = logit = rfcls =knnreg = dtreereg= ''
    model_metrics = {}
 
    if regress: 
        models_save = {'LinearRregression': regr,'XGBoost':xgb,'RandomForest_regressor':rfreg,'KNN_regressor':knnreg,'DecisionTree_regressor':dtreereg}
        models = {'LinearRegression': linear_regression,'XGBoost':xgboost_reg,'RandomForest_regressor':randomforest_reg,'KNN_regressor':knn_reg,'DecisionTree_regressor':dtree_reg}
        model_plot = {'LinearRegression': plot_forecast_line,'XGBoost':plot_forecast_line,'RandomForest_regressor':plot_forecast_line,'KNN_regressor':plot_forecast_line,'DecisionTree_regressor':plot_forecast_line}
    if classification:
        models_save = {'SVM_Classifier': svm,'Logistic_Regressor':logit,'RandomForest_Classifier':rfcls}
        models = {'SVM_Classifier': svm_cls,'Logistic_Regressor':logit_cls,'RandomForest_Classifier':randomforest_cls}
        model_plot = {'SVM_Classifier': plot_cm,'Logistic_Regressor':plot_cm,'RandomForest_Classifier':plot_cm}
    
    dt = train_df.reset_index(drop=True)
    # df = dt.dropna()
    if train: 
        df = fill_na(dt)
        df = df.fillna(df.mean())
        df = df.select_dtypes(['number'])
        df = df[df[tar_col] != 0]
        df_num = df.copy()
        n_features = len(df.columns)
        
        if normalize:
            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(df_num)
            df_num = normalization(df_num)

        train_data = df_num.copy()
        train_data = train_data.drop([tar_col], axis = 1)
        # print('The columns in train_data are {}'.format(train_data.columns))

        X = np.nan_to_num(train_data.values)
        y = np.nan_to_num(df_num[tar_col].values)
        # # train = X[:int(len(df_num) * (1-test_prop))]
        # # test = X[-int(len(df_num) * test_prop):]
        # X_train, X_test, y_train, y_test = train_test_split(X, y ,test_size=test_prop)
        X_train = train_data.iloc[:int(len(df_num) * (1-test_prop)),:]
        X_test = train_data.iloc[-int(len(df_num) * test_prop):,:]
        y_train = df_num[tar_col].iloc[:int(len(df_num) * (1-test_prop))]
        y_test = df_num[tar_col].iloc[-int(len(df_num) * test_prop):]
        
    
        for md in models.keys():
            if cross_val:
                r2_scores = []           
                cv = KFold(n_splits=splits, random_state=42, shuffle=shu)
                for train_index, test_index in cv.split(X):
                    X_train, X_test, y_train, y_test = X[train_index], X[test_index], y[train_index], y[test_index]
                    models_save[md], score = models[md](X_train, y_train, X_test, y_test)
                    r2_scores.append(score)
                print('R^2 of {} model after cross validation is {}'.format(md,np.mean(r2_scores)))
                predictions = models_save[md].predict(X_test)
                rmse = np.sqrt(np.mean((predictions - y_test) ** 2))
                model_metrics[md] = float(rmse)
                print("Model {} RMSE: {:.2f}".format(md,rmse))
                model_plot[md](y_train,y_test, predictions, df[tar_col], md,norm= normalize)
            else:
                models_save[md], score = models[md](X_train, y_train, X_test, y_test)
                print('R^2 of {} model is {}'.format(md,score))
                predictions = models_save[md].predict(X_test.values)
                rmse = np.sqrt(np.mean((predictions - y_test.values) ** 2))
                model_metrics[md] = float(rmse)
                print("Model {} RMSE: {:.2f}".format(md,rmse))
                model_plot[md](y_train,y_test, predictions, df[tar_col], md, norm= normalize)


        # if save:
        best_model  = min(model_metrics, key=model_metrics.get)
        print('The best model is {} with the RMSE {} \n'.format(str(best_model), str(model_metrics[best_model])))
        save_model(models_save[best_model], model_name+label)

    if load: 
        best  = load_model(model_name+label)
        for obj in test_objs:
            df = data.loc[data['obj_name'] == obj]
            dt = df.reset_index(drop=True)
        
            df = df.select_dtypes(['number'])
            df_cols = df.columns
            df_num = df.copy()
            # print('The shape of df_num is {}'.format(df_num.shape))
            if df_num.shape[0] > 0:
                    
                if normalize:
                        
                        scaler = MinMaxScaler()
                        scaled = scaler.fit_transform(df_num)
                        df_num = normalization(df_num)

                train_data = df_num.copy()
                train_data = train_data.drop([tar_col], axis = 1)
                # print('Training data col 1: {}'.format(train_data.columns[0]))
                if train_window: 
                    X = np.nan_to_num(train_data.values)[:train_window]
                    y = np.nan_to_num(df_num[tar_col].values)[:train_window]
                else:
                    X = np.nan_to_num(train_data.values)
                    y = np.nan_to_num(df_num[tar_col].values)
                print('\n-------Testing Battery {}--------\n'.format(obj))
                y_pred = linear_smooth(best.predict(X))
                
                if tar_col == 'dy':
                    if normalize: 
                        y = rev_min_max_func(y, df[tar_col])
                    # print('After reversion the y is {}'.format(y))
                    try:
                        print('R^2 of the best model is {}'.format(best.score(X,y)))
                    except:
                        print('R^2 of the best model is {}'.format(best.rsquared))
                    else:
                        pass
                    y_pred_cal = linear_smooth(calibration(best, X, y, ratios =[1.5, 0.5]))
                    # y = rev_min_max_func(df_num['y'].iloc[1:], df['y'])
                    if normalize:
                        # print('The length of predicted y and dy are {} and {}'.format(len(df_num['y'].shift(1).iloc[1:]), len(y_pred[1:])))
                        y_pred = rev_min_max_func(df_num['y'].shift(1).iloc[1:], df['y']) + rev_min_max_func(y_pred[1:], df[tar_col])
                        y_pred_cal = rev_min_max_func(df_num['y'].shift(1).iloc[1:], df['y']) + rev_min_max_func(y_pred_cal[1:], df[tar_col])
                    else:
                        y_pred = df_num['y'].shift(1).iloc[1:].values + y_pred[1:]
                        y_pred_cal = df_num['y'].shift(1).iloc[1:].values + y_pred_cal[1:]
                    # print('The y_pred after addition is {} and original y is {}'.format(df['y']y_pred[:10]))
                    rmse_best = np.sqrt(np.mean((y_pred - df['y'].iloc[1:].values) ** 2))
                    rmse_cal = np.sqrt(np.mean((y_pred_cal - df['y'].iloc[1:].values)**2))          
                    print("Best model's RMSE: %.3f" % rmse_best)
                    print('After calibration RMSE of the best model is %.3f'%(rmse_cal))

                    model_plot[best_model](df_num['y'].values,df_num['y'].values, linear_smooth(y_pred), df['y'], obj+' '+best_model,pred_partial=False, norm=False)
                    model_plot[best_model](df_num['y'].values,df_num['y'].values, linear_smooth(y_pred_cal), df['y'], obj+' After_Calibration',pred_partial=False, norm=False)
                    
                else:
                    try:
                        print('R^2 of the best model is {}'.format(best.score(X,y)))
                    except:
                        print('R^2 of the best model is {}'.format(best.rsquared))
                    else:
                        pass
                    if normalize: 
                        # df_rev =  scaler.inverse_transform(scaled)
                        # df_rev = pd.DataFrame(df_rev, columns = df_cols)
                        all_feat = df.copy()
                        X = all_feat.drop([tar_col],axis=1)
                        y = df[tar_col].values
                        y_pred_cal = linear_smooth(calibration(best, X, y, ratios = [1.2, 0.8]))
                        y_pred_cal = np.array(y_pred_cal)
                        # y_pred = rev_min_max_func(y_pred,df[tar_col].values)
                        if pred_window: 
                            print('The predicted value in position {} is {} '.format(pred_window,y_pred[pred_window]))
                        rmse_best = np.sqrt(np.mean((y_pred - y) ** 2))
                        # print('R^2 of the best model is {}'.format(best.score(X,y)))
                        rmse_cal = np.sqrt(np.mean((y_pred_cal -y[:len(y_pred_cal)])**2))          

                        print("Best model's RMSE: %.3f" % rmse_best)
                        print('After calibration RMSE of the best model is %.3f'%(rmse_cal))
                        model_plot[best_model](y, y, y_pred, df[tar_col], obj+ ' ' +best_model,pred_partial=False, norm = False)
                        model_plot[best_model](y, y, y_pred_cal, df[tar_col], obj+' After Calibration',pred_partial=False, norm = False)

                        
                    
                    else:
                        y_pred_cal = linear_smooth(calibration(best, X, y, ratios = [1.2, 0.8]))
                        y_pred_cal = np.array(y_pred_cal)
                        # print('The first 10 predictions in y_pred {}'.format(y_pred[:10]))
                        rmse_best = np.sqrt(np.mean((y_pred - y) ** 2))
                        # print('R^2 of the best model is {}'.format(best.score(X,y)))
                        rmse_cal = np.sqrt(np.mean((y_pred_cal -y[:len(y_pred_cal)])**2))          

                        print("Best model's RMSE: %.3f" % rmse_best)
                        print('After calibration RMSE of the best model is %.3f'%(rmse_cal))
                        # best_plots = {'linear_regression': plot_linearreg,'XGBoost':plot_xgboost,'linear_regression_ols':plot_linearreg}
                        model_plot[best_model](y, y, y_pred, df[tar_col], obj+ ' ' +best_model,pred_partial=False, norm = normalize)
                        model_plot[best_model](y, y, y_pred_cal, df[tar_col], obj+' After Calibration',pred_partial=False, norm = normalize)




def calibration(model, x, y, calibrated_prop= 0.2, ratios =[1.2, 0.8]):
    '''
        Adjust the prediction every 10 percent of the data 

    ''' 

    n = int(len(x)*calibrated_prop)
    
    x_subset = [x[i:i+n] if (i+n) <= len(x) else x[i:len(x)] for i in range(1, len(x), n)]  
    y_subset = [y[i:i+n] if (i+n) <= len(y) else y[i:len(y)] for i in range(1, len(y), n)]  
    y_subset = np.array(y_subset)
    # y_subset=y_subset.reshape((-1,1))
    tscv = TimeSeriesSplit()
    # print('The input y is {}'.format(y))
    diff = 0  
    predictions = [y[0]]
    
    Y = y_subset[0].tolist()

    for i,subset in enumerate(x_subset): 
        
        y_pred = linear_smooth(model.predict(subset))
        y_pred = rev_min_max_func(y_pred,subset)
        y_pred = pd.Series(y_pred, index= range(0,len(subset)))
        if i == 0:
            ratio = float(y_pred[0]/Y[0])
            if (1.03 < ratio < 10) or (0 < ratio < 0.98):               
                y_pred = y_pred[:10]/ratio + y_pred[10:]
                # predictions.extend(y_pred/ratio)
          
            predictions.extend(y_pred)
        else: 
            Y.extend(y_subset[i])
        
            if (ratios[0] < ratio < 10) or (0 < ratio < ratios[1]):
                # if np.mean(y_pred) > 0:
                print('Before calibration the first 3 predicted y are {}'.format(y_pred[:3]))
                predictions.extend(y_pred/ratio)
                print('After calibration the first 3 predicted y are {}'.format((y_pred/ratio)[:3]))
            # elif ratio < ratios[1]:
            #     predictions.extend(y_pred/ratio)
            else:
                predictions.extend(y_pred)
            try:
                ratio = np.mean(np.divide(Y,predictions[1:]))
            except:
                ratio = 1
  
        # print('The ratio between the real y and predicted y are {}'.format(ratio))
    # print(' The length of true y and predicted y are {}'.format(len(y),len(predictions)))
    return predictions


def butter_lowpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def butter_lowpass_filter(data, cutoff, fs, order=5):
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = lfilter(b, a, data)
    return y

# if __name__ == "__main__":
#     gwd = os.getcwd()
#     # data_dir = os.path.join(gwd, 'ou/','weather/')
#     df = load_data('processed_pred_y.csv','output/', set_index=0)
#     df = df.drop(df.columns[0], axis =1)
#     df = df.dropna(axis=1, how='all')
#     df = df.select_dtypes(['number'])
    
#     #downsampling
#     data_res = resample_class(data, test_objs)
#     #upsampling 
#     # data_ext = add_weights(data, abn_objs, rep_times=5)
#     train, test, _ = split_train_test(data_res,)

#     models_run(df) 