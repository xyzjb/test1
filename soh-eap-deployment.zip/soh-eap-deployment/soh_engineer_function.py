# -*- coding: UTF-8 -*-
'''=================================================
@Project -> File   ：soh-eap-deployment -> soh_engineer_function+soh_preprocessing
@IDE    ：PyCharm
@Author ：xiangnan.jia/haohan.wang
@Date   ：5/24/2021 11:18 AM
=================================================='''
from core.feature_engineer import *
import json
import shutil
import argparse
from pathlib import Path
import sys
import warnings
import os
warnings.filterwarnings("ignore")
logging.getLogger().setLevel(logging.INFO)

y_cols = {'y1': 26, 'y2': 7}
target_col = {'y': 13}
pred_drop_cols = [6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 26, 27, 28, 33, 31, 36]



def find_folder(input_dir, pattern_str_list=['N190269'], pattern_loc='start'):
    # def find_folder(input_dir, pattern_str = 'N1893',pattern_loc = 'start'):

    '''
     Identify all folders with the particular pattern in the name in given input directory
     Return a list of folder names
    '''
    folders = os.listdir(input_dir)
    folders_list = []
    for pattern_str in pattern_str_list:
        if pattern_loc == 'start':
            folders_middle = [os.path.join(input_dir, folder) for folder in folders if folder.startswith(pattern_str)]
        elif pattern_loc == 'end':
            folders_middle = [os.path.join(input_dir, folder) for folder in folders if folder.endswith(pattern_str)]
        elif pattern_loc == 'contain':
            folders_middle = [os.path.join(input_dir, folder) for folder in folders if folder.find(pattern_str) != -1]
        folders_list.extend(folders_middle)
    return folders_list


class Battery(object):
    def __init__(self, battery_dir):
        """Return a Customer object whose name is *name*."""
        self.dir = battery_dir
        self.battery_name = re.search(r'.*\/(.*)', self.dir).group(1)
        print('\nTesting Battery {}'.format(self.battery_name))

    def read_iv_curve(self, file_name):
        iv_curve_data = pd.read_csv(file_name, skiprows=8, encoding='gbk')
        iv_curve_data = iv_curve_data.drop(iv_curve_data.index[:2]).reset_index(drop=True)
        #         print(iv_curve_data.head())
        return iv_curve_data

    def get_cyc_files(self):
        summary = find_folder(self.dir, pattern_str_list=['Summary'], pattern_loc='end')
        cycle = find_folder(summary[0], pattern_str_list=['Cycle'], pattern_loc='end')
        cycs = find_folder(cycle[0], pattern_str_list=['_cy'], pattern_loc='start')
        cyc_no = [re.search(r'.*\/(.*)', cyc).group(1)[-4:] for cyc in cycs]
        #         print(cyc_no)
        cyc_dic = dict(zip(cyc_no, cycs))
        return cyc_dic, cyc_no

    def get_file_name(self, file_dir):
        num_filename = {}
        file_num = 0
        for root, dirs, files in os.walk(file_dir):
            files = [file for file in files if '-0' in file]
            for i in range(len(files)):
                num_filename.update({i + 1: files[i]})
            file_num = len(files)
            break
        return num_filename

    def get_charge_turningindex(self, iv_curve):
        cycle_list = sorted(iv_curve['CycleNo'].unique())
        for cyc in cycle_list:
            sub_df = iv_curve.loc[iv_curve['CycleNo'] == cyc].reset_index(drop=True)
            turning_idx = flat_idx(sub_df['voltage'].astype(float), True)
            if len(turning_idx) >= 1:
                iv_curve.loc[iv_curve['CycleNo'] == cyc, 'turningpt_idx'] = int(turning_idx[0])
            else:
                iv_curve.loc[iv_curve['CycleNo'] == cyc, 'turningpt_idx'] = 0

        iv_curve['turningpt_idx'] = iv_curve['turningpt_idx'].ffill().bfill()
        return iv_curve['turningpt_idx']

    def get_pattern_cycleno_filename(self, file_dir, start_idx):
        folder_name = re.search(r'.*\/(.*)', file_dir).group(1)
        num_filename = self.get_file_name(file_dir)
        sum_file_dir = os.path.join(file_dir, 'step-summary.csv')
        if os.path.exists(sum_file_dir):
            raw_data = pd.read_csv(sum_file_dir, skiprows=11, encoding='iso-8859-1')
            #                 df1 = load_data(filename1, file_dir, skiprows = 10)

            pattern_cycleno = raw_data.drop_duplicates()
            pattern_cycleno['Step'] = pattern_cycleno['Step'] + start_idx
            pattern_cycleno['Mode2'] = pattern_cycleno['Mode2'].astype(int)
            pattern_cycleno['CycleNo'] = pattern_cycleno['CycleNo'] + start_idx
            pattern_cycleno['status'] = pattern_cycleno['CycleNo'].duplicated(keep='last')
            pattern_cycleno = pattern_cycleno[pattern_cycleno['status'] == False][['Pattern', 'CycleNo']]
            pattern_cycleno['file_name'] = pattern_cycleno['Pattern'].map(num_filename)
            print('The number of missing values in file name column is {}'.format(
                pattern_cycleno['file_name'].isnull().sum()))
            pattern_cycleno['file_name'] = pattern_cycleno['file_name'].ffill()
            pattern_cycleno = pattern_cycleno.reset_index(drop=True)
            #             pattern_cycleno['file_name'].fillna('lack file', inplace=True)
            pattern_cycleno['obj_name'] = self.battery_name
            pattern_cycleno = pattern_cycleno.dropna().reset_index(drop=True)
            #             print('The starting CycleNo in file {} is {}'.format(folder_name,start_idx))
            return pattern_cycleno

    def get_step_time(self, pattern_cycleno, iv_curve_data, i, mode):
        idx_close_target = self.find_close_target(iv_curve_data['capacity'].astype(float), 6)
        iv_curve_data = iv_curve_data[iv_curve_data.index == idx_close_target]
        if len(iv_curve_data) > 0:
            pattern_cycleno.loc[i, str(mode) + '_10pct_time'] = iv_curve_data['step time'].iloc[0]
        else:
            pattern_cycleno.loc[i, str(mode) + '_10pct_time'] = np.nan
        pattern_cycleno[str(mode) + '_10pct_time'].fillna(
            pattern_cycleno[str(mode) + '_10pct_time'].dropna().astype(float).mean(), inplace=True)
        #         print(pattern_cycleno['discharge_10pct_time'])
        return pattern_cycleno

    def get_auc(self, pattern_cycleno, iv_curve_data, i, mode, turning_idx):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data['current'] = np.nan_to_num(iv_curve_data['current'].ffill()).astype(float)
        iv_curve_data_before = iv_curve_data.iloc[:int(turning_idx), :]
        iv_curve_data_after = iv_curve_data.iloc[-int(turning_idx):, :]
        pattern_cycleno.loc[i, str(mode) + '_vol_auc_before'] = cal_auc(iv_curve_data_before['voltage'])
        pattern_cycleno.loc[i, str(mode) + '_vol_auc_after'] = cal_auc(iv_curve_data_after['voltage'])
        pattern_cycleno.loc[i, str(mode) + '_cur_auc_before'] = cal_auc(iv_curve_data_before['current'])
        pattern_cycleno.loc[i, str(mode) + '_cur_auc_after'] = cal_auc(iv_curve_data_after['current'])
        pattern_cycleno[str(mode) + '_vol_auc_before'].fillna(
            pattern_cycleno[str(mode) + '_vol_auc_before'].dropna().astype(float).mean(), inplace=True)
        pattern_cycleno[str(mode) + '_vol_auc_after'].fillna(
            pattern_cycleno[str(mode) + '_vol_auc_after'].dropna().astype(float).mean(), inplace=True)
        #         elif mode == 'discharge':
        #             pattern_cycleno.loc[i, str(mode)+'_cur_auc_before'] = auc(iv_curve_data_before['current'])
        #             pattern_cycleno.loc[i, str(mode)+'_cur_auc_after'] = auc(iv_curve_data_after['current'])
        pattern_cycleno[str(mode) + '_cur_auc_before'].fillna(
            pattern_cycleno[str(mode) + '_cur_auc_before'].dropna().astype(float).mean(), inplace=True)
        pattern_cycleno[str(mode) + '_cur_auc_after'].fillna(
            pattern_cycleno[str(mode) + '_cur_auc_after'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_dis_dq(self, pattern_cycleno, iv_curve_data, i, vol_vals, last_cyc, last_q):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data['capacity'] = np.nan_to_num(iv_curve_data['capacity'].ffill()).astype(float)
        current_cyc = max(iv_curve_data['CycleNo'])
        if current_cyc > last_cyc:
            for vol in vol_vals:
                current_q_idx = (iv_curve_data['voltage'] - vol).abs().argsort()[0]
                #                 print(current_q_idx)
                current_q = iv_curve_data['capacity'].iloc[current_q_idx]
                q_delta = current_q - float(last_q[vol])
                #                 print('The first capacity is {} and the second capacity is {} at voltage {}'.format(last_q, current_q, vol))
                pattern_cycleno.loc[i, 'dq_under_' + str(vol)] = np.mean(q_delta)
                pattern_cycleno['dq_under_' + str(vol)] = pattern_cycleno['dq_under_' + str(vol)].replace(
                    [np.inf, -np.inf], np.nan)
                pattern_cycleno['dq_under_' + str(vol)].fillna(
                    pattern_cycleno['dq_under_' + str(vol)].dropna().astype(float).mean(), inplace=True)
                last_q[vol] = current_q
        return pattern_cycleno, last_q

    def get_rest_vt(self, pattern_cycleno, iv_curve_data, mode_col, i, mode):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        max_vol = max(iv_curve_data['voltage'])
        vol_92 = 0.92 * max_vol
        vol_63 = 0.63 * max_vol
        time_92 = iv_curve_data['step time'].iloc[(iv_curve_data['voltage'] - vol_92).abs().argsort()[:1]]
        time_63 = iv_curve_data['step time'].iloc[(iv_curve_data['voltage'] - vol_63).abs().argsort()[:1]]
        pattern_cycleno.loc[i, str(mode) + '_92_time'] = np.mean(time_92)
        pattern_cycleno.loc[i, str(mode) + '_63_time'] = np.mean(time_63)
        pattern_cycleno[str(mode) + '_92_time'] = pattern_cycleno[str(mode) + '_92_time'].replace([np.inf, -np.inf],
                                                                                                  np.nan)
        pattern_cycleno[str(mode) + '_63_time'] = pattern_cycleno[str(mode) + '_63_time'].replace([np.inf, -np.inf],
                                                                                                  np.nan)
        pattern_cycleno[str(mode) + '_63_time'].fillna(
            pattern_cycleno[str(mode) + '_63_time'].dropna().astype(float).mean(), inplace=True)
        pattern_cycleno[str(mode) + '_92_time'].fillna(
            pattern_cycleno[str(mode) + '_92_time'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_constant_val(self, pattern_cycleno, iv_curve_data, i, mode, turning_idx):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data['current'] = np.nan_to_num(iv_curve_data['current'].ffill()).astype(float)
        iv_curve_data_before = iv_curve_data.iloc[:int(turning_idx), :]
        iv_curve_data_after = iv_curve_data.iloc[-int(turning_idx):, :]
        pattern_cycleno.loc[i, str(mode) + '_vol_const'] = np.mean(iv_curve_data_after['voltage'])
        pattern_cycleno.loc[i, str(mode) + '_cur_const'] = np.mean(iv_curve_data_before['current'])
        return pattern_cycleno

    def get_avg_slope(self, pattern_cycleno, iv_curve_data, i, mode, turning_idx):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data['current'] = np.nan_to_num(iv_curve_data['current'].ffill()).astype(float)
        iv_curve_data_before = iv_curve_data.iloc[:int(turning_idx), :]
        iv_curve_data_after = iv_curve_data.iloc[-int(turning_idx):, :].reset_index(drop=True)
        twty_pct_b = int(len(iv_curve_data_before) * 0.2)
        thirty_pct_b = int(len(iv_curve_data_before) * 0.3)
        fourty_pct_b = int(len(iv_curve_data_before) * 0.4)
        twty_pct_a = int(len(iv_curve_data_after) * 0.2)
        thirty_pct_a = int(len(iv_curve_data_after) * 0.3)
        fourty_pct_a = int(len(iv_curve_data_after) * 0.4)
        pattern_cycleno.loc[i, str(mode) + '_vol_slope_20'] = np.mean(
            iv_curve_data_before['voltage'].iloc[-twty_pct_b:].diff().dropna())
        pattern_cycleno.loc[i, str(mode) + '_vol_slope_30'] = np.mean(
            iv_curve_data_before['voltage'].iloc[-thirty_pct_b:].diff().dropna())
        pattern_cycleno.loc[i, str(mode) + '_vol_slope_40'] = np.mean(
            iv_curve_data_before['voltage'].iloc[-fourty_pct_b:].diff().dropna())

        pattern_cycleno.loc[i, str(mode) + '_cur_slope_20'] = np.mean(
            iv_curve_data_after['current'].iloc[:twty_pct_a].diff().dropna())
        pattern_cycleno.loc[i, str(mode) + '_cur_slope_30'] = np.mean(
            iv_curve_data_after['current'].iloc[:thirty_pct_a].diff().dropna())
        pattern_cycleno.loc[i, str(mode) + '_cur_slope_40'] = np.mean(
            iv_curve_data_after['current'].iloc[:fourty_pct_a].diff().dropna())
        return pattern_cycleno

    def get_capacity(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['step time'] = np.nan_to_num(iv_curve_data['step time']).astype(float).astype(int)
        iv_curve_data = iv_curve_data[iv_curve_data['step time'] == 600]
        #             print('The length of iv_curve_data with step-time equals to 600 is {}'.format(len(iv_curve_data)))
        if len(iv_curve_data) > 0:
            pattern_cycleno.loc[i, str(mode) + '_10min_capacity'] = iv_curve_data['capacity'].iloc[0]
        #             print('iv_curve_data capacity first value is {}'.format(pattern_cycleno['discharge_10min_capacity'].loc[i]))
        else:
            pattern_cycleno.loc[i, str(mode) + '_10min_capacity'] = np.nan
        pattern_cycleno[str(mode) + '_10min_capacity'].fillna(
            pattern_cycleno[str(mode) + '_10min_capacity'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_voltage_drop_first(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['step time'] = np.nan_to_num(iv_curve_data['step time']).astype(float).astype(int)
        v1_data = iv_curve_data[iv_curve_data['step time'] == 10]
        v2_data = iv_curve_data[iv_curve_data['step time'] == 20]
        if len(v1_data) == 0 or len(v2_data) == 0:
            delta_v = np.nan
        else:
            v1 = v1_data['voltage'].iloc[0]
            v2 = v2_data['voltage'].iloc[0]
            try:
                delta_v = (float(v1) - float(v2)) / float(v1)
            except:
                delta_v = np.nan
        pattern_cycleno.loc[i, str(mode) + '_voltagedrop_first'] = delta_v
        pattern_cycleno[str(mode) + '_voltagedrop_first'].fillna(
            pattern_cycleno[str(mode) + '_voltagedrop_first'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_voltage_drop_last(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['step time'] = np.nan_to_num(iv_curve_data['step time']).astype(float).astype(int)
        if len(iv_curve_data['step time']) <= 0:
            delta_v = np.nan
        else:
            v1_data = iv_curve_data[iv_curve_data['step time'] == iv_curve_data['step time'].values[-2]]
            v2_data = iv_curve_data[iv_curve_data['step time'] == iv_curve_data['step time'].values[-1]]

            v1 = v1_data['voltage'].iloc[0]
            v2 = v2_data['voltage'].iloc[0]
            try:
                delta_v = (float(v1) - float(v2)) / float(v1)
            except:
                delta_v = np.nan
        pattern_cycleno.loc[i, str(mode) + '_voltagedrop_last'] = delta_v
        pattern_cycleno[str(mode) + '_voltagedrop_last'].fillna(
            pattern_cycleno[str(mode) + '_voltagedrop_last'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_dqdv_ratio(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data['capacity'] = np.nan_to_num(iv_curve_data['capacity'].ffill()).astype(float)
        iv_curve_data[str(mode) + '_dqdv_ratio'] = iv_curve_data['capacity'].diff() / iv_curve_data['voltage'].diff()
        iv_curve_data[str(mode) + '_dqdv_ratio'] = iv_curve_data[str(mode) + '_dqdv_ratio'].replace([np.inf, -np.inf],
                                                                                                    np.nan)
        if mode == 'discharge':
            pattern_cycleno.loc[i, str(mode) + '_dqdv_ratio'] = float(
                np.max(iv_curve_data[str(mode) + '_dqdv_ratio'].dropna()))
        else:
            pattern_cycleno.loc[i, str(mode) + '_dqdv_ratio'] = float(
                np.min(iv_curve_data[str(mode) + '_dqdv_ratio'].dropna()))
        pattern_cycleno[str(mode) + '_dqdv_ratio'].fillna(
            pattern_cycleno[str(mode) + '_dqdv_ratio'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_avg_temp(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['temperature 1'] = np.nan_to_num(iv_curve_data['temperature 1'].ffill()).astype(float)
        iv_curve_data['temperature 2'] = np.nan_to_num(iv_curve_data['temperature 2'].ffill()).astype(float)
        iv_curve_data['temperature 2'] = np.nan_to_num(iv_curve_data['temperature 3'].ffill()).astype(float)
        if -100 < float(np.mean(iv_curve_data['temperature 1'].dropna())) < 100:
            pattern_cycleno.loc[i, str(mode) + '_avg_temp'] = float(np.mean(iv_curve_data['temperature 1'].dropna()))
        elif -100 < float(np.mean(iv_curve_data['temperature 2'].dropna())) < 100:
            pattern_cycleno.loc[i, str(mode) + '_avg_temp'] = float(np.mean(iv_curve_data['temperature 2'].dropna()))
        elif -100 < float(np.mean(iv_curve_data['temperature 3'].dropna())) < 100:
            pattern_cycleno.loc[i, str(mode) + '_avg_temp'] = float(np.mean(iv_curve_data['temperature 3'].dropna()))
        else:
            pattern_cycleno.loc[i, str(mode) + '_avg_temp'] = np.nan
        pattern_cycleno[str(mode) + '_avg_temp'] = pattern_cycleno[str(mode) + '_avg_temp'].replace([np.inf, -np.inf],
                                                                                                    np.nan)

        pattern_cycleno[str(mode) + '_avg_temp'].fillna(
            pattern_cycleno[str(mode) + '_avg_temp'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_ee_pct_change(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['electric energy'] = np.nan_to_num(iv_curve_data['electric energy'].ffill()).astype(float)
        iv_curve_data[str(mode) + '_ee_pct_change'] = iv_curve_data['electric energy'].diff() / iv_curve_data[
            'electric energy'].shift()
        iv_curve_data[str(mode) + '_ee_pct_change'] = iv_curve_data[str(mode) + '_ee_pct_change'].replace(
            [np.inf, -np.inf], np.nan)
        #         print('The first 10 vals in ee_pct_change {}'.format(iv_curve_data['ee_pct_change'].values[:3]))
        pattern_cycleno.loc[i, str(mode) + '_ee_pct_change'] = float(
            np.mean(iv_curve_data[str(mode) + '_ee_pct_change'].dropna()))
        pattern_cycleno[str(mode) + '_ee_pct_change'].fillna(
            pattern_cycleno[str(mode) + '_ee_pct_change'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_ee_delta(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['electric energy'] = np.nan_to_num(iv_curve_data['electric energy'].ffill()).astype(float)
        _ee_delta = iv_curve_data['electric energy'].diff(len(iv_curve_data['electric energy']) - 1) / iv_curve_data[
            'step time'].diff(len(iv_curve_data['step time']) - 1)
        if len(_ee_delta.dropna()) <= 0:
            pattern_cycleno.loc[i, str(mode) + '_ee_delta'] = np.nan
        else:
            #             print('The vals in ee_delta {}'.format(_ee_delta.dropna().values[-1]))
            pattern_cycleno.loc[i, str(mode) + '_ee_delta'] = float(_ee_delta.dropna().values[-1])
        pattern_cycleno[str(mode) + '_ee_delta'] = pattern_cycleno[str(mode) + '_ee_delta'].replace([np.inf, -np.inf],
                                                                                                    np.nan)
        pattern_cycleno[str(mode) + '_ee_delta'].fillna(
            pattern_cycleno[str(mode) + '_ee_delta'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_capacity_changerate(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['capacity'] = np.nan_to_num(iv_curve_data['capacity'].ffill()).astype(float)
        iv_curve_data[str(mode) + '_capacity_change'] = iv_curve_data['capacity'].diff() / (
                iv_curve_data['step time'].diff() / 10)
        iv_curve_data[str(mode) + '_capacity_changerate'] = iv_curve_data[str(mode) + '_capacity_change'].diff()
        iv_curve_data[str(mode) + '_capacity_changerate'] = iv_curve_data[str(mode) + '_capacity_changerate'].replace(
            [np.inf, -np.inf], np.nan)
        #         print('The first 10 vals in ee_pct_change {}'.format(iv_curve_data['ee_pct_change'].values[:3]))
        pattern_cycleno.loc[i, str(mode) + '_capacity_changerate'] = float(
            np.mean(iv_curve_data[str(mode) + '_capacity_changerate'].dropna()) * 100)
        pattern_cycleno[str(mode) + '_capacity_changerate'].fillna(
            pattern_cycleno[str(mode) + '_capacity_changerate'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_total_current(self, pattern_cycleno, iv_curve_data, i, mode):
        phase_length = len(iv_curve_data)
        iv_curve_data['current'] = np.nan_to_num(iv_curve_data['current'].ffill()).astype(float)
        pattern_cycleno.loc[i, str(mode) + '_total_current'] = float(
            np.mean(iv_curve_data['current'].dropna()) * phase_length)
        pattern_cycleno[str(mode) + '_total_current'].fillna(
            pattern_cycleno[str(mode) + '_total_current'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_voltage_changerate(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        iv_curve_data[str(mode) + '_voltage_change'] = iv_curve_data['voltage'].diff() / (
                iv_curve_data['step time'].diff() / 10)
        iv_curve_data[str(mode) + '_voltage_changerate'] = iv_curve_data[str(mode) + '_voltage_change'].diff()

        iv_curve_data[str(mode) + '_voltage_changerate'] = iv_curve_data[str(mode) + '_voltage_changerate'].replace(
            [np.inf, -np.inf], np.nan)
        #         print('The first 10 vals in ee_pct_change {}'.format(iv_curve_data['ee_pct_change'].values[:3]))
        pattern_cycleno.loc[i, str(mode) + '_voltage_changerate'] = float(
            np.mean(iv_curve_data[str(mode) + '_voltage_changerate'].dropna()) * 100)
        pattern_cycleno[str(mode) + '_voltage_changerate'].fillna(
            pattern_cycleno[str(mode) + '_voltage_changerate'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_total_time(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['step time'] = np.nan_to_num(iv_curve_data['step time'].ffill()).astype(float)
        _steptime_delta = iv_curve_data['step time'].diff(len(iv_curve_data['step time']) - 1)
        if len(_steptime_delta.dropna()) <= 0:
            pattern_cycleno.loc[i, str(mode) + '_steptime_delta'] = np.nan
        else:
            #             print('The vals in ee_delta {}'.format(_ee_delta.dropna().values[-1]))
            pattern_cycleno.loc[i, str(mode) + '_steptime_delta'] = float(_steptime_delta.dropna().values[-1])
        pattern_cycleno[str(mode) + '_steptime_delta'] = pattern_cycleno[str(mode) + '_steptime_delta'].replace(
            [np.inf, -np.inf], np.nan)
        pattern_cycleno[str(mode) + '_steptime_delta'].fillna(
            pattern_cycleno[str(mode) + '_steptime_delta'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_voltageaftercharge(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        if len(iv_curve_data['voltage'].dropna()) <= 0:
            pattern_cycleno.loc[i, str(mode) + '_voltage_after'] = np.nan
        else:
            _last_voltage = iv_curve_data['voltage'].dropna().values[-1]
            #             print('The vals in ee_delta {}'.format(_ee_delta.dropna().values[-1]))
            pattern_cycleno.loc[i, str(mode) + '_voltage_after'] = float(_last_voltage)
        pattern_cycleno[str(mode) + '_voltage_after'] = pattern_cycleno[str(mode) + '_voltage_after'].replace(
            [np.inf, -np.inf], np.nan)
        pattern_cycleno[str(mode) + '_voltage_after'].fillna(
            pattern_cycleno[str(mode) + '_voltage_after'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_charge_vol_uptime(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['voltage'] = np.nan_to_num(iv_curve_data['voltage'].ffill()).astype(float)
        if len(iv_curve_data['voltage'].dropna()) <= 0:
            pattern_cycleno.loc[i, str(mode) + '_vol_uptime'] = np.nan
        else:
            cycle_list = sorted(iv_curve_data['CycleNo'].unique())
            uptime = []
            for cyc in cycle_list:
                sub_df = iv_curve_data.loc[iv_curve_data['CycleNo'] == cyc].reset_index(drop=True)
                turning_idx = flat_idx(sub_df['voltage'], True)
                if len(turning_idx) >= 1:
                    uptime.append(turning_idx[0])

            pattern_cycleno.loc[i, str(mode) + '_vol_uptime'] = np.mean(uptime)
        pattern_cycleno[str(mode) + '_vol_uptime'].fillna(
            pattern_cycleno[str(mode) + '_vol_uptime'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def get_charge_current_stabletime(self, pattern_cycleno, iv_curve_data, i, mode):
        iv_curve_data['current'] = np.nan_to_num(iv_curve_data['current'].ffill()).astype(float)
        if len(iv_curve_data['current'].dropna()) <= 0:
            pattern_cycleno.loc[i, str(mode) + '_cur_stabletime'] = np.nan
        else:
            cycle_list = sorted(iv_curve_data['CycleNo'].unique())
            stabletime = []
            for cyc in cycle_list:
                sub_df = iv_curve_data.loc[iv_curve_data['CycleNo'] == cyc].reset_index(drop=True)
                turning_idx = flat_idx(sub_df['current'], False)
                if len(turning_idx) >= 1:
                    stabletime.append(len(sub_df) - turning_idx[0])
            pattern_cycleno.loc[i, str(mode) + '_cur_stabletime'] = np.mean(stabletime)
        pattern_cycleno[str(mode) + '_cur_stabletime'].fillna(
            pattern_cycleno[str(mode) + '_cur_stabletime'].dropna().astype(float).mean(), inplace=True)
        return pattern_cycleno

    def find_close_target(self, df, target):
        if len(df) > 0:
            df['deviation'] = abs(df.sub(target))
            result = df['deviation'].idxmin()
        else:
            result = np.nan
        return result

    def add_all_features(self, cyc_dir, start_idx, pattern_cycleno, thresh=2):
        max_vol = 4.2
        min_vol = 2.5
        vol_vals = np.linspace(min_vol, max_vol, thresh, dtype='float')
        q_dict = {max_vol: 0,
                  min_vol: 0}
        for i in range(len(pattern_cycleno['CycleNo'])):
            file_name = pattern_cycleno.loc[i, 'file_name']
            file_dir = os.path.join(cyc_dir, file_name)
            iv_curve_data = self.read_iv_curve(file_dir)
            iv_curve_data['CycleNo'] = pattern_cycleno['CycleNo'].iloc[i]
            iv_curve_data['turningpt_idx'] = self.get_charge_turningindex(iv_curve_data)

            iv_curve_data['mode'] = np.nan_to_num(iv_curve_data['mode']).astype(int)
            iv_curve_data_discha = iv_curve_data[iv_curve_data['mode'] == 2].reset_index(drop=True)
            iv_curve_data_cha = iv_curve_data[iv_curve_data['mode'] == 1].reset_index(drop=True)
            try:
                rest_start = iv_curve_data[(iv_curve_data['mode'].diff() == 1) & (iv_curve_data['mode'] == 3)].index[0]
                #             rest_end = iv_curve_data.iloc[rest_start:][(iv_curve_data['mode'].diff(-1) !=0) & (iv_curve_data['mode']==3)].index
                iv_curve_data_rest = iv_curve_data.iloc[rest_start:][iv_curve_data['mode'] == 3].reset_index(drop=True)
                mode_iv_curve = {'charge': iv_curve_data_cha,
                                 'discharge': iv_curve_data_discha,
                                 'rest': iv_curve_data_rest}
            except:
                break
            if i >= 1:
                last_cyc = pattern_cycleno['CycleNo'].iloc[i - 1]
            else:
                last_cyc = 0
            for mode in mode_iv_curve.keys():
                # Features during Discharge
                #                 pattern_cycleno = self.get_step_time(pattern_cycleno, mode_iv_curve[mode],i+start_idx, mode)
                #             print('After adding discharge 10% time the columns are {}'.format(pattern_cycleno.columns))
                pattern_cycleno = self.get_capacity(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode)
                #             print('After adding discharge 10min capacity the columns are {}'.format(pattern_cycleno.columns))
                #                 pattern_cycleno = self.get_voltage_drop_first(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                #             print('After adding voltage drop the columns are {}'.format(pattern_cycleno.columns))
                pattern_cycleno = self.get_voltage_drop_last(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode)
                #             print('After adding voltage drop the columns are {}'.format(pattern_cycleno.columns))

                #                 pattern_cycleno = self.get_dqdv_ratio(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                pattern_cycleno = self.get_avg_temp(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode)
                #                 pattern_cycleno = self.get_ee_pct_change(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                pattern_cycleno = self.get_total_current(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode)

                #                 pattern_cycleno = self.get_voltage_changerate(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                pattern_cycleno = self.get_capacity_changerate(pattern_cycleno, mode_iv_curve[mode], i + start_idx,
                                                               mode)
                #                 pattern_cycleno = self.get_ee_delta(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                pattern_cycleno = self.get_total_time(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode)
                if mode == 'charge':
                    #                     pattern_cycleno = self.get_voltageaftercharge(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                    pattern_cycleno = self.get_charge_vol_uptime(pattern_cycleno, mode_iv_curve[mode], i + start_idx,
                                                                 mode)
                    #                     pattern_cycleno = self.get_charge_current_stabletime(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode)
                    pattern_cycleno = self.get_auc(pattern_cycleno, mode_iv_curve[mode], i + start_idx, mode,
                                                   iv_curve_data['turningpt_idx'].mode()[0])
                #                     pattern_cycleno = self.get_constant_val(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode, iv_curve_data['turningpt_idx'].mode()[0])
                #                     pattern_cycleno = self.get_avg_slope(pattern_cycleno, mode_iv_curve[mode],i+start_idx,mode, iv_curve_data['turningpt_idx'].mode()[0])
                if mode == 'discharge':
                    pattern_cycleno, q_dict = self.get_dis_dq(pattern_cycleno, mode_iv_curve[mode], i + start_idx,
                                                              vol_vals, last_cyc, q_dict)
                if mode == 'rest':
                    pattern_cycleno = self.get_rest_vt(pattern_cycleno, iv_curve_data, 'mode', i, mode)
        return pattern_cycleno

    def process_all_cycs(self):
        cyc_dic, cyc_n = self.get_cyc_files()
        battery_summaries = []
        end_idx = 0
        for i, num in enumerate(sorted(cyc_n)):
            cyc_dir = cyc_dic[num]
            try:
                print('cycle dir is {}'.format(cyc_dir[-7:]))
            except:
                print('cycle dir is {}'.format(cyc_dir))
            iv_curve_files = find_folder(cyc_dir, pattern_str_list=['-0'], pattern_loc='contain')
            pattern_cycleno = self.get_pattern_cycleno_filename(cyc_dir, 0)
            if (pattern_cycleno is not None):
                #                 if len(pattern_cycleno) > 0:
                df_ad = self.add_all_features(cyc_dir, 0, pattern_cycleno)
                #                 print(df_ad.head())
                #                 end_idx = df_ad['CycleNo'].iloc[-1]
                cyc_name = re.search(r'.*\/(.*)', cyc_dir).group(1)
                battery_summaries.append(df_ad)
        if len(battery_summaries) > 0:
            frame = pd.concat(battery_summaries, axis=0, ignore_index=True)
            print('Number of rows in concatenated dataset: ', len(frame))
            return frame

    def export_df(self):
        targets = ['CycleNo', 'discharge_10pct_time', 'discharge_10min_capacity',
                   'discharge_voltagedrop_first', 'discharge_voltagedrop_last',
                   'charge_10pct_time', 'charge_10min_capacity',
                   'charge_voltagedrop_first', 'charge_voltagedrop_last',
                   'discharge_dqdv_ratio', 'charge_dqdv_ratio',
                   'discharge_avg_temp', 'charge_avg_temp',
                   'discharge_ee_pct_change', 'charge_ee_pct_change',
                   'discharge_total_current', 'charge_total_current',
                   'discharge_voltage_changerate', 'charge_voltage_changerate',
                   'discharge_capacity_changerate', 'charge_capacity_changerate',
                   'discharge_ee_delta', 'charge_ee_delta', 'charge_voltage_after',
                   'discharge_steptime_delta', 'charge_steptime_delta',
                   'charge_vol_uptime', 'charge_cur_stabletime',
                   'charge_vol_auc_before', 'charge_vol_auc_after',
                   'charge_cur_auc_before', 'charge_cur_auc_after',
                   'charge_vol_const', 'charge_cur_const',
                   'charge_vol_slope_20', 'charge_vol_slope_30', 'charge_vol_slope_40',
                   'charge_cur_slope_20', 'charge_cur_slope_30', 'charge_cur_slope_40',
                   'dq_under_4.2', 'dq_under_2.5', 'rest_63_time', 'rest_92_time', 'obj_name']
        sum_a_folder = find_folder(self.dir, pattern_str_list=['Summary'], pattern_loc='end')
        lev3_df = load_data(self.battery_name + '-A.csv', sum_a_folder[0] + '/', skiprows=10)
        lev3_df = lev3_df.rename(columns={lev3_df.columns[0]: 'CycleNo'})

        print('The length of lev3 df is {}.'.format(len(lev3_df['CycleNo'])))

        processed_lev2 = self.process_all_cycs()
        current_cols = processed_lev2.columns
        tar_cols = [col for col in current_cols if col in targets]
        processed_lev2 = processed_lev2[tar_cols]
        if processed_lev2 is not None:
            processed_lev2['CycleNo'] = np.arange(1, len(processed_lev2) + 1)
            #         print(processed_lev2.head())
            final_lev3 = lev3_df.join(processed_lev2.set_index('CycleNo'), on='CycleNo')
            #         final_lev3 = pd.merge(lev3_df.reset_index(drop=True), processed_lev2.reset_index(drop=True), on='CycleNo',how='outer')
            return final_lev3, processed_lev2


def get_filelist(dir):
    Filelist = []
    for home, dirs, files in os.walk(dir):
        for filename in files:
            Filelist.append(os.path.join(home, filename))
    return Filelist

class SOH_Proprocesser:
    def __init__(self):
        pass

    def generate_dataset(self, df):
        pred_df = df.copy()
        pred_df.rename(columns={pred_df.columns[target_col['y']]: 'y'}, inplace=True)
        pred_df = pred_df.reset_index(drop=True)
        pred_cols = pred_df.columns[pred_drop_cols].tolist()
        pred_df = pred_df.drop(pred_cols, axis=1)
        return pred_df

    def fillna(self, df):
        df = df.interpolate(method='linear')
        df['y'].iloc[0] = 100
        df = df.reset_index(drop=True)
        return df

    def filter_soh(self, df):
        df = df.loc[df['y'] > 0]
        neg_bat = df.loc[df['y'] < 0, 'obj_name'].unique()
        df = df.loc[~df['obj_name'].isin(neg_bat)].reset_index(drop=True)
        df = df[df['obj_name'].notna()]
        return df

    def clean_anomaly(self, df):
        df = df.ffill().bfill()
        pred_ab_y = remove_anomaly(df, 'obj_name', 15, tar_col='y')
        return pred_ab_y

    def smooth_soh(self, df):
        sm_pred = groupby_apply(df, 'y', 'obj_name', ma_smooth, plotname='smoothing SOHs -  MA Method')
        return sm_pred

    def scaling_soh(self, df):
        sc_pred = groupby_apply(df, 'y', 'obj_name', scale_data, b_plot=False, plotname='scaling - SOHs')
        return sc_pred

    def label_abnormal_batteries(self, df):
        pred_ades = drop_type1(df)
        return pred_ades


def run_preprocessor(data):
    PProcessor = SOH_Proprocesser()
    # Step 1: Generate df
    gd = PProcessor.generate_dataset(data)
    logging.info('(AESC-SOH) --> Finish Step 1 Dataset Generation Process')

    ## Step 2: Fill missing values
    # print(gd.isnull().sum())
    fn = PProcessor.fillna(gd)
    # print(fn.isnull().sum())
    logging.info('(AESC-SOH) --> Finish Step 2 Fill Missing Value Process')

    ## Step 3: Filter SOH
    fs = PProcessor.filter_soh(fn)
    # print(fs.tail())
    logging.info('(AESC-SOH) --> Finish Step 3 Filter SOH Process')

    ## Step 4: Remove Anomaly
    ra = PProcessor.clean_anomaly(fs)
    logging.info('(AESC-SOH) --> Finish Step 4 Remove Anomaly SOH Process')
    # print(ra.tail())

    # ## Step 5: Smooth SOH
    sms = PProcessor.smooth_soh(ra)
    logging.info('(AESC-SOH) --> Finish Step 5 Smooth SOH Process')
    # ## Step 6: Scale SOH
    scs = PProcessor.scaling_soh(sms)
    logging.info('(AESC-SOH) --> Finish Step 6 Scale SOH Process')
    # print(max(scs['y']))

    # ## Step 7: Label Abnormal Batteries
    lab = PProcessor.label_abnormal_batteries(scs)
    logging.info('(AESC-SOH) --> Finish Step 7 Label Abnormal Cell Process')
    return lab

def main(args):
    parser = argparse.ArgumentParser(description='feature engineer code')
    parser.add_argument("--features_output", type=str, required=True)
    args = parser.parse_args(args)

    # data_dir = args.workspace2
    # print("-----------------------------data_dir---------------------------------")
    # print(data_dir)
    # Filelist = get_filelist(data_dir)
    # for file in Filelist:
    #     print(file)
    #     break
    print("-----------------------------start train---------------------------------")
    all_battery_dirs = find_folder("/data/soh/data/", pattern_str_list=['N190269', 'N192642'], pattern_loc='start')
    print(all_battery_dirs)
    for bat in all_battery_dirs:
        inichara = find_folder(bat, pattern_str_list=['01_'], pattern_loc='start')
        for fd in inichara:
            try:
                shutil.rmtree(fd)
                print('remove battery {} folder'.format(bat))
            except OSError as e:  ## if failed, report it back to the user ##
                print("Error: %s - %s." % (e.filename, e.strerror))
    df3 = []
    for bat_dir in all_battery_dirs:
        bat = Battery(bat_dir)
        bat_name = re.search(r'.*\/(.*)', bat_dir).group(1)
        try:
            if os.path.exists(os.path.join(os.getcwd(), 'lev3_sample_reduced/', bat_name + '.csv')) != True:
                bat_df, lev2_sum = bat.export_df()
                df3.append(bat_df)
                write_csv(bat_df, bat_name, out_dir='lev3_sample_reduced/')
                print('Finish writing battery {}'.format(bat_name))
            else:
                print('The battery {} file already exists'.format(bat_name))
        except Exception as e:
            print(e)
            pass
    lev3 = pd.concat(df3)
    lev3 = run_preprocessor(lev3)
    print(lev3.head())
    print('the length of all batteries data is {}'.format(len(lev3)))

    Path(args.features_output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.features_output, 'w') as sum_path:
        lev3.to_csv(sum_path, index=False)


if __name__ == '__main__':
    main(sys.argv[1:])
