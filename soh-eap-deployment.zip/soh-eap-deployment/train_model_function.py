# -*- coding: UTF-8 -*-
'''=================================================
@Project -> File   ：soh-eap-deployment -> train_model_function + MySQL Storage 
@IDE    ：PyCharm
@Author ：xiangnan.jia & Haohan Wang
@Date   ：5/24/2021 1:56 PM
=================================================='''
from core.feature_engineer import *
from core.ts_models import *
import argparse
import json
from pathlib import Path
import pandas as pd
import numpy as np
import logging
import mysql.connector as mysql
import warnings
import sys

warnings.filterwarnings("ignore")
logging.getLogger().setLevel(logging.INFO)


class CellExistsError(Exception):
    def __init__(self, message):
        self.message = message


class ForecastSaver:
    def __init__(self):
        self.database = "MySQL"

    def save_to_param(self, avg_acc, optimal_input_data=200, max_input_data=500):
        db_connection = mysql.connect(
            user='battery_soh_user',
            password='Battery_soh123!',
            host="10_65_30_70".replace("_", "."),
            port="3306",
            database="battery_soh"
        )
        cursor = db_connection.cursor(buffered=True)
        try:
            cursor.execute("SELECT * FROM global_configuration where avg_accuracy=%s", (avg_acc,))
            if cursor.fetchone() != None:
                cursor.execute(
                    'INSERT INTO global_configuration (avg_accuracy, optimal_input_data, max_input_data) VALUES (%s,%s,%s) ON DUPLICATE KEY UPDATE avg_accuracy=VALUES(avg_accuracy)',
                    (avg_acc, optimal_input_data, max_input_data,))
                db_connection.commit()
                raise CellExistsError('Average Accuracy {} already exists!'.format(avg_acc))

            else:
                cursor.execute(
                    'INSERT INTO global_configuration (avg_accuracy, optimal_input_data, max_input_data ) VALUES (%s,%s,%s)',
                    (avg_acc, optimal_input_data, max_input_data,))
                logging.info(' Forecast Parameters info Stored!')
                db_connection.commit()
                cursor.close()

        except Exception as e:
            logging.info(' Forecast Parameters info storage failed --> ERROR: {}'.format(str(e)))
            db_connection.rollback()
            cursor.close()
        db_connection.close()

    def save_to_cellinfo(self, cell_num, accuracy, label=0):
        db_connection = mysql.connect(
            user='battery_soh_user',
            password='Battery_soh123!',
            host="10_65_30_70".replace("_", "."),
            port="3306",
            database="battery_soh"
        )
        cursor = db_connection.cursor(buffered=True)
        try:
            cursor.execute("SELECT * FROM battery where device_number=%s", (cell_num,))
            if cursor.fetchone() != None:
                cursor.execute(
                    'INSERT INTO battery (device_number, status, precision_rate ) VALUES (%s,%s,%s) ON DUPLICATE KEY UPDATE precision_rate=VALUES(precision_rate)',
                    (cell_num, label, accuracy,))
                db_connection.commit()
                raise CellExistsError('Cell {} already exists!'.format(cell_num))

            else:
                cursor.execute('INSERT INTO battery (device_number, status, precision_rate ) VALUES (%s,%s,%s)',
                               (cell_num, label, accuracy,))
                logging.info(' Battery info Stored!')
                db_connection.commit()
                cursor.close()
        #                 db_connection.close()
        except Exception as e:
            logging.info(' Battery info storage failed --> ERROR: {}'.format(str(e)))
            logging.info(' Forecast Parameters info storage failed --> ERROR: {}'.format(str(e)))
            db_connection.rollback()
            cursor.close()
        db_connection.close()

    def save_to_sohforecast(self, cell_num, cycle_num, label, soh):
        db_connection = mysql.connect(
            user='battery_soh_user',
            password='Battery_soh123!',
            host="10_65_30_70".replace("_", "."),
            port="3306",
            database="battery_soh"
        )
        cursor = db_connection.cursor(buffered=True)
        try:
            cursor.execute("SELECT * FROM battery_soh where device_number=%s and cycle=%s", (cell_num, cycle_num,))
            if cursor.fetchone() != None:
                cursor.execute(
                    'INSERT INTO battery_soh (cycle, device_number, status, soh) VALUES (%s,%s,%s,%s) ON DUPLICATE KEY UPDATE soh=VALUES(soh)',
                    (cycle_num, cell_num, label, soh,))
                db_connection.commit()
                #                 db_connection.close()
                raise CellExistsError('Cell {} Cycle {} already exists!'.format(cell_num, cycle_num))
            else:
                cursor.execute('INSERT INTO battery_soh (cycle, device_number, status, soh) VALUES (%s,%s,%s,%s)',
                               (cycle_num, cell_num, label, soh,))
                logging.info(' SOH Forecast info Stored!')
                db_connection.commit()
                cursor.close()
        #                 db_connection.close()
        except Exception as e:
            logging.info(' SOH Forecast info storage failed --> ERROR: {}'.format(str(e)))
            db_connection.rollback()
            cursor.close()
        db_connection.close()


def metrics(y_true, y_pred):
    '''
    Takes in the real test data and the predcited results and calculate the predicted error
    Returns printed metrics values (RMSE and MAPE)
    '''

    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    # scores.append(rmse)
    return rmse, mape


# Ori Cycle Forecast Data
def label_cell(df, tar_col, idx_col='CycleNo', lab_col='obj_name'):
    dfs = []
    for battery in df[lab_col].unique():
        df_sub = df.loc[df[lab_col] == battery]
        if len(df_sub) > 0:
            if df_sub[idx_col].iloc[-1] <= 600:
                if df_sub[tar_col].iloc[-1] < 85:
                    df_sub['chk_abn'] = 1
                else:
                    df_sub['chk_abn'] = 0
            else:
                if df_sub[tar_col].iloc[-1] < 75:
                    df_sub['chk_abn'] = 1
                else:
                    df_sub['chk_abn'] = 0
        dfs.append(df_sub)
    data = pd.concat(dfs)
    return data



def train_model(train_df, test_df='', train=True, label_col='obj_name', status_col='chk_abn',
                xwin=200, y_win=1000, reduce_dim=10, tar_col='y', cross_val=False, normalize=False, regress=False,
                classification=False, data_method='2', splits=5, shu=True, method=False, grid_search=False):
    rfreg = ""
    model_metrics = {}
    cyc_grid = {}
    model_grid = defaultdict(list)
    models_save = {}
    if grid_search:
        xwin = np.linspace(100, 500, 5, dtype=int)

    if type(xwin) == int:
        xwin = [xwin]
    for x_win in xwin:
        print('\n----------------Testing training cycle number {}----------------\n'.format(x_win))

        models = {'RandomForest_regressor': randomforest_reg}

        if data_method == '1':
            X_train, y_train = get_every_n(train_df, tar_col=tar_col, x_win=x_win, y_win=y_win, reduce_dim=reduce_dim,
                                           train=True, normalize=normalize, method=method)


        elif data_method == '2':
            X_train, y_train = get_multi_output(train_df, tar_col=tar_col, x_win=x_win, y_win=y_win,
                                                reduce_dim=reduce_dim, train=True, normalize=normalize, method=method)

        elif data_method == '3':
            X_train, y_train = get_equal_dist(train_df, tar_col=tar_col, x_win=x_win, y_win=y_win,
                                              reduce_dim=reduce_dim, train=True, normalize=normalize, method=method)

        if train:
            for md in models.keys():
                if cross_val:
                    r2_scores = []
                    cv = KFold(n_splits=splits, random_state=42, shuffle=shu)
                    for train_index, test_index in cv.split(X_train):
                        X_train_cv, X_val, y_train_cv, y_val = X_train[train_index], X_train[test_index], y_train[
                            train_index], y_train[test_index]
                        # print('The shape of X_train and y_train is {} and {}'.format(X_train_cv.shape, y_train_cv.shape))
                        models_save[md + '_' + str(x_win)], score = models[md](X_train_cv, y_train_cv, X_val, y_val)
                        r2_scores.append(score)
                    print('\nR^2 of {} model after cross validation is {}'.format(md, np.mean(r2_scores)))

                    predictions = models_save[md + '_' + str(x_win)].predict(X_val)
                    rmse = np.sqrt(np.mean((predictions - y_val) ** 2))
                    mape = np.mean(np.abs((y_val - predictions) / y_val)) * 100
                    model_metrics[md + '_' + str(x_win)] = float(mape)
                    print("Model {} MAPE: {:.2f}".format(md, mape))
                    if len(predictions.shape) >= 2:
                        y_train_cv = y_train_cv.flatten()
                        y_val = y_val.flatten()
                        predictions = predictions.flatten()
                        # predictions = limit_array(predictions)
                    # print('y_train shape is {} and predictions shape is {}'.format(predictions.shape,y_train_cv.shape))

                else:
                    X_train1, X_val1 = np.nan_to_num(X_train[:int(0.8 * len(X_train))]), np.nan_to_num(
                        X_train[-int(0.2 * len(X_train)):])
                    y_train1, y_val1 = np.nan_to_num(y_train[:int(0.8 * len(y_train))]), np.nan_to_num(
                        y_train[-int(0.2 * len(y_train)):])
                    # print('The shape of X_train and y_train is {} and {}'.format(X_train.shape, y_train.shape))

                    models_save[md + '_' + str(x_win)], score = models[md](X_train1, y_train1, X_val1, y_val1)
                    print('\nR^2 of {} model is {}'.format(md, score))
                    predictions = models_save[md + '_' + str(x_win)].predict(X_val1)
                    if len(y_train.shape) >= 2:
                        y_train1 = y_train1.flatten()
                        y_val1 = y_val1.flatten()
                        predictions = predictions.flatten()
                        predictions = limit_array(predictions)
                    rmse = np.sqrt(np.mean((predictions - y_val1) ** 2))
                    mape = np.mean(np.abs((y_val1 - predictions) / y_val1)) * 100
                    model_metrics[md + '_' + str(x_win)] = float(mape)
                    print("Model {} MAPE: {:.2f}".format(md, mape))

                model_grid[md].append({x_win: float(mape)})

            print('The best model is {} with MAPE {} '.format(str(min(model_metrics, key=model_metrics.get)),
                                                              float(min(model_metrics.values()))))
            cyc_grid[x_win] = [min(model_metrics, key=model_metrics.get), float(min(model_metrics.values()))]
    if len(test_df) > 0:
        best_model = min(cyc_grid.items(), key=lambda x: x[1][1])[1][0]
        best = models_save[str(list(models.keys())[0]) + '_' + str(x_win)]
        preds = {}
        ys = {}
        dfs = []
        mapes = []
        max_cyc = {}
        bat_lab = {}

        test_objs = test_df[label_col].unique()
        for i, obj in enumerate(test_objs):
            df = test_df[test_df[label_col] == obj]
            print('The length of the cell {} has {} data points'.format(obj, len(df)))
            if len(df) > 0:
                max_cyc_num = df.CycleNo.values[-1]
                bat_lab[obj] = int(df['chk_abn'].unique()[0])
                max_cyc[obj] = max_cyc_num
                print('Battery {} has the maximum {} cycles'.format(obj, max_cyc_num))
                if data_method == '1':
                    X_test, y_test = get_every_n(df, tar_col=tar_col, x_win=x_win, y_win=y_win, reduce_dim=reduce_dim,
                                                 train=False, normalize=normalize, method=method)
                elif data_method == '2':
                    X_test, y_test = get_multi_output(df, tar_col=tar_col, x_win=x_win, y_win=y_win,
                                                      reduce_dim=reduce_dim, train=False, normalize=normalize,
                                                      method=method)
                    if max_cyc_num < y_win:
                        y_test_real = y_test[:int(max_cyc_num // 100) + 1]
                    else:
                        y_test_real = y_test
                elif data_method == '3':
                    X_test, y_test = get_equal_dist(df, tar_col=tar_col, x_win=x_win, y_win=y_win,
                                                    reduce_dim=reduce_dim, train=False, normalize=normalize,
                                                    method=method)
                    if max_cyc_num < y_win:
                        y_test_real = y_test[:int((max_cyc_num // 100) / 10 * len(y_test))]
                    else:
                        y_test_real = y_test

                if len(X_test) >= 1:
                    y_pred = linear_smooth(best.predict(X_test))
                    y_pred[y_pred < 0] = 0
                    if tar_col == 'dy':
                        if normalize:
                            y_test = rev_min_max_func(y_test, df[tar_col])
                        try:
                            print('R^2 of the {} model is {}'.format(str(best_model), best.score(X_test, y_test)))
                        except:
                            print('R^2 of the {} model is {}'.format(str(best_model), best.rsquared))
                        else:
                            pass
                        if normalize:
                            y_pred = rev_min_max_func(df['y'].shift(1).iloc[1:], df['y']) + rev_min_max_func(y_pred[1:],
                                                                                                             df[
                                                                                                                 tar_col])
                        else:
                            y_pred = df['y'].shift(1).iloc[1:].values + y_pred[1:]

                    else:
                        if normalize:
                            y_test = rev_min_max_func(y_test, df[tar_col])
                            y_pred = rev_min_max_func(y_pred, df[tar_col])
                        # print('The real SOH value is {}'.format(len(y_test)))
                        if len(y_pred) > 1:
                            preds[obj] = y_pred
                            # ys[obj] = y_test[i*x_win:(i+1)*x_win]
                            ys[obj] = y_test
                        else:
                            preds[obj] = np.mean(y_pred)
                            # ys[obj] = np.mean(y_test[i])
                            ys[obj] = np.mean(y_test)

                    if len(y_test.shape) >= 2:
                        y_test = np.array(y_test).flatten()
                        y_pred = np.array(y_pred).flatten()

                    mape_df = pd.DataFrame({obj + '_MAPE': metrics(y_test, y_pred)[1]}, index=range(1))
                    mapes.append(mape_df)
                    dataframe = pd.DataFrame({obj + '_ytrue': y_test, obj + '_ypred': y_pred}, index=range(len(y_pred)))

                    dfs.append(dataframe)
                    y_idx = np.linspace(x_win + 1, y_win, 100, dtype='int')
                    y_1 = df[tar_col].iloc[:-100]
                    y_2 = df[tar_col].iloc[-100:]
                    coeffs = np.polyfit(y_2.index, y_2, 1)
                    x = range(len(df[tar_col]), 1000 + 1)
                    y_ext = pd.Series(x * coeffs[0] + coeffs[1], index=x)
                    # print('The length of y_2 after nan appending is {}'.format(len(y_ext)))
                    y_2 = y_2.append(y_ext)
                    y_ext = y_1.append(y_2)

                    y_ext = pd.Series(y_ext.values,
                                      index=range(len(df[tar_col]) - 1, len(df[tar_col]) + len(y_ext) - 1))
                    y_train = df[tar_col] + y_ext
                    y_pred = pd.Series(y_pred, index=range(x_win+100, 1100, 100))
                    ForecastSaver.save_to_cellinfo(str(obj), 100-float(metrics(y_test, y_pred)[1]),
                                                   int(df[status_col].tolist()[-1]))
                    for idx in y_pred.index:
                        ForecastSaver.save_to_sohforecast(str(obj), idx, int(df[status_col].tolist()[-1]),
                                                          float(y_pred[idx]))
        try:
            y_real_len = len(y_test_real)

            rmse_best = np.sqrt(np.mean((np.array(list(preds.values())).flatten()[:y_real_len] - np.array(
                list(ys.values())).flatten()[:y_real_len]) ** 2))
            mape_best = np.mean(np.abs((np.array(list(ys.values())).flatten()[:y_real_len] - np.array(
                list(preds.values())).flatten()[:y_real_len]) / np.array(list(ys.values())).flatten()[
                                                                :y_real_len])) * 100

            print("\n Prediction MAPE: %.3f" % float(mape_best))
            # print("\n---The programe took %s seconds to predict ---\n" % (time.time() - start_time))
            #             frame = pd.concat(dfs, axis=1, ignore_index=False)
            #             frame.index = np.arange(300, 1000, 100)
            # index = np.arange(300,1000,100)
            mape_frame = pd.concat(mapes, axis=1, ignore_index=False)
            mape_frame['MAPE'] = mape_frame.iloc[0].mean(axis=0)
            avg_acc = 100 - mape_frame.iloc[0].mean(axis=0)
            ForecastSaver.save_to_param(avg_acc=float(avg_acc))

        except Exception as e:
            print('No Prediction Returned due to the error: {}'.format(e))


def main(args):
    parser = argparse.ArgumentParser(description='soh train models')
    parser.add_argument("--features_data", type=str, required=True)
    args = parser.parse_args(args)
    data = pd.read_csv(args.features_data)
    print("-----------------------features data-------------------------")
    data = data.dropna(axis=1, how='all')
    data = data.loc[:, data.isnull().mean() < .7]
    data = data.ffill().bfill()
    print('There are total {} batteries in the dataset'.format(len(data['obj_name'].unique())))

    test_objs = ['N190269-01-54-01-12', 'N190269-01-54-01-14', 'N190269-01-54-01-02',
                 'N192642-11-47-01-05', 'N190269-02-55-01-08', 'N192642-11-47-01-08',
                 'N192642-11-47-01-20', 'N192642-11-47-01-15', 'N192642-02-55-01-08',
                 'N192642-40-4c-01-32', 'N192642-11-47-01-20', 'N192642-11-47-01-16',
                 'N192642-11-47-01-06']
    train_res, test_res, _ = split_train_test(data, test_objs=test_objs)
    print('The shape of train_res is {} and test_res is {}'.format(train_res.shape, test_res.shape))
    train, test, _ = split_train_test(data, test_objs=test_objs)
    train_model(train_res, test_res, train=True, data_method='2', regress=True)


if __name__ == '__main__':
    ForecastSaver = ForecastSaver()
    main(sys.argv[1:])

            

