from core.feature_engineer import *
import logging
import shutil
import argparse
from pathlib import Path
import sys, json
# TODO
# Figure out the function used from feature_engineer and add them here as supporting function 

y_cols ={'y1':26,'y2':7}
target_col = {'y': 13}
pred_drop_cols = [6,7,8,9,10,11,12,14,15,16,17,18,19,26,27,28,33,31,36]


class SOH_Proprocesser: 
    def __init__(self): 
        pass

    def generate_dataset(self, df):
        pred_df = df.copy()
        pred_df.rename(columns={pred_df.columns[target_col['y']]:'y'}, inplace=True)
        pred_df=pred_df.reset_index(drop=True)
        pred_col_drop = pred_df.columns[pred_drop_cols].tolist()
        return pred_df
    

    def fillna(self, df):
        df = df.interpolate(method='linear')
        df['y'].iloc[0] = 100
        df = df.reset_index(drop=True)
        return df

    def filter_soh(self, df):
        df = df.loc[df['y'] > 0]
        neg_bat = df.loc[df['y'] < 0, 'obj_name'].unique()
        df = df.loc[~df['obj_name'].isin(neg_bat)].reset_index(drop=True)
        df = df[df['obj_name'].notna()]
        return df 

    def clean_anomaly(self, df):
        df = df.ffill().bfill()
        pred_ab_y = remove_anomaly(df,'obj_name', 15,tar_col='y')        
        return pred_ab_y

    def smooth_soh(self, df):
        sm_pred = groupby_apply(df, 'y', 'obj_name', ma_smooth, plotname = 'smoothing SOHs -  MA Method')
        return sm_pred

    def scaling_soh(self, df):
        sc_pred = groupby_apply(df, 'y', 'obj_name', scale_data, b_plot=False, plotname = 'scaling - SOHs')
        return sc_pred

    def label_abnormal_batteries(self, df):
        pred_ades = drop_type1(df)
        return pred_ades
        
def run_preprocessor(args):
    parser = argparse.ArgumentParser(description='SOH Preprocessor')
    parser.add_argument("--result_output", type=str, required=True)
    args = parser.parse_args(args)
    Path(args.after_pp).parent.mkdir(parents=True, exist_ok=True)

    # TODO: read in data
    with open(args.result_output, 'r') as f:           
        # print("open_file", type(f))
        file_load = json.load(f)
    data = pd.DataFrame()
    for key, item in file_load.items():
        data[key] = item

    PProcessor =  SOH_Proprocesser()
    # Step 1: Generate df
    gd  = PProcessor.generate_dataset(data)
    logging.info('(AESC-SOH) --> Finish Step 1 Dataset Generation Process')

    ## Step 2: Fill missing values
    # print(gd.isnull().sum())
    fn = PProcessor.fillna(gd)
    # print(fn.isnull().sum())
    logging.info('(AESC-SOH) --> Finish Step 2 Fill Missing Value Process')


    ## Step 3: Filter SOH 
    fs = PProcessor.filter_soh(fn)
    # print(fs.tail())
    logging.info('(AESC-SOH) --> Finish Step 3 Filter SOH Process')

    ## Step 4: Remove Anomaly
    ra = PProcessor.clean_anomaly(fs)
    logging.info('(AESC-SOH) --> Finish Step 4 Remove Anomaly SOH Process')
    # print(ra.tail())

    # ## Step 5: Smooth SOH
    sms = PProcessor.smooth_soh(ra)
    logging.info('(AESC-SOH) --> Finish Step 5 Smooth SOH Process')
    # ## Step 6: Scale SOH
    scs = PProcessor.scaling_soh(sms)
    logging.info('(AESC-SOH) --> Finish Step 6 Scale SOH Process')
    # print(max(scs['y']))

    # ## Step 7: Label Abnormal Batteries 
    lab = PProcessor.label_abnormal_batteries(scs)
    logging.info('(AESC-SOH) --> Finish Step 7 Label Abnormal Cell Process')

    xgb_predict_json = {}
    for col in lab.columns:
        xgb_predict_json[col] = lab[col].tolist()

    with open(args.result_output, 'w') as sum_path:
        sum_path.write(json.dumps(xgb_predict_json))
    return lab

# Supporting Functions


if __name__ == '__main__':
    run_preprocessor(sys.argv[1:])
    # file_dir = os.path.join(gwd, 'data/','cycle_forecastdata.csv')
    # lev3_df = pd.read_csv(file_dir,index_col = 0)
    # run_preprocessor(lev3_df)
    # PProcessor =  SOH_Proprocesser()
    # # Step 1: Generate df
    # gd  = PProcessor.generate_dataset(lev3_df)
    # # print(gd.tail())

    # ## Step 2: Fill missing values
    # # print(gd.isnull().sum())
    # fn = PProcessor.fillna(gd)
    # # print(fn.isnull().sum())

    # ## Step 3: Filter SOH 
    # fs = PProcessor.filter_soh(fn)
    # # print(fs.tail())

    # ## Step 4: Remove Anomaly
    # ra = PProcessor.clean_anomaly(fs)
    # # print(ra.tail())

    # # ## Step 5: Smooth SOH
    # sms = PProcessor.smooth_soh(ra)

    # # ## Step 6: Scale SOH
    # scs = PProcessor.scaling_soh(sms)
    # # print(max(scs['y']))

    # # ## Step 7: Label Abnormal Batteries 
    # lab = PProcessor.label_abnormal_batteries(scs)
    # # print(lab['chk_abn'].value_counts())




